"""Сцены NeuroClock — как экраны ESP32-часов, но на Pi. Каждая сцена берёт экран, какой он есть, и уводит
его в себя через нейросеть: горящие точки стекают в узлы, сеть собирает новое (morph). Цикл: TODAY → большие
часы → курсы → снова TODAY."""
from __future__ import annotations

import datetime as dt

from matrix import (BIG_X, BIG_Y, BLUE, GREEN, RED, W, Screen, big_points, center_x, draw_text, morph,
                    text_points)

DAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")


def now() -> dt.datetime:
    return dt.datetime.now()


async def morph_from_screen(scr: Screen, B: list, cb=None, beam: bool = False, area=None) -> None:
    A, ca = scr.lit()
    await morph(scr, A, ca, B, cb, beam, area or (0, 0, W, 32))


def colon_small(scr: Screen, on: bool) -> None:  # двоеточие «HH:MM» внизу: x = 31, строки 26 и 28
    for y in (26, 28):
        scr.set(31, y, GREEN if on else (0, 0, 0))


def colon_big(scr: Screen, on: bool) -> None:
    c = BLUE if on else (0, 0, 0)
    for y0 in (BIG_Y + 5, BIG_Y + 12):
        scr.fill(BIG_X[1] + 14, y0, 2, 2, c)


async def today(scr: Screen, clock, seconds: float = 12) -> None:
    """Крупное «TODAY» собирает сеть с лучом, потом оно перетекает в день недели, дату и часы."""
    T = text_points("TODAY", 3, 9, 2, 2)
    await morph_from_screen(scr, T, None, beam=True)
    await scr.hold(1.2)
    t = now()
    weekend = clock.weekend
    lines = ((DAYS[t.weekday()], 0, BLUE if weekend else RED), (t.strftime("%d.%m.%y"), 12, BLUE),
             (t.strftime("%H:%M"), 24, GREEN))
    B, cb = [], []
    for text, y, c in lines:
        pts = text_points(text, center_x(text), y)
        B += pts; cb += [c] * len(pts)
    await morph(scr, T, None, B, cb)
    shown = t.strftime("%H:%M")
    end = scr_time() + seconds
    while scr_time() < end:
        t = now()
        if t.strftime("%H:%M") != shown:  # минута сменилась — строка часов заново
            shown = t.strftime("%H:%M")
            scr.fill(0, 24, W, 8)
            draw_text(scr, shown, center_x(shown), 24, GREEN)
        colon_small(scr, t.second % 2 == 0)
        await scr.hold(0.25)


async def big_clock(scr: Screen, clock, seconds: float = 20) -> None:
    """Большие ночные часы: экран перетекает в цифры, меняющиеся цифры пересобирает сеть."""
    def digits(t):
        return [t.hour // 10, t.hour % 10, t.minute // 10, t.minute % 10]

    shown = digits(now())
    B = [p for j, d in enumerate(shown) for p in big_points(d, j)]
    await morph_from_screen(scr, B, BLUE)
    end = scr_time() + seconds
    while scr_time() < end:
        t = now()
        d = digits(t)
        if d != shown:
            k = next(j for j in range(4) if d[j] != shown[j])
            A = [p for j in range(k, 4) for p in big_points(shown[j], j)]
            Bn = [p for j in range(k, 4) for p in big_points(d[j], j)]
            if k <= 1:
                colon_big(scr, False)
            await morph(scr, A, [BLUE] * len(A), Bn, BLUE, area=(BIG_X[k] - 1, 0, W, 32))
            shown = d
        colon_big(scr, t.second % 2 == 0)
        await scr.hold(0.25)


async def currency(scr: Screen, clock, seconds: float = 10) -> None:
    """Курсы ЦБ: код и курс, цвет — как у ESP32-часов: курс вырос — зелёный, упал — красный."""
    cur = clock.currency
    if not cur:
        return
    B, cb = [], []
    for row, code in enumerate(("USD", "EUR")):
        c = cur.get(code)
        if not c:
            continue
        text = f"{code} {c['value']:.2f}"
        col = GREEN if c["delta"] > 0 else RED if c["delta"] < 0 else BLUE
        pts = text_points(text, center_x(text), 6 + row * 12)
        B += pts; cb += [col] * len(pts)
    await morph_from_screen(scr, B, cb)
    await scr.hold(seconds)


def scr_time() -> float:
    import asyncio
    return asyncio.get_running_loop().time()


async def run(scr: Screen, clock) -> None:
    """Цикл экранов; ошибка сцены не роняет остальное — экран просто идёт дальше."""
    import logging
    log = logging.getLogger("neuroclock.scenes")
    while True:
        for scene in (today, big_clock, currency):
            try:
                await scene(scr, clock)
            except Exception:
                log.exception("сцена %s упала", scene.__name__)
                scr.clear()
                await scr.hold(1)
