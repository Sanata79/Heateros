"""Сцены NeuroClock — экраны ESP32-часов на Pi, а между ними и под ними живёт стая-мозг (mind.py).

Цикл: TODAY (минута часов, TODAY растворяется в сети) → HEATER (AIR, влажность, CO2, STATUS, MODE с живыми
значками, heatneuro.py) → CURRENCY (монеты, шар, порталы, барабаны USD и EUR,
осыпание монетками) → WEATHER (NOW и Tomorrow, живые сцены, Pressure → Wind, wxneuro.py) → стая думает и сама
собирает время крупно → снова TODAY — порядок, как на ESP; после погоды — сообщения Лины (linaneuro.py),
если они есть. Вечер (большие часы), ночь (глаза засыпают), утро (глаза просыпаются) — night.py, по часам.
Сцена рисует только своё (Screen) и задаёт, насколько стая притихла: mind.calm(…).
"""
from __future__ import annotations

import asyncio
import datetime as dt
import logging
import math
import random

import curneuro
import fx
import heatneuro
import boot as bootfx
import linaneuro
import night
import wxneuro
from clockrow import SMALL_Y, ClockKeeper, colon_small, drip_small, now, row_neuro
from matrix import BIG_X, BIG_Y, BLUE, GREEN, RED, Screen, big_points, center_x, grad, morph, text_points

DAYS = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
TODAY_SHOW = 60              # секунд TODAY с часами, как на ESP (потом там HEATER)
TD_READY = False             # крупное «TODAY» уже собрала загрузка (tdReady)
log = logging.getLogger("neuroclock.scenes")


def clock_s() -> float:
    return asyncio.get_running_loop().time()


async def today(scr: Screen, clock, mind) -> None:
    """TODAY, как todayIn/todayShow/todayOut на ESP: сеть из пустоты собирает крупное «TODAY» с лучом, оно
    переливается и перетекает в день недели, дату и часы; минута за минутой часы стекают; в конце весь экран
    растворяется в сети — и стая снова в полную силу."""
    global TD_READY
    mind.calm(.12)
    T = text_points("TODAY", 3, 9, 2, 2)
    if TD_READY:  # уже на экране — после загрузки
        TD_READY = False
    else:
        await morph(scr, [], None, T, None, beam=True)
    t0 = clock_s()
    while clock_s() - t0 < 1.2:  # перелив, как «AI»
        tt = (clock_s() - t0) * .5
        for x, y in T:
            scr.set(x, y, grad(x, tt))
        await scr.frame()
    t = now()
    lines = ((DAYS[t.weekday()], 0, BLUE if clock.weekend else RED), (t.strftime("%d.%m.%y"), 12, BLUE),
             (t.strftime("%H:%M"), SMALL_Y, GREEN))
    B, cb = [], []
    for text, y, c in lines:
        pts = text_points(text, center_x(text), y)
        B += pts; cb += [c] * len(pts)
    await morph(scr, T, [scr.get(x, y) for x, y in T], B, cb)
    mind.calm(.22)
    shown, day = t.strftime("%H:%M"), t.date()
    end = clock_s() + TODAY_SHOW
    while clock_s() < end:
        t = now()
        hm = t.strftime("%H:%M")
        if t.date() != day:  # полночь — TODAY заново, с новой датой
            break
        if hm != shown:
            colon_small(scr, True)
            await drip_small(scr, shown, hm, GREEN)
            shown = hm
        colon_small(scr, t.second % 2 == 0)
        await scr.hold(0.25)
    mind.calm(.1)
    A, ca = scr.lit()
    await morph(scr, A, ca, [], None)  # экран растворяется в сети
    scr.clear()


async def currency(scr: Screen, clock, mind) -> None:
    """CURRENCY, как на ESP: монеты вихрем собираются в заставку и осыпаются, часы внизу собирает сеть, курсы
    USD и EUR — шар, порталы, барабаны (curneuro.py); в конце весь экран осыпается монетками."""
    if not clock.currency:
        return
    mind.calm(.12)
    P = await fx.coins_title_in(scr, "CURRENCY")
    await scr.hold(.3)
    await fx.coins_title_out(scr, P)
    await row_neuro(scr, now().strftime("%H:%M"), GREEN)
    keeper = ClockKeeper(scr)
    keeper.start()
    try:
        await curneuro.currency(scr, clock, mind)
    finally:
        keeper.stop()
    await fx.coins_out(scr)
    mind.calm(1)


async def weather(scr: Screen, clock, mind) -> None:
    await wxneuro.weather(scr, clock, mind)


async def heater(scr: Screen, clock, mind) -> None:
    await heatneuro.heater(scr, clock, mind)


async def lina(scr: Screen, clock, mind) -> None:
    await linaneuro.lina(scr, clock, mind)


def time_points(t: dt.datetime) -> list:
    d = (t.hour // 10, t.hour % 10, t.minute // 10, t.minute % 10)
    pts = [p for j, v in enumerate(d) for p in big_points(v, j)]
    for y0 in (BIG_Y + 5, BIG_Y + 12):  # двоеточие
        pts += [(BIG_X[1] + 14 + dx, y0 + dy) for dx in (0, 1) for dy in (0, 1)]
    return pts


async def think(scr: Screen, clock, mind) -> None:
    """Пауза: стая в полную силу думает, потом сама «додумывается» до времени — узлы тянутся к цифрам и
    рисуют их, держат и отпускают (около 11 с)."""
    mind.calm(1)
    await scr.hold(4)
    mind.gather(time_points(now()))
    while not mind.done:
        await scr.hold(0.2)
    await scr.hold(1.5)


DAY = (today, heater, currency, weather, lina, think)


async def run(scr: Screen, clock, mind, boot: bool = False) -> None:
    """Режимы по часам, как на ESP (night.mode_now): днём — цикл экранов, начало дня — с пожелания; вечер,
    ночь, утро — night.py. boot — сначала загрузка (boot.py). Ошибка сцены не роняет остальное."""
    global TD_READY
    for _ in range(50):  # будни или выходной и Wake up — сначала данные от веб-части
        if getattr(clock, "ready", True):
            break
        await scr.hold(.2)
    last = None
    if boot:
        try:
            shown = await bootfx.boot(scr, clock, mind)
            mode = night.mode_now(now(), clock.weekend, getattr(clock, "wake", False))
            if shown == "today" and mode == "day":
                TD_READY, last = True, "day"  # пожелание уже было, TODAY на экране
            elif shown == "today" and mode == "morning":
                night.GREETED = True
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("загрузка упала")
            scr.clear()
    while True:
        mode = night.mode_now(now(), clock.weekend, getattr(clock, "wake", False))
        steps = [night.day_start] if mode == "day" and last != "day" else []
        steps += list(DAY) if mode == "day" else [{"evening": night.evening, "night": night.night,
                                                   "morning": night.morning}[mode]]
        last = mode
        for scene in steps:
            try:
                await scene(scr, clock, mind)
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("сцена %s упала", scene.__name__)
                scr.clear()
                mind.calm(1)
                await scr.hold(1)
            if mode == "day" and not night.settled("day", clock):
                break
