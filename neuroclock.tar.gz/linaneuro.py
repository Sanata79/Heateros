"""Экран сообщений Лины — порт hLina (lina.ino) с ESP32-часов. Идёт после погоды, если есть что сказать.

Из пустоты рождается сеть, узлы дугами собирают крупное «AI», по нему проходит луч распознавания, градиент
делает круг. Для каждого сообщения (MQTT Lina1 — почта, Lina2 — Доктор Надежда, Lina3 — сборный) «AI» или
прежний заголовок стекает в сеть, она собирает новый наверху — по умолчанию Mail / Nadejda / Lina, или свой
из сообщения «Luna|текст». В первый раз внизу сеть собирает часы. Текст (по-русски) бежит между нейропорталами
из шара, переливаясь голубым → фиолетовым. В конце весь экран разлетается искрами.
"""
from __future__ import annotations

import asyncio

import fx
from clockrow import SMALL_Y, ClockKeeper, now, row_neuro
from matrix import GREEN, W, Screen, center_x, grad, morph, text_points
from ticker import Row

TOPICS = ("Lina1", "Lina2", "Lina3")
TITLES = ("Mail", "Nadejda", "Lina")  # по умолчанию; Lina3 — заголовок обычно в сообщении


def lina_title(m: str, default: str) -> tuple[str, str]:
    """«Заголовок|текст»: заголовок — латиница, цифры, пробел, точка, дефис, до 10 знаков (так рисует шрифт
    заголовков); иначе — заголовок топика по умолчанию."""
    bar = m.find("|")
    if not 1 <= bar <= 10:
        return default, m
    head = m[:bar]
    if not all((ch.isascii() and ch.isalnum()) or ch in " .-" for ch in head):
        return default, m
    return head, m[bar + 1:].strip()


async def lina(scr: Screen, clock, mind) -> None:
    msgs = [(clock.lina or {}).get(t, "").strip() for t in TOPICS]
    if not any(msgs):
        return
    mind.calm(.12)
    A = text_points("AI", 17, 5, 3, 3)
    await morph(scr, [], None, A, None, beam=True)  # весь экран
    for f in range(1, 31):  # градиент делает круг — и снова как в начале
        for x, y in A:
            scr.set(x, y, grad(x, f / 30))
        await scr.frame(.03)
    await asyncio.sleep(.6)
    keeper, first = ClockKeeper(scr), True
    try:
        for i, m in enumerate(msgs):
            if not m:
                continue
            title, text = lina_title(m, TITLES[i])
            B = text_points(title, center_x(title), 0)
            if B and A:  # заголовок перетекает через сеть; в первый раз часов ещё нет — весь экран
                await morph(scr, A, [scr.get(x, y) for x, y in A], B, None, area=(0, 0, W, 32 if first else SMALL_Y))
                A = B
            if first:
                await row_neuro(scr, now().strftime("%H:%M"), GREEN)
                keeper.start()
                first = False
            await Row(scr, 12).run(text)  # строка между нейропорталами
    finally:
        keeper.stop()
    await fx.scatter_out(scr)  # весь экран разлетается искрами, как «AI»
    mind.calm(1)
