"""NeuroPortal USB CDC: send the newest 64×32 frame and read sensor telemetry."""

from __future__ import annotations

import asyncio
import json
import logging
import os
import termios
import time
import tty
from pathlib import Path

import matrix
from nc_portal_flash import flash_in_progress, try_lock, usb_serial

log = logging.getLogger("neuroclock.portal")
MAGIC = b"\xa5\x5aF"
RGB_BYTES = matrix.W * matrix.H * 3


def encode_frame(rgb: bytes) -> bytes:
    if len(rgb) != RGB_BYTES:
        raise ValueError("expected a 64×32 RGB frame")
    body = bytearray(matrix.W * matrix.H * 2)
    j = 0
    for i in range(0, len(rgb), 3):
        r, g, b = rgb[i], rgb[i + 1], rgb[i + 2]
        body[j] = ((g & 0x1c) << 3) | (b >> 3)
        body[j + 1] = (r & 0xf8) | (g >> 5)
        j += 2
    return MAGIC + body + bytes((sum(body) & 0xff,))


def portal_ports() -> list[Path]:
    configured = os.getenv("NEUROCLOCK_PORTAL_PORT")
    if configured:
        return [Path(configured)]
    ports = []
    for tty_dev in sorted(Path("/sys/class/tty").glob("ttyACM*")):
        for parent in tty_dev.resolve().parents:
            try:
                vendor = (parent / "idVendor").read_text().strip()
            except OSError:
                continue
            if vendor == "303a":  # Espressif native USB; verify NeuroPortal with #I before sending frames
                ports.append(Path("/dev", tty_dev.name))
            break
    return ports


def open_port(port: Path) -> int:
    fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
    try:
        tty.setraw(fd)
        attrs = termios.tcgetattr(fd)
        attrs[2] |= termios.CLOCAL | termios.CREAD
        attrs[4] = attrs[5] = termios.B115200
        termios.tcsetattr(fd, termios.TCSANOW, attrs)
    except BaseException:
        os.close(fd)
        raise
    return fd


class PortalPanel:
    def __init__(self, settings: dict, data: Path):
        self.base = int(settings["brightness"])
        self.applied = self.base
        self.brightness = self.base
        self.frames = 0
        self.hw = False
        self.identified = False
        self.error = "Ожидаю NeuroPortal по USB"
        self.night = True
        self.ack: bool | None = None
        self.latest: tuple[int, bytes] | None = None
        self.sequence = 0
        self.data = data
        self.status = data / "portal_status.json"

    def show(self, rgb: bytes) -> None:
        if self.hw and not self.night:
            self.sequence += 1
            self.latest = (self.sequence, rgb)

    def show_img(self, img) -> None:
        self.show(img.tobytes())

    def bright(self, percent: int) -> None:
        self.brightness = max(1, min(100, int(percent)))

    def set_night(self, night: bool) -> None:
        if night != self.night:
            self.night = night
            self.ack = None
            self.latest = None
            self.hw = False

    async def shutdown(self) -> None:
        if not self.identified:
            return
        self.set_night(True)
        for _ in range(40):
            if self.ack is True:
                return
            await asyncio.sleep(.025)

    async def send(self, fd: int, packet: bytes) -> None:
        pending = memoryview(packet)
        until = time.monotonic() + .35
        while pending:
            if time.monotonic() >= until:
                raise OSError("таймаут записи USB")
            try:
                written = os.write(fd, pending)
                if written:
                    pending = pending[written:]
                    continue
            except BlockingIOError:
                pass
            await asyncio.sleep(.004)

    def save_telemetry(self, report: dict) -> None:
        try:
            tmp = self.status.with_suffix(".tmp")
            tmp.write_text(json.dumps({**report, "ts": time.time()}))
            tmp.replace(self.status)
        except OSError as exc:
            log.debug("portal status: %s", exc)

    async def session(self, fd: int, port: Path) -> None:
        rx = b""
        identify = True
        last_rx = time.monotonic()
        next_command = next_time = 0.0
        next_flash_check = 0.0
        last_brightness = sent_frame = None
        requested = None
        serial = usb_serial(port)
        while True:
            try:
                chunk = os.read(fd, 4096)
            except BlockingIOError:
                chunk = None
            if chunk == b"":
                raise OSError("USB отключён")
            if chunk:
                rx += chunk
                while b"\n" in rx:
                    line, rx = rx.split(b"\n", 1)
                    try:
                        message = json.loads(line)
                    except ValueError:
                        continue
                    if not isinstance(message, dict):
                        continue
                    if message.get("hello") == "NeuroPortal" or str(message.get("fw", "")).startswith("NeuroPortal "):
                        identify = False
                        self.identified = True
                        last_rx = time.monotonic()
                        requested, self.ack, self.hw = None, None, False
                        last_brightness = sent_frame = None
                        next_command = next_time = 0.0
                    elif not identify and "night" in message:
                        if requested is self.night and message["night"] == int(self.night):
                            self.ack = self.night
                            self.hw = True
                            self.error = ""
                            last_rx = time.monotonic()
                    elif not identify and "mode" in message and "rx" in message:
                        last_rx = time.monotonic()
                        self.save_telemetry({**message, "usb_port": str(port), "usb_serial": serial})
                if len(rx) > 8192:
                    rx = b""

            now = time.monotonic()
            if now >= next_flash_check:
                next_flash_check = now + .1
                if flash_in_progress(self.data):
                    self.hw = False
                    if self.identified and self.ack is not True:
                        await self.send(fd, b"#N 1\n")
                        await asyncio.sleep(.1)
                    return
            if now - last_rx > 5:
                raise OSError("Portal не отвечает по USB")
            if identify:
                if now >= next_command:
                    await self.send(fd, b"#I\n")
                    next_command = now + .5
            elif self.ack is not self.night:
                if requested is not self.night or now >= next_command:
                    requested = self.night
                    await self.send(fd, f"#N {int(requested)}\n".encode())
                    next_command = now + .5
            else:
                if now >= next_time:
                    offset = time.localtime().tm_gmtoff // 60
                    await self.send(fd, f"#T {int(time.time())} {offset}\n".encode())
                    next_time = now + 60
                if last_brightness != self.brightness:
                    last_brightness = self.brightness
                    await self.send(fd, f"#B {round(last_brightness * 255 / 100)}\n".encode())
                frame = self.latest
                if frame and frame[0] != sent_frame and not self.night:
                    await self.send(fd, encode_frame(frame[1]))
                    sent_frame = frame[0]
                    self.frames += 1
            await asyncio.sleep(.004)

    async def connect(self, port: Path) -> None:
        fd = None
        try:
            fd = open_port(port)
            await self.session(fd, port)
        except OSError as exc:
            self.error = f"{port.name}: {exc}"
            log.debug("%s", self.error)
        finally:
            self.hw = False
            self.identified = False
            self.ack = None
            self.latest = None
            if fd is not None:
                os.close(fd)

    async def run(self) -> None:
        while True:
            if not flash_in_progress(self.data):
                with try_lock(self.data / "portal-usb.lock") as free:
                    if free:
                        for port in portal_ports():
                            if flash_in_progress(self.data):
                                break
                            await self.connect(port)
            await asyncio.sleep(.75)
