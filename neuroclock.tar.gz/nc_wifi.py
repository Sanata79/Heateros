#!/usr/bin/env python3
"""NeuroClock: переход на другую сеть Wi-Fi с откатом.

Запускает app.py (кнопка USE / CONNECT в Connection → Wi-Fi) отдельной службой от root:
    sudo -n systemd-run --unit=neuroclock-wifi --collect … nc_wifi.py <uuid> [--new]
Служба живёт сама по себе: связь со страницей рвётся на время переключения, перезапуск веба её не остановит.

Ход: запоминаем текущую сеть → поднимаем новую (до 40 с) → проверяем адрес и ответ роутера (шлюза) →
нет — возвращаемся на прежнюю. Новая сеть, к которой не вышло подключиться (--new: только что добавили,
например, с ошибкой в пароле), остаётся в таблице, но без автоподключения: после перезагрузки часы не станут
о неё спотыкаться. Ход и итог — data/wifi.json (его читает страница), строки — в журнал (Wi-Fi).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

DATA = Path(os.getenv("NEUROCLOCK_DATA", "/home/sasha/nc/data"))
STATUS = DATA / "wifi.json"
WAIT = 40  # с: на подключение к сети и на возврат


def nm(*args: str, wait: int = 0) -> subprocess.CompletedProcess:
    pre = ["nmcli", "--wait", str(wait)] if wait else ["nmcli"]
    return subprocess.run([*pre, *args], capture_output=True, text=True, timeout=wait + 15)


def log(msg: str) -> None:
    subprocess.run(["logger", "-t", "neuroclock", "Wi-Fi: " + msg])


def write(**st) -> None:
    st["ts"], st["t"] = time.strftime("%d.%m %H:%M:%S"), int(time.time())
    tmp = STATUS.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, ensure_ascii=False))
    os.chown(tmp, 1000, 1000)
    tmp.replace(STATUS)


def active() -> tuple[str, str]:
    """Текущая сеть Wi-Fi на wlan0: (uuid, имя) или ("", "")."""
    for ln in nm("-t", "-f", "UUID,TYPE,DEVICE,NAME", "con", "show", "--active").stdout.splitlines():
        p = ln.split(":", 3)
        if len(p) == 4 and p[1] == "802-11-wireless" and p[2] == "wlan0":
            return p[0], p[3]
    return "", ""


def ssid(uuid: str) -> str:
    return nm("-g", "802-11-wireless.ssid", "con", "show", uuid).stdout.strip() or uuid[:8]


def online() -> str:
    """Адрес Pi, если есть адрес и роутер отвечает; иначе пусто."""
    for _ in range(10):
        route = subprocess.run(["ip", "-4", "route", "show", "default", "dev", "wlan0"], capture_output=True, text=True).stdout.split()
        addr = subprocess.run(["ip", "-4", "-o", "addr", "show", "wlan0"], capture_output=True, text=True).stdout.split()
        if "via" in route and "inet" in addr:
            gw, ip = route[route.index("via") + 1], addr[addr.index("inet") + 1].split("/")[0]
            for _ in range(3):
                if subprocess.run(["ping", "-c", "1", "-W", "2", gw], capture_output=True).returncode == 0:
                    return ip
        time.sleep(2)
    return ""


def reason(r: subprocess.CompletedProcess) -> str:
    """Короткая причина из ответа nmcli (строка «Error: …», подсказку про journalctl отбрасываем)."""
    err = next((l for l in (r.stderr + r.stdout).splitlines() if l.startswith("Error:")), "")
    low = err.lower()
    if "secrets were required" in low or "802-1x supplicant" in low or "psk" in low:
        return "wrong password"
    if "could not be found" in low or "no network with ssid" in low:
        return "network not found"
    if "timeout" in low:
        return "no answer in 40 s"
    return err.replace("Error: Connection activation failed: ", "").replace("Error: ", "")[:120] or "failed"


def main() -> int:
    new, fresh = sys.argv[1], "--new" in sys.argv
    to = ssid(new)
    old, old_name = active()
    old_ssid = ssid(old) if old else ""
    if old == new:
        write(state="ok", ssid=to, ip=online(), note="already connected")
        return 0
    write(state="trying", ssid=to, back=old_ssid)
    log(f"переход {old_ssid or '—'} → {to}")
    r = nm("con", "up", "uuid", new, wait=WAIT)
    ip = online() if r.returncode == 0 else ""
    if ip:
        if fresh:
            nm("con", "modify", "uuid", new, "connection.autoconnect", "yes")
        write(state="ok", ssid=to, ip=ip)
        log(f"{to}: подключено, адрес {ip}")
        return 0
    why = reason(r) if r.returncode else "no answer from the router"
    log(f"{to}: не вышло ({why}) — возврат на {old_ssid or 'автоподключение'}")
    if fresh:
        nm("con", "modify", "uuid", new, "connection.autoconnect", "no")
    write(state="back", ssid=to, back=old_ssid, error=why)
    ok = False
    if old:
        ok = nm("con", "up", "uuid", old, wait=WAIT).returncode == 0 and bool(online())
    if not ok:  # прежней нет или не поднялась — пусть NetworkManager выберет сам по приоритетам
        nm("device", "connect", "wlan0", wait=WAIT)
    now = ssid(active()[0]) if active()[0] else ""
    write(state="failed", ssid=to, back=now, error=why, ip=online() if now else "")
    log(f"остались на {now or '— (нет сети)'}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
