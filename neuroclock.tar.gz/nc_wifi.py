#!/usr/bin/env python3
"""NeuroClock: Wi-Fi — переход на другую сеть с откатом и запасная точка доступа «NeuroClock».

    nc_wifi.py <uuid> [--new]   переход (кнопки USE / CONNECT в Connection → Wi-Fi); app.py запускает его
                                отдельной службой от root: sudo -n systemd-run --unit=neuroclock-wifi --collect …
    nc_wifi.py --ap             поднять точку доступа сейчас (кнопка HOTSPOT) — та же служба neuroclock-wifi
    nc_wifi.py --watch          сторож (служба neuroclock-wifi-watch, root, всегда): нет сети 5 минут — точка доступа;
                                пока к точке никто не подключён, раз в 5 минут ищет свои сети и возвращается

Переход: запоминаем текущую сеть → поднимаем новую (до 40 с) → проверяем адрес и ответ роутера (шлюза) →
нет — возвращаемся на прежнюю. Новая сеть, к которой не вышло подключиться (--new: только что добавили,
например, с ошибкой в пароле), остаётся в таблице, но без автоподключения: после перезагрузки часы не станут
о неё спотыкаться. Ход и итог — data/wifi.json (его читает страница), строки — в журнал (Wi-Fi).

Точка доступа: сеть NeuroClock, пароль neuroclock, часы — 10.42.0.1 (NetworkManager «shared»: сам раздаёт адреса;
DNS отвечает 10.42.0.1 на любое имя — телефон сам открывает страницу, nc_system.py кладёт CAPTIVE). Пока она
поднята, Wi-Fi часов искать сети не может — список «Nearby» берётся из data/wifi_scan.json (поиск перед подъёмом).
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

DATA = Path(os.getenv("NEUROCLOCK_DATA", "/home/sasha/nc/data"))
STATUS = DATA / "wifi.json"
SCAN = DATA / "wifi_scan.json"
WAIT = 40          # с: на подключение к сети и на возврат
AP_NAME, AP_SSID, AP_PSK, AP_IP = "NeuroClock-AP", "NeuroClock", "neuroclock", "10.42.0.1"
LOST = 300         # с без сети → точка доступа
RETRY = 300        # с: точка без гостей → поискать свои сети
GUEST = 120        # с после ухода последнего гостя — не трогать точку (вдруг вернётся)
# Чистый WPA2. Без pmf disable NetworkManager поднимает точку WPA2+WPA3 (SAE, PSK-SHA256): чип Zero 2 W (brcmfmac)
# так работает плохо — телефон выбирает WPA3 и не подключается (проверено 06.11.2026). Пароль — последним.
AP_SEC = ("wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.proto", "rsn", "wifi-sec.pairwise", "ccmp", "wifi-sec.group", "ccmp",
          "wifi-sec.pmf", "disable", "wifi-sec.psk", AP_PSK)


def nm(*args: str, wait: int = 0) -> subprocess.CompletedProcess:
    pre = ["nmcli", "--wait", str(wait)] if wait else ["nmcli"]
    try:
        return subprocess.run([*pre, *args], capture_output=True, text=True, timeout=wait + 20)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(args, 1, "", "Error: timeout")


def log(msg: str) -> None:
    subprocess.run(["logger", "-t", "neuroclock", "Wi-Fi: " + msg])


def save_json(path: Path, data) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False))
    os.chown(tmp, 1000, 1000)
    tmp.replace(path)


def write(**st) -> None:
    st["ts"], st["t"] = time.strftime("%d.%m %H:%M:%S"), int(time.time())
    save_json(STATUS, st)


def fields(line: str) -> list[str]:
    """Строка nmcli -t: поля через «:», внутри поля «\\:»."""
    out, cur, esc = [], "", False
    for ch in line:
        if esc:
            cur += ch; esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            out.append(cur); cur = ""
        else:
            cur += ch
    return out + [cur]


def active() -> tuple[str, str]:
    """Текущее подключение Wi-Fi на wlan0: (uuid, имя) или ("", "")."""
    for ln in nm("-t", "-f", "UUID,TYPE,DEVICE,NAME", "con", "show", "--active").stdout.splitlines():
        p = fields(ln)
        if len(p) == 4 and p[1] == "802-11-wireless" and p[2] == "wlan0":
            return p[0], p[3]
    return "", ""


def ssid(uuid: str) -> str:
    return nm("-g", "802-11-wireless.ssid", "con", "show", uuid).stdout.strip() or uuid[:8]


NO_IP, NO_GW = "no address from the network in 50 s", "the router does not answer"
_why = ""


def online(limit: float = 50) -> str:
    """Адрес Pi, если есть адрес и роутер отвечает; иначе пусто (причина — в _why).
    Ждём адрес до 50 с: nmcli считает сеть поднятой уже по IPv6, а повторитель Home1 даёт IPv4 через ~24 с
    (06.11.2026 откат на 20-й секунде дважды вернул часы с рабочей сети). Сам NetworkManager ждёт DHCP 45 с."""
    global _why
    end, _why = time.monotonic() + limit, NO_IP
    while True:
        route = subprocess.run(["ip", "-4", "route", "show", "default", "dev", "wlan0"], capture_output=True, text=True).stdout.split()
        addr = subprocess.run(["ip", "-4", "-o", "addr", "show", "wlan0"], capture_output=True, text=True).stdout.split()
        if "via" in route and "inet" in addr:
            _why = NO_GW
            gw, ip = route[route.index("via") + 1], addr[addr.index("inet") + 1].split("/")[0]
            for _ in range(3):
                if subprocess.run(["ping", "-c", "1", "-W", "2", gw], capture_output=True).returncode == 0:
                    return ip
        if time.monotonic() > end:
            return ""
        time.sleep(2)


def reason(r: subprocess.CompletedProcess) -> str:
    """Короткая причина из ответа nmcli (строка «Error: …», подсказку про journalctl отбрасываем)."""
    err = next((l for l in (r.stderr + r.stdout).splitlines() if l.startswith("Error:")), "")
    low = err.lower()
    if "secrets were required" in low or "802-1x supplicant" in low or "psk" in low:
        return "wrong password"
    if "could not be found" in low or "no network with ssid" in low:
        return "network not found"
    if "timeout" in low:
        return "no answer in 40 s"
    return err.replace("Error: Connection activation failed: ", "").replace("Error: ", "")[:120] or "failed"


# ---------- точка доступа ----------
def ap_uuid() -> str:
    """Профиль точки доступа; нет — создаётся (без автоподключения: поднимает только сторож или кнопка)."""
    r = nm("-g", "connection.uuid", "con", "show", AP_NAME)
    if r.returncode == 0 and r.stdout.strip():
        nm("con", "modify", AP_NAME, *AP_SEC[:-2])  # профиль из прошлой версии — выровнять (pmf)
        return r.stdout.strip()
    nm("con", "add", "type", "wifi", "ifname", "wlan0", "con-name", AP_NAME, "ssid", AP_SSID, "autoconnect", "no",
       "802-11-wireless.mode", "ap", "802-11-wireless.band", "bg", "802-11-wireless.channel", "6",
       "ipv4.method", "shared", "ipv4.addresses", AP_IP + "/24", "ipv6.method", "disabled", *AP_SEC)
    return nm("-g", "connection.uuid", "con", "show", AP_NAME).stdout.strip()


def saved() -> list[tuple[int, str, str]]:
    """Свои сети (без точки доступа): (приоритет, uuid, ssid), сначала первые по выбору."""
    out = []
    for ln in nm("-t", "-f", "UUID,TYPE,NAME,AUTOCONNECT-PRIORITY", "con", "show").stdout.splitlines():
        p = fields(ln)
        if len(p) == 4 and p[1] == "802-11-wireless" and p[2] != AP_NAME:
            out.append((int(p[3]) if p[3].lstrip("-").isdigit() else 0, p[0], ssid(p[0])))
    return sorted(out, reverse=True)


def scan() -> list[dict]:
    """Сети вокруг (только когда точка не поднята) — копия в wifi_scan.json для страницы."""
    seen: dict[str, dict] = {}
    for ln in nm("-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", "yes", wait=15).stdout.splitlines():
        p = fields(ln)
        if len(p) >= 3 and p[0] and p[0] != AP_SSID:
            sig = int(p[1]) if p[1].isdigit() else 0
            if p[0] not in seen or sig > seen[p[0]]["signal"]:
                seen[p[0]] = {"ssid": p[0], "signal": sig, "sec": p[2]}
    near = sorted(seen.values(), key=lambda n: -n["signal"])
    if near:
        save_json(SCAN, {"t": int(time.time()), "near": near})
    return near


def ap_up(why: str) -> bool:
    u = ap_uuid()
    scan()  # пока Wi-Fi свободен — запомнить, что вокруг
    r = nm("con", "up", "uuid", u, wait=WAIT)
    if r.returncode == 0:
        write(state="hotspot", ssid=AP_SSID, ip=AP_IP, why=why)
        log(f"точка доступа {AP_SSID} поднята ({why}), адрес {AP_IP}")
        return True
    log(f"точка доступа не поднялась: {reason(r)}")
    return False


def guests() -> int:
    out = subprocess.run(["/usr/sbin/iw", "dev", "wlan0", "station", "dump"], capture_output=True, text=True).stdout
    return out.count("Station ")


def go_home() -> bool:
    """С точки доступа — на свою сеть, если какая-то видна. Точку опускаем на время поиска (вместе нельзя)."""
    u = ap_uuid()
    nm("con", "down", "uuid", u, wait=10)
    near = {n["ssid"] for n in scan()}
    for _, uuid, name in saved():
        if name in near:
            r = nm("con", "up", "uuid", uuid, wait=WAIT)
            ip = online() if r.returncode == 0 else ""
            if ip:
                write(state="ok", ssid=name, ip=ip, note="back from the hotspot")
                log(f"сеть {name} снова видна — подключено, адрес {ip}")
                return True
            log(f"{name}: {reason(r) if r.returncode else _why}")
    nm("con", "up", "uuid", u, wait=WAIT)  # своих нет — точка обратно
    write(state="hotspot", ssid=AP_SSID, ip=AP_IP, why="no saved network in range")
    return False


def switching() -> bool:
    return subprocess.run(["systemctl", "is-active", "--quiet", "neuroclock-wifi"]).returncode == 0


def watch() -> int:
    ap_uuid()
    lost = guest = tried = 0.0
    in_ap = False
    while True:
        time.sleep(10)
        if switching():
            lost = 0
            continue
        now = time.monotonic()
        uuid, name = active()
        if name != AP_NAME:
            in_ap = False
        elif not in_ap:  # точка только что поднялась (кнопкой, откатом или здесь) — отсчёт с этой минуты
            in_ap, tried, guest = True, now, 0.0
        if name == AP_NAME:
            if guests():
                guest = now
            elif now - max(guest + GUEST, tried) > RETRY:
                tried = now
                if go_home():
                    lost = 0
                tried = time.monotonic()
            continue
        st = nm("-t", "-f", "DEVICE,STATE", "dev").stdout
        if uuid and "wlan0:connected" in st.replace(" (externally)", ""):
            lost = 0
            continue
        lost = lost or now
        if now - lost > LOST:
            if ap_up("no network for 5 min"):
                tried = guest = time.monotonic()
            lost = 0


# ---------- переход на сеть ----------
def switch(new: str, fresh: bool) -> int:
    to = ssid(new)
    old, old_name = active()
    old_ssid = ssid(old) if old else ""
    if old == new:
        write(state="ok", ssid=to, ip=online(5), note="already connected")
        return 0
    write(state="trying", ssid=to, back=old_ssid)
    log(f"переход {old_ssid or '—'} → {to}")
    if old_name == AP_NAME:  # с точки доступа: опустить её, иначе Wi-Fi не найдёт сеть
        nm("con", "down", "uuid", old, wait=10)
    r = nm("con", "up", "uuid", new, wait=WAIT)
    ip = online() if r.returncode == 0 else ""
    if ip:
        if fresh:
            nm("con", "modify", "uuid", new, "connection.autoconnect", "yes")
        write(state="ok", ssid=to, ip=ip)
        log(f"{to}: подключено, адрес {ip}")
        return 0
    why = reason(r) if r.returncode else _why
    log(f"{to}: не вышло ({why}) — возврат на {old_ssid or 'автоподключение'}")
    if fresh:
        nm("con", "modify", "uuid", new, "connection.autoconnect", "no")
    write(state="back", ssid=to, back=old_ssid, error=why)
    ok = False
    if old:
        r2 = nm("con", "up", "uuid", old, wait=WAIT)
        ok = r2.returncode == 0 and (old_name == AP_NAME or bool(online()))
    if not ok:  # прежней нет или не поднялась — пусть NetworkManager выберет сам по приоритетам
        nm("device", "connect", "wlan0", wait=WAIT)
    cur_uuid, cur_name = active()
    if cur_name == AP_NAME:
        write(state="hotspot", ssid=AP_SSID, ip=AP_IP, why=f"{to}: {why}", error=why, tried=to)
    else:
        now = ssid(cur_uuid) if cur_uuid else ""
        write(state="failed", ssid=to, back=now, error=why, ip=online(5) if now else "")
    log(f"остались на {cur_name if cur_name == AP_NAME else (ssid(cur_uuid) if cur_uuid else '— (нет сети)')}")
    return 1


def main() -> int:
    if "--watch" in sys.argv:
        return watch()
    if "--ap" in sys.argv:
        return 0 if ap_up("button") else 1
    return switch(sys.argv[1], "--new" in sys.argv)


if __name__ == "__main__":
    sys.exit(main())
