"""Стая-мозг — живой фон NeuroClock (прототип prototypes/living_network.html).

Узлы летят стаей (держатся рядом, не сталкиваются, выравнивают курс), копят заряд: накопил — вспыхнул и
послал импульсы соседям по связям; дошедший импульс подзаряжает соседа. Связи — к трём ближайшим, вспыхнувшие
светлее. Рисунок всё время новый, без сценария.

Стая — отдельный слой под сценой: compose() кладёт её под то, что нарисовала сцена (берётся ярчайшее по
каждому цвету), с яркостью level. Сцена задаёт, насколько стая притихла (calm): при тексте — фоном, в паузах —
в полную силу. gather() — стая «додумывается» до картинки: узлы тянутся к точкам и рисуют их, потом отпускают.
Шаг — 20 мс, как кадр на ESP32-часах.

Стая живёт непрерывно и по-своему: stir() — событие (сообщение Лины, новая погода, термостат, курс) — стая
вздрагивает, вспыхивает и на миг разгорается ещё до экрана; mood() — характер по времени суток (утром сонная,
днём быстрая и яркая, вечером плавная, ночью еле дышит); imprint() — память: где только что была информация,
туда стая ещё несколько секунд тянется, как след мысли.

MindProc — та же стая в отдельном процессе (на Pi — на своём ядре): каждые 20 мс готовый слой (с яркостью
level) — в общей памяти, команды calm/gather — через общие значения и очередь. Основной поток кладёт слой
под сцену одним вызовом PIL (nc_matrix.compositor).
"""
from __future__ import annotations

import math
import multiprocessing as mp
import queue
import random
import signal
import time
from multiprocessing import shared_memory

from matrix import H, W

N = 30
NEAR2, SEP2, LINK = 12 * 12, 7 * 7, 14.0
PHASES = {"gather": 260, "hold": 200, "release": 80}  # кадры по 20 мс
MOODS = {"morning": (.6, .6, .7, .8), "day": (1, 1, 1, 1), "evening": (.75, .7, .6, .85),
         "night": (.3, .35, .3, .55)}  # скорость, частота вспышек, дрожь, яркость


class Mind:
    def __init__(self):
        # x, y, vx, vy, заряд, отдых, вспышка
        self.nd = [[random.uniform(0, W), random.uniform(0, H), random.uniform(-.5, .5), random.uniform(-.5, .5),
                    random.random(), 0, 0.0] for _ in range(N)]
        self.pulses: list = []  # a, b, k, скорость
        self.level = 0.0         # яркость слоя сейчас — плавно идёт к target
        self.target = 1.0
        self.phase, self.tick, self.targets = "wander", 0, []
        self.acc = [0.0] * (W * H * 3)  # свет стаи за кадр; hit — где он есть
        self.hit: list = []
        self.excite = 0.0                                # событие: 1 — вздрогнула, гаснет за пару секунд
        self.mood_to, self.mp = MOODS["day"], list(MOODS["day"])  # характер: куда идёт и какой сейчас
        self.trace: list = []                            # память: x, y, свежесть
        self.lv = 0.0                                    # яркость слоя с характером и событием

    # ---------- управление из сцен ----------
    def calm(self, level: float) -> None:
        """Яркость стаи: 1 — в полную силу, 0.1…0.3 — фоном под текстом, 0 — погасла."""
        self.target = level

    def gather(self, points: list) -> None:
        """Стая собирается в точки (например, время крупно), держит их и отпускает; done — когда отпустила."""
        self.targets = random.sample(points, len(points))
        self.phase, self.tick = "gather", 0

    def stir(self, s: float = 1.0) -> None:
        """Событие: узлы получают заряд и толчок, стая на миг ярче и быстрее."""
        self.excite = max(self.excite, s)
        for a in self.nd:
            a[4] += random.random() * .6 * s
            t = random.uniform(0, 6.283)
            a[2] += math.cos(t) * .5 * s; a[3] += math.sin(t) * .5 * s

    def mood(self, name: str) -> None:
        """Характер по режиму часов: morning, day, evening, night — переход плавный, за несколько секунд."""
        self.mood_to = MOODS.get(name, MOODS["day"])

    def imprint(self, points: list) -> None:
        """След информации: точки, к которым стая тянется, пока след не остынет (около 6 с)."""
        if points:
            self.trace = (self.trace + [[x, y, 1.0] for x, y in random.sample(points, min(40, len(points)))])[-80:]

    @property
    def done(self) -> bool:
        return self.phase == "wander"

    # ---------- кадр ----------
    def _add(self, x: float, y: float, r: float, g: float, b: float) -> None:
        x, y = int(x + .5), int(y + .5)
        if 0 <= x < W and 0 <= y < H:
            acc, j = self.acc, (y * W + x) * 3
            if not (acc[j] or acc[j + 1] or acc[j + 2]):
                self.hit.append(j)
            acc[j] += r; acc[j + 1] += g; acc[j + 2] += b

    def _line(self, x0, y0, x1, y1, r, g, b) -> None:
        n = math.ceil(max(abs(x1 - x0), abs(y1 - y0)))
        if n < 2:
            return
        acc, hit, dx, dy = self.acc, self.hit, (x1 - x0) / n, (y1 - y0) / n
        for s in range(1, n):  # то же, что _add, — без вызова на каждую точку
            x, y = int(x0 + dx * s + .5), int(y0 + dy * s + .5)
            if 0 <= x < W and 0 <= y < H:
                j = (y * W + x) * 3
                if not (acc[j] or acc[j + 1] or acc[j + 2]):
                    hit.append(j)
                acc[j] += r; acc[j + 1] += g; acc[j + 2] += b

    def step(self) -> None:
        self.level += (self.target - self.level) * 0.06
        mp = self.mp
        for k in range(4):
            mp[k] += (self.mood_to[k] - mp[k]) * .01
        spd, chg, jit, bri = mp
        self.excite *= .97
        base = self.level * bri
        self.lv = base + self.excite * .7 * (1 - base)
        if self.phase != "wander":
            self.tick += 1
            if self.tick > PHASES[self.phase]:
                self.phase = {"gather": "hold", "hold": "release", "release": "wander"}[self.phase]
                self.tick = 0
        gathering = self.phase in ("gather", "hold")
        nd, rnd = self.nd, random.random
        # расстояния — один раз на пару: и для стаи, и для связей
        near = [[] for _ in range(N)]
        for i in range(N):
            a = nd[i]
            for j in range(i + 1, N):
                b = nd[j]
                dx, dy = b[0] - a[0], b[1] - a[1]
                d2 = dx * dx + dy * dy
                if d2 < LINK * LINK:
                    near[i].append((d2, j, dx, dy)); near[j].append((d2, i, -dx, -dy))
        g = .2 if gathering else 1
        trace = self.trace
        step_t = len(self.targets) // N if gathering and self.targets else 0
        for i, a in enumerate(nd):
            cx = cy = ax = ay = sx = sy = 0.0
            n = 0
            for d2, j, dx, dy in near[i]:
                if d2 < NEAR2:
                    b = nd[j]
                    cx += b[0]; cy += b[1]; ax += b[2]; ay += b[3]; n += 1
                    if d2 < SEP2:
                        sx -= dx / (d2 + .5); sy -= dy / (d2 + .5)
            if n:
                a[2] += ((cx / n - a[0]) * .0012 + (ax / n - a[2]) * .04) * g
                a[3] += ((cy / n - a[1]) * .0012 + (ay / n - a[3]) * .04) * g
            a[2] += sx * .9 + (rnd() - .5) * .07 * jit
            a[3] += sy * .9 + (rnd() - .5) * .07 * jit
            if trace and not gathering:  # память: тянется к месту, где была информация
                t = trace[i % len(trace)]
                a[2] += (t[0] - a[0]) * .0025 * t[2]; a[3] += (t[1] - a[1]) * .0025 * t[2]
            if gathering and self.targets:
                p = self.targets[(i * step_t) % len(self.targets)]
                a[2] = (a[2] + (p[0] - a[0]) * .02) * .88
                a[3] = (a[3] + (p[1] - a[1]) * .02) * .88
            if a[0] < 3: a[2] += .08
            if a[0] > W - 4: a[2] -= .08
            if a[1] < 3: a[3] += .08
            if a[1] > H - 4: a[3] -= .08
            sp, mx = math.hypot(a[2], a[3]), (1.2 if gathering else .55 * spd) * (1 + .8 * self.excite)
            if sp > mx:
                a[2] *= mx / sp; a[3] *= mx / sp
            a[0] += a[2]; a[1] += a[3]
            if a[5] > 0:
                a[5] -= 1
            else:
                a[4] += (.004 + rnd() * .003) * chg * (1 + 2 * self.excite)
                if a[4] >= 1:  # вспышка: импульсы соседям
                    a[4], a[5], a[6] = 0, 30, 1.0
                    for d2, j, _, _ in near[i]:
                        if rnd() < .5:
                            self.pulses.append([i, j, 0.0, .06 + rnd() * .05])
            a[6] *= .86
        for t in trace:
            t[2] *= .997
        self.trace = [t for t in trace if t[2] > .05]
        # связи: у каждого узла — три ближайших
        seen = set()
        for i in range(N):
            for d2, j, _, _ in sorted(near[i])[:3]:
                key = (i, j) if i < j else (j, i)
                if key in seen:
                    continue
                seen.add(key)
                a, b = nd[i], nd[j]
                w = (1 - math.sqrt(d2) / LINK) * (.35 + .9 * max(a[6], b[6]))
                self._line(a[0], a[1], b[0], b[1], 55 * w, 25 * w, 130 * w)
        alive = []
        for p in self.pulses:  # импульс с хвостом; дошёл — подзарядил соседа
            p[2] += p[3]
            a, b = nd[p[0]], nd[p[1]]
            if p[2] >= 1:
                b[4] += .35
                continue
            alive.append(p)
            for s, q in ((0, 1), (1, .45), (2, .18)):
                k = p[2] - s * .08
                if k < 0:
                    break
                self._add(a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, 200 * q, 240 * q, 255 * q)
        self.pulses = alive
        hold = self.phase == "hold"
        for a in nd:
            f = a[6]
            c = (40, 110, 255) if hold else (0, 170, 255)
            self._add(a[0], a[1], c[0] + 215 * f, c[1] + 85 * f, c[2])
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                self._add(a[0] + dx, a[1] + dy, 60 * f, 30 + 90 * f, 70 + 150 * f)
        if gathering:  # точки картинки проявляются, пока стая держит форму
            k = min(1, self.tick / 40) if hold else max(0, (self.tick - 180) / 80)
            for x, y in self.targets:
                self._add(x, y, 0, 90 * k, 255 * k)

    def render(self) -> bytearray:
        """Слой стаи за кадр — с яркостью level, без сцены."""
        out = bytearray(W * H * 3)
        lv, acc = self.lv, self.acc
        for j in self.hit:
            if lv > .01:
                for k in (j, j + 1, j + 2):
                    v = int(acc[k] * lv)
                    out[k] = v if v < 256 else 255
            acc[j] = acc[j + 1] = acc[j + 2] = 0.0
        self.hit = []
        return out

    def compose(self, px: bytes) -> bytearray:
        """Кадр сцены и стая под ним: по каждому цвету — ярче из двух; стая — с яркостью level."""
        out = bytearray(px)
        lv, acc = self.lv, self.acc
        for j in self.hit:
            if lv > .01:
                for k in (j, j + 1, j + 2):
                    v = int(acc[k] * lv)
                    if v > out[k]:
                        out[k] = v if v < 256 else 255
            acc[j] = acc[j + 1] = acc[j + 2] = 0.0
        self.hit = []
        return out


def _proc(name: str, target, done, q) -> None:
    signal.set_wakeup_fd(-1)  # обработчики asyncio родителя здесь не нужны
    signal.signal(signal.SIGINT, signal.SIG_IGN)   # Ctrl+C — родителю, он остановит и этот процесс
    signal.signal(signal.SIGTERM, signal.SIG_DFL)  # systemd останавливает всю службу
    shm = shared_memory.SharedMemory(name=name, track=False)  # удаляет память родитель, не этот процесс
    m, nxt = Mind(), time.monotonic()
    while True:
        try:
            while True:
                kind, arg = q.get_nowait()  # gather, stir, mood, imprint
                getattr(m, kind)(arg)
        except queue.Empty:
            pass
        m.target = target.value
        m.step()
        shm.buf[:W * H * 3] = m.render()
        done.value = m.done
        nxt += .02
        d = nxt - time.monotonic()
        if d > 0:
            time.sleep(d)
        else:
            nxt = time.monotonic()


class MindProc:
    """Стая в своём процессе — то же управление, что у Mind; layer() — последний готовый слой."""

    def __init__(self):
        ctx = mp.get_context("fork")  # до запуска матрицы: дочерний процесс её не трогает
        self.shm = shared_memory.SharedMemory(create=True, size=W * H * 3)
        self.target, self.flag, self.q = ctx.Value("d", 1.0), ctx.Value("b", 1), ctx.Queue()
        self.p = ctx.Process(target=_proc, args=(self.shm.name, self.target, self.flag, self.q), daemon=True)
        self.p.start()

    def calm(self, level: float) -> None:
        self.target.value = level

    def gather(self, points: list) -> None:
        self.flag.value = 0
        self.q.put(("gather", points))

    def stir(self, s: float = 1.0) -> None:
        self.q.put(("stir", s))

    def mood(self, name: str) -> None:
        if name != getattr(self, "_mood", None):
            self._mood = name
            self.q.put(("mood", name))

    def imprint(self, points: list) -> None:
        self.q.put(("imprint", points))

    @property
    def done(self) -> bool:
        return bool(self.flag.value)

    def layer(self) -> bytes:
        return bytes(self.shm.buf[:W * H * 3])

    def close(self) -> None:
        self.p.terminate()
        self.p.join(2)
        self.shm.close()
        self.shm.unlink()
