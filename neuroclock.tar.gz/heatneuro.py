"""Экран HEATER в стиле нейросети — порт Hmqtt (hfunct.ino), hsMorph (todayfx.ino) и heaticons.ino с ESP32.

Огонь собирается в HEATER и разлетается угольками; часы внизу собирает сеть. Сеть собирает AIR, температуру
и живые значки по бокам (слева и справа — зеркально и чуть не в фазе): градусник с ртутью по значению;
потом значение со значками перестраивается во влажность (капля, налитая на столько же процентов, с волной),
в CO2 (пузырьки — зелёные, жёлтые, красные по ppm), в STATUS (heating — живой огонь, waiting — песочные
часы) и в MODE (Home — домик с дымом, AUTO — шестерёнка, SLEEP — луна, звёзды и «z»). В конце экран
сгорает целиком. Данные — MQTT термостата: thome, thome1, CO, Wstate, hmode.
"""
from __future__ import annotations

import asyncio
import math
import random

import fx
from clockrow import SMALL_Y, ClockKeeper, now, row_neuro
from matrix import BLUE, GREEN, RED, W, Screen, center_x, morph, text_points

NONE, TEMP, HUM, CO2, FIRE, WAIT, HOME, AUTO, SLEEP = range(9)
HS_X, HS_Y = (0, 54), 8
HOLD = 5
LANE = (2.5, 6.5, 4.5, 7.5, 2)
Z = ((0, 0), (1, 0), (2, 0), (1, 1), (0, 2), (1, 2), (2, 2))


def wrap(v: float, m: float) -> float:
    v = math.fmod(v, m)
    return v + m if v < 0 else v


def lround(v: float) -> int:
    return int(v + .5) if v >= 0 else -int(.5 - v)


def c(r, g, b) -> tuple:
    return (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))


def in_drop(x: float, y: float) -> bool:
    dx, dy = x - 4.5, y - 10.5
    if dx * dx + dy * dy < 3.9 * 3.9:
        return True
    if y < 1.5 or y > 10.5:
        return False
    return abs(dx) < 3.9 * ((y - 1.5) / 9) ** 1.4  # острый носик


class Icon:
    """Значок 10x16 (hsRender)."""

    def __init__(self):
        self.b = [[None] * 10 for _ in range(16)]

    def put(self, x: int, y: int, col) -> None:
        if 0 <= x < 10 and 0 <= y < 16:
            self.b[y][x] = col

    def fire(self, t: float) -> None:  # язык пламени качается, по краям бегут волны, внутри жёлтое ядро
        H = 13 + 1.5 * math.sin(t * 7) + .8 * math.sin(t * 13)
        for y in range(16):
            fy = (15.5 - (y + .5)) / H
            if fy > 1:
                continue
            w = 4.6 * math.sqrt(1 - fy) * (.6 + fy / .15 * .4 if fy < .15 else 1) * (1 + .25 * math.sin(fy * 9 - t * 14))
            cx = 5 + math.sin(t * 5 + fy * 3) * fy * 1.6
            for x in range(10):
                d = abs(x + .5 - cx) / w
                if d >= 1:
                    continue
                h = (1 - d) * (1 - fy * .6) + random.randrange(15) / 100
                self.put(x, y, (255, 240, 150) if h > .75 else (255, 170, 0) if h > .5 else (255, 80, 0) if h > .25 else (180, 20, 0))
        for i in range(2):  # искры
            q = wrap(t * .9 + i * .5, 1)
            self.put(lround(5 + math.sin(t * 4 + i * 2) * 2.5), int(6 - q * 7), c(255, 150 * (1 - q), 0))

    def render(self, kind: int, t: float, val: float) -> list:
        self.b = [[None] * 10 for _ in range(16)]
        put = self.put
        if kind == TEMP:  # градусник: 10…30 °C — от донышка до верха трубки
            top = 10.5 - min(1, max(.1, (val - 10) / 20)) * 9.5 + math.sin(t * 2) * .4
            for y in range(1, 11):
                put(3, y, (90, 95, 110)); put(6, y, (90, 95, 110))
            put(4, 0, (90, 95, 110)); put(5, 0, (90, 95, 110))
            for y in range(2, 9, 2):
                put(8, y, (60, 60, 70))  # деления
            for y in range(1, 11):
                if y + .5 > top:
                    col = (255, 130, 90) if y + .5 - top < 1 else (255, 35, 25)
                    put(4, y, col); put(5, y, col)
            for y in range(10, 16):
                for x in range(10):
                    d = math.hypot(x + .5 - 5, y + .5 - 13)
                    if d < 2.3:
                        put(x, y, (255, 150, 120) if x == 4 and y == 12 else (255, 35, 25))
                    elif d < 3:
                        put(x, y, (90, 95, 110))
        elif kind == HUM:  # капля налита на влажность, по воде бежит волна
            lvl = 14.5 - min(1, max(.05, val / 100)) * 13
            for y in range(16):
                for x in range(10):
                    px, py = x + .5, y + .5
                    if not in_drop(px, py):
                        continue
                    if not in_drop(px - 1, py) or not in_drop(px + 1, py) or not in_drop(px, py - 1) or not in_drop(px, py + 1):
                        put(x, y, (110, 180, 255)); continue
                    s = lvl + math.sin(x * 1.3 + t * 4) * .6
                    if py > s:
                        put(x, y, (90, 170, 255) if py - s < 1 else c(0, 70 - (py - s) * 3, 200 - (py - s) * 6))
            if math.sin(t * 1.7) > .6:
                put(3, 10, (220, 240, 255))  # блик
        elif kind == CO2:  # пузырьки поднимаются
            r, g, b = (255, 60, 40) if val >= 1200 else (240, 200, 0) if val >= 800 else (60, 220, 90)
            for i in range(5):
                p = wrap(t * 3 + i * 3.7, 19)
                cy, cx, rad = 17.5 - p, LANE[i] + math.sin(t * 2.5 + i) * .9, 1.0 if i % 2 else 1.6
                a = min(1, max(0, cy / 4)) if cy < 4 else 1  # у верха тают
                for y in range(16):
                    for x in range(10):
                        d = math.hypot(x + .5 - cx, y + .5 - cy)
                        if (abs(d - rad) < .6) if rad > 1.2 else d < .8:
                            put(x, y, (r * a, g * a, b * a))
        elif kind == FIRE:
            self.fire(t)
        elif kind == WAIT:  # песочные часы, цикл 6 с
            p = wrap(t, 6) / 6
            glass, sand = (0, 120, 140), (230, 170, 40)
            for x in range(1, 9):
                put(x, 0, glass); put(x, 15, glass)
            for y in range(1, 15):
                w = 3.5 - (y - 1) * .5 if y <= 7 else 3.5 - (14 - y) * .5  # полуширина колбы
                put(int(4.5 - w - .5), y, glass); put(int(4.5 + w + .5), y, glass)
                top = 7 >= y >= 2 + 5.5 * p
                bot = y >= 8 and y >= 14 - 5.5 * p
                if top or bot:
                    for x in range(10):
                        if abs(x + .5 - 5) < w - .3:
                            put(x, y, sand)
                if 7 <= y < 14 - 5.5 * p and (y + int(t * 12)) & 1:
                    put(4, y, sand)  # струйка
        elif kind == HOME:
            for y in range(6, 10):  # крыша
                for x in range(10):
                    if abs(x + .5 - 5) <= (y - 6) * 1.4 + .7:
                        put(x, y, (200, 60, 30))
            for y in range(4, 7):
                put(7, y, (150, 70, 40))  # труба
            for y in range(10, 16):
                for x in range(1, 9):
                    put(x, y, (80, 55, 35))
            for y in range(12, 16):
                put(2, y, (40, 25, 15)); put(3, y, (40, 25, 15))  # дверь
            fl = .8 + .2 * math.sin(t * 7) * math.sin(t * 3.1)
            for y in (11, 12):
                for x in (5, 6, 7):
                    put(x, y, (255 * fl, 200 * fl, 60 * fl))  # окно
            for i in range(3):  # дым
                q = wrap(t * .8 + i / 3, 1)
                a = 1 - q
                put(lround(7 + q * 2 + math.sin(t * 3 + i) * .5), int(3.5 - q * 4), (140 * a, 140 * a, 150 * a))
        elif kind == AUTO:  # шестерёнка: 6 зубцов, крутится
            for y in range(16):
                for x in range(10):
                    dx, dy = x + .5 - 5, y + .5 - 8
                    d = math.sqrt(dx * dx + dy * dy)
                    if d < 1.3:
                        continue
                    if d < 3.3:
                        put(x, y, (0, 190, 215)); continue
                    a = wrap(math.atan2(dy, dx) / (2 * math.pi) * 6 - t * 1.5, 1)
                    if d < 4.8 and a < .5:
                        put(x, y, (0, 130, 160))
        elif kind == SLEEP:
            for y in range(10):  # серп
                for x in range(10):
                    dx, dy = x + .5 - 4.5, y + .5 - 5
                    ex, ey = dx - 2.3, dy + 1.1
                    if dx * dx + dy * dy < 14.4 and ex * ex + ey * ey > 9.2:
                        put(x, y, (240, 230, 160))
            s1, s2 = math.sin(t * 2.3), math.sin(t * 2.3 + 2.5)
            if s1 > 0:
                put(8, 1, (255 * s1,) * 3)
            if s2 > 0:
                put(9, 6, (255 * s2,) * 3)
            q = wrap(t * .6, 1)
            a = math.sin(q * math.pi)  # «z» поднимается и тает
            zx, zy = 4 + int(q * 2), 15 - int(q * 5)
            for px, py in Z:
                put(zx + px, zy - 2 + py, (0, 200 * a, 235 * a))
        return self.b


class Heat:
    def __init__(self, scr: Screen):
        self.scr, self.kind, self.val, self.task = scr, NONE, 0.0, None
        self.icon = Icon()

    @staticmethod
    def t() -> float:
        return asyncio.get_running_loop().time() % 3600

    def frame_points(self) -> tuple[list, list]:
        """Первый кадр значков с обеих сторон — точки и цвета (как их рисует hsDraw)."""
        P, C = [], []
        for s in range(2):
            b = self.icon.render(self.kind, self.t() + s * .7, self.val)
            for y in range(16):
                for x in range(10):
                    if b[y][x]:
                        P.append((HS_X[s] + (9 - x if s else x), HS_Y + y)); C.append(b[y][x])
        return P, C

    async def _tick(self) -> None:  # кадр значков раз в 40 мс (hsTick)
        while True:
            for s in range(2):
                b = self.icon.render(self.kind, self.t() + s * .7, self.val)
                for y in range(16):
                    for x in range(10):
                        self.scr.set(HS_X[s] + (9 - x if s else x), HS_Y + y, b[y][x] or (0, 0, 0))
            await asyncio.sleep(.04)

    def stop(self) -> None:
        if self.task:
            self.task.cancel()
            self.task = None

    async def morph(self, y0: int, title: str | None, tc, val: str, vc, kind: int, v: float = 0) -> None:
        """Что горит в строках y0..над часами (значение, значки, при y0 = 0 и заголовок), стекает в сеть, она
        собирает title (None — заголовок не трогается), val и значки kind; дальше значки живут сами (hsMorph)."""
        self.stop()
        P, C = self.scr.lit()
        A = [(p, col) for p, col in zip(P, C) if y0 <= p[1] < SMALL_Y]
        self.kind, self.val = kind, v
        B, cb = [], []
        if title:
            pts = text_points(title, center_x(title), 0)
            B += pts; cb += [tc] * len(pts)
        pts = text_points(val, center_x(val), 12)
        B += pts; cb += [vc] * len(pts)
        ip, ic = self.frame_points()
        await morph(self.scr, [a for a, _ in A], [col for _, col in A], B + ip, cb + ic, area=(0, y0, W, SMALL_Y))
        self.task = asyncio.create_task(self._tick())


def num(v, default: float = 0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


async def heater(scr: Screen, clock, mind) -> None:
    h = clock.heat or {}
    if h.get("st") in (None, ""):  # от термостата ещё ничего (heatDT на ESP)
        return
    t, hu, co = num(h.get("t")), num(h.get("h")), num(h.get("co"))
    ts, hs, cs = f"{round(t * 10) / 10:.1f}C", f"{int(hu + .5)}%", f"{int(co)}PPM"
    heating, mode = int(num(h.get("st"))) == 1, int(num(h.get("mode"), -1))
    mind.calm(.12)
    P = await fx.fire_title_in(scr, "HEATER")
    await scr.hold(2)
    await fx.fire_title_out(scr, P)
    await row_neuro(scr, now().strftime("%H:%M"), GREEN)
    keeper, ht = ClockKeeper(scr), Heat(scr)
    keeper.start()
    try:
        await ht.morph(0, "AIR", RED, ts, BLUE, TEMP, t)  # AIR, температура и градусники
        await scr.hold(HOLD)
        await ht.morph(8, None, 0, hs, BLUE, HUM, hu)     # → влажность с каплями
        await scr.hold(HOLD)
        await ht.morph(8, None, 0, cs, BLUE, CO2, co)     # → CO2 с пузырьками
        await scr.hold(HOLD)
        if heating:                                       # AIR → STATUS
            await ht.morph(0, "STATUS", BLUE, "heating", RED, FIRE)
        else:
            await ht.morph(0, "STATUS", RED, "waiting", BLUE, WAIT)
        await scr.hold(HOLD)
        names = ("Home", "AUTO", "SLEEP")                 # STATUS → MODE
        await ht.morph(0, "MODE", RED, names[mode] if 0 <= mode <= 2 else "", BLUE, HOME + mode if 0 <= mode <= 2 else NONE)
        await scr.hold(HOLD)
    finally:
        ht.stop()
        keeper.stop()
    await fx.fire_out(scr)  # HEATER сгорает целиком, со значками
    mind.calm(1)
