"""Погода — живая сцена во всю ширину над нижней строкой (64x23, строки 0..22) по коду OpenWeatherMap
("01d", "10n" …) — порт icons.ino с ESP32-часов. У солнца вращаются и дышат лучи, ночью мерцают звёзды и
пролетает падающая звезда, облака плывут слоями, дождь с брызгами, косой ливень, молния бьёт в разных
местах, снег кружит, туман тянется полосами. render(kind, t) — кадр в буфер, t — секунды.
"""
from __future__ import annotations

import math

WX_W, WX_H = 64, 23
SUN, MOON, SUNCLOUD, MOONCLOUD, CLOUDS, OVERCAST, SHOWER, RAIN, STORM, SNOW, FOG = range(11)
KINDS = {"01d": SUN, "01n": MOON, "02d": SUNCLOUD, "02n": MOONCLOUD, "03": CLOUDS, "04": OVERCAST,
         "09": SHOWER, "10": RAIN, "11": STORM, "13": SNOW, "50": FOG}
STARS = ((3, 2), (12, 6), (7, 15), (19, 3), (45, 2), (52, 9), (60, 4), (57, 16),
         (48, 19), (40, 6), (2, 10), (62, 12), (14, 20), (36, 1), (28, 19), (54, 1))
CLOUD = ((235, 190, 125), (150, 110, 72), (95, 65, 42))  # белое, серое, тёмное: свет сверху, середина, тень


def kind(code: str) -> int | None:
    """«10n» → сцена «10»; None — такой сцены нет."""
    if not code or len(code) < 2:
        return None
    return KINDS.get(code, KINDS.get(code[:2]))


def wrap(v: float, m: float) -> float:
    v = math.fmod(v, m)
    return v + m if v < 0 else v


def c3(r, g, b) -> tuple:
    return (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))


def lround(v: float) -> int:
    return int(v + .5) if v >= 0 else -int(.5 - v)


Q = 16  # облако сдвигается шагами в 1/16 точки: глазу не отличить, а форма считается один раз (cloud_mask)
CLOUD_C = tuple(tuple(c3(c, c, c + 12) for c in P) for P in CLOUD)
_MASKS: dict = {}


def in_cloud(x, y, cx, cy, sc) -> bool:
    u, v = (x - cx) / sc, (y - cy) / sc
    if v > 3:
        return False
    if (u + 3.2) ** 2 + (v - .8) ** 2 < 2.6 * 2.6:
        return True
    if (u - .2) ** 2 + (v + .8) ** 2 < 3.4 * 3.4:
        return True
    return (u - 3.6) ** 2 + (v - .9) ** 2 < 2.4 * 2.4


def cloud_mask(fx: int, fy: int, sc: float) -> list:
    """Точки облака масштаба sc с центром в (fx/Q, fy/Q) от целой точки: (dx, dy, тон 0 свет / 1 середина / 2 тень).
    Считается один раз на сдвиг — раньше каждый кадр, и пасмурная погода не успевала в кадр на Pi Zero."""
    key = (fx, fy, sc)
    m = _MASKS.get(key)
    if m is None:
        cx, cy, m = fx / Q, fy / Q, []
        for y in range(int(-4.4 * sc) - 2, int(3 * sc) + 3):
            for x in range(int(-6.2 * sc) - 2, int(6.2 * sc) + 3):
                px, py = x + .5, y + .5
                if in_cloud(px, py, cx, cy, sc):
                    m.append((x, y, 0 if not in_cloud(px, py - 1, cx, cy, sc) else 2 if not in_cloud(px, py + 1, cx, cy, sc) else 1))
        _MASKS[key] = m
    return m


class Scene:
    def __init__(self):
        self.b: list = [None] * (WX_W * WX_H)

    def put(self, x: int, y: int, c) -> None:
        if 0 <= x < WX_W and 0 <= y < WX_H:
            self.b[y * WX_W + x] = c

    def cloud(self, cx, cy, sc, shade) -> None:
        ix, iy = math.floor(cx), math.floor(cy)
        fx, fy = round((cx - ix) * Q), round((cy - iy) * Q)
        if fx == Q:
            ix += 1; fx = 0
        if fy == Q:
            iy += 1; fy = 0
        P, b = CLOUD_C[shade], self.b
        for dx, dy, v in cloud_mask(fx, fy, sc):
            x, y = ix + dx, iy + dy
            if 0 <= x < WX_W and 0 <= y < WX_H:
                b[y * WX_W + x] = P[v]

    def drift(self, t, v, ph, cy, sc, shade) -> None:  # плывёт слева направо через весь экран
        self.cloud(wrap(t * v + ph, WX_W + 14 * sc) - 7 * sc, cy, sc, shade)

    def sun(self, cx, cy, R, rays, t) -> None:
        e = int(R + rays + 2)
        for y in range(max(0, int(cy) - e), min(WX_H - 1, int(cy) + e) + 1):
            for x in range(max(0, int(cx) - e), min(WX_W - 1, int(cx) + e) + 1):
                dx, dy = x + .5 - cx, y + .5 - cy
                d = math.sqrt(dx * dx + dy * dy)
                if d < R:
                    self.put(x, y, (255, 130, 0) if d > R - 1 else c3(255, 215 - d * 60 / R, 0))
                    continue
                a = wrap(math.atan2(dy, dx) - t * .6, 2 * math.pi)  # 12 лучей вращаются
                ray = int(a / (math.pi / 6) + .5) % 12
                off = abs(a - ray * (math.pi / 6)) * d
                if ray == 0 and a > math.pi:
                    off = (2 * math.pi - a) * d
                ln = rays * ((.6 if ray & 1 else 1) + .2 * math.sin(t * 4 + ray * 1.3))  # длинные и короткие, дышат
                if off < .6 and R + 1 < d < R + 1 + ln:
                    self.put(x, y, (255, 150, 0) if ray & 1 else (255, 200, 0))

    def moon(self, cx, cy, r) -> None:
        e = int(r) + 1
        for y in range(max(0, int(cy) - e), min(WX_H - 1, int(cy) + e) + 1):
            for x in range(max(0, int(cx) - e), min(WX_W - 1, int(cx) + e) + 1):
                dx, dy = x + .5 - cx, y + .5 - cy
                ex, ey = dx - r * .6, dy + r * .3  # вырез — серп
                if dx * dx + dy * dy < r * r and ex * ex + ey * ey > r * r * .64:
                    self.put(x, y, (190, 175, 100) if dx * dx + dy * dy > (r - 1) ** 2 else (240, 230, 160))

    def stars(self, t, n) -> None:
        for i in range(min(n, 16)):
            b = math.sin(t * (1.6 + (i % 4) * .5) + i * 2.1)
            if b > -.3:
                k = .35 + .65 * max(b, 0)
                self.put(STARS[i][0], STARS[i][1], (255 * k, 255 * k, 235 * k))

    def shooting(self, t) -> None:  # падающая звезда раз в 9 секунд
        p = wrap(t, 9)
        if p > .9:
            return
        k = p / .9
        hx, hy = 58 - k * 40, 1 + k * 9
        for i in range(6):
            a = 1 - i / 6
            self.put(lround(hx + i * 1.6), lround(hy - i * .4), (255 * a, 255 * a, 220 * a))

    def drops(self, n, y0, v, sl, r, g, b, t) -> None:  # капли из-под облаков, внизу брызги
        L = WX_H - y0 + 3
        for i in range(n):
            lane = wrap(i * 13.7 + 5, WX_W + 8)
            y = y0 + wrap(t * v + i * 2.9, L)
            x = lane - (y - y0) * sl
            if y < WX_H - 1:
                self.put(lround(x), int(y), c3(r, g, b))
                self.put(lround(x + sl), int(y) - 1, c3(r * .35, g * .35, b * .45))
            else:
                a = 1 - (y - (WX_H - 1)) / 4
                yy = WX_H - 1 - (a > .6)
                self.put(lround(x) - 1, yy, c3(r * a, g * a, b * a))
                self.put(lround(x) + 1, yy, c3(r * a, g * a, b * a))

    def render(self, k: int, t: float) -> list:
        self.b = [None] * (WX_W * WX_H)
        if k == SUN:
            self.sun(32, 11, 6, 4.5, t)
        elif k == MOON:
            self.stars(t, 16); self.shooting(t); self.moon(32, 11.5, 8.5)
        elif k == SUNCLOUD:
            self.sun(22, 10, 5, 3.5, t); self.drift(t, 1.2, 30, 7, 1.0, 1); self.drift(t, 2.2, 55, 14, 1.6, 0)
        elif k == MOONCLOUD:
            self.stars(t, 12); self.moon(22, 10, 7); self.drift(t, 1.2, 30, 7, 1.0, 1); self.drift(t, 2.2, 55, 14, 1.6, 0)
        elif k == CLOUDS:  # два слоя: дальние серые медленнее, ближние белые быстрее
            self.drift(t, 1, 0, 6, 1.1, 1); self.drift(t, 1, 45, 5, .9, 1)
            self.drift(t, 2, 20, 14, 1.6, 0); self.drift(t, 2, 62, 15, 1.3, 0)
        elif k == OVERCAST:
            for i in range(4):
                self.cloud(8 + i * 16 + 2 * math.sin(t * .4 + i), 6 + (i & 1), 1.5, 2)
            self.drift(t, 1.3, 10, 14, 1.5, 1); self.drift(t, 1.3, 55, 15, 1.3, 1)
        elif k == RAIN:
            self.drops(16, 8, 12, 0, 90, 170, 255, t)
            for i in range(3):
                self.cloud(wrap(t * .8 + i * 24, 72) - 4, 4.5, 1.4, 1 if i == 1 else 0)
        elif k == SHOWER:
            self.drops(28, 8, 20, .35, 0, 110, 255, t)
            for i in range(3):
                self.cloud(wrap(t * 1.2 + i * 24, 72) - 4, 4.5, 1.4, 2 if i == 1 else 1)
        elif k == STORM:
            p, strike = wrap(t, 3.1), int(t / 3.1)
            flash = p < .1 or .18 < p < .28  # двойная вспышка
            if flash and p < .1:
                self.b = [(18, 18, 40)] * (WX_W * WX_H)  # небо озарилось
            self.drops(14, 8, 18, .3, 0, 90, 220, t)
            for i in range(3):
                self.cloud(wrap(t * .9 + i * 24, 72) - 4, 4.5, 1.4, 0 if flash else 2)
            if flash:  # молния — каждый раз в новом месте и своей формы
                x = 10 + (strike * 23) % 44
                for y in range(8, WX_H):
                    self.put(x, y, (255, 245, 160))
                    if (strike * 7 + y * 13) % 5 == 0:
                        self.put(x + 1, y, (255, 220, 90))
                    x += (strike * 7 + y * 13) % 3 - 1
        elif k == SNOW:
            for i in range(18):  # снежинки кружат; крупные — крестиком
                y = 8 + wrap(t * 2.2 + i * 1.7, 16)
                x = lround(wrap(i * 11.3 + math.sin(t * 1.2 + i) * 2.5, WX_W))
                self.put(x, int(y), (230, 240, 255))
                if i % 4 == 0:
                    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        self.put(x + dx, int(y) + dy, (120, 130, 160))
            for i in range(3):
                self.cloud(wrap(t * .6 + i * 24, 72) - 4, 4.5, 1.4, 0)
        elif k == FOG:  # полосы тянутся в разные стороны
            for l in range(7):
                v = (-1 if l & 1 else 1) * (1.2 + l * .3)
                g = 85 + 25 * math.sin(t * .7 + l)
                for x in range(WX_W):
                    if wrap(x + t * v + l * 7, 14) < 10:
                        self.put(x, 2 + l * 3, c3(g, g, g + 12))
        return self.b
