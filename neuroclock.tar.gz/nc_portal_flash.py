"""Update an identified NeuroPortal over USB using an image staged on the Pi."""
from __future__ import annotations

import asyncio
import fcntl
import hashlib
import json
import logging
import re
import shutil
import time
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory

log = logging.getLogger("neuroclock.portal")


@contextmanager
def try_lock(path: Path):
    with path.open("a") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            yield False
        else:
            yield True


def flash_in_progress(data: Path) -> bool:
    with try_lock(data / "portal-flash.lock") as idle:
        return not idle


def usb_serial(port: Path) -> str:
    name = port.resolve().name
    if not re.fullmatch(r"ttyACM[0-9]+", name):
        return ""
    for parent in (Path("/sys/class/tty") / name).resolve().parents:
        try:
            vendor = (parent / "idVendor").read_text().strip()
        except OSError:
            continue
        if vendor != "303a":
            return ""
        try:
            return (parent / "serial").read_text().strip()
        except OSError:
            return ""
    return ""


class PortalFirmware:
    def __init__(self, data: Path):
        self.data = data
        self.staging = data / "portal-firmware"
        self.task: asyncio.Task | None = None
        self.message = ""

    @property
    def busy(self) -> bool:
        return self.task is not None and not self.task.done()

    @staticmethod
    def read(path: Path) -> dict:
        try:
            contents = json.loads(path.read_text())
        except (OSError, ValueError):
            return {}
        return contents if isinstance(contents, dict) else {}

    def esptool(self) -> list[str]:
        python = self.data.parent / "tools/esptool/bin/python"
        if python.is_file():
            return [str(python), "-m", "esptool"]
        executable = shutil.which("esptool") or shutil.which("esptool.py")
        return [executable] if executable else []

    def state(self, report: dict) -> dict:
        manifest = self.read(self.staging / "manifest.json")
        version = manifest.get("version", "")
        ready = bool(version and (self.staging / "neuroportal.bin").is_file() and self.esptool())
        return {"installed": report.get("fw", ""), "available": version if ready else "",
                "connected": bool(report.get("usb_serial")), "busy": self.busy, "message": self.message}

    def start(self, report: dict) -> str:
        if self.busy:
            return "Portal firmware update is already running"
        if not report.get("usb_serial") or not report.get("usb_port"):
            return "Waiting for an identified NeuroPortal over USB"
        if not self.state(report)["available"]:
            return "No Portal firmware or flashing tool is ready"
        self.message = "Preparing Portal…"
        self.task = asyncio.create_task(self.flash(report))
        return ""

    async def write_image(self, args: list[str], port: Path, image: Path) -> None:
        process = await asyncio.create_subprocess_exec(
            *args, "--chip", "esp32s3", "--port", str(port), "--before", "usb_reset", "--after", "hard_reset",
            "write_flash", "0x10000", str(image),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        )
        try:
            output, _ = await asyncio.wait_for(process.communicate(), 100)
        finally:
            if process.returncode is None:
                process.kill()
                await process.wait()
        if process.returncode != 0:
            log.warning("прошивка Portal: %s", output.decode(errors="replace").strip()[-800:])
            raise RuntimeError("Flash failed. See Journal")

    async def flash(self, report: dict) -> None:
        port = Path(report["usb_port"])
        serial = report["usb_serial"]
        try:
            manifest = self.read(self.staging / "manifest.json")
            version = manifest.get("version")
            content = (self.staging / "neuroportal.bin").read_bytes()
            if not isinstance(version, str) or not version.strip() or hashlib.sha256(content).hexdigest() != manifest.get("sha256"):
                raise RuntimeError("Portal firmware checksum or version is invalid")
            with try_lock(self.data / "update.lock") as allowed:
                if not allowed:
                    raise RuntimeError("NeuroClock update is already running")
                with try_lock(self.data / "portal-flash.lock") as exclusive, TemporaryDirectory() as directory:
                    if not exclusive:
                        raise RuntimeError("Portal firmware update is already running")
                    image = Path(directory) / "neuroportal.bin"
                    image.write_bytes(content)
                    for _ in range(50):
                        with try_lock(self.data / "portal-usb.lock") as free:
                            if free:
                                if usb_serial(port) != serial:
                                    raise RuntimeError("Portal disconnected before flashing")
                                self.message = "Writing Portal firmware…"
                                await self.write_image(self.esptool(), port, image)
                                break
                        await asyncio.sleep(.1)
                    else:
                        raise RuntimeError("Portal USB port is busy")
                    written = time.time()
                self.message = "Waiting for Portal to reconnect…"
                for _ in range(25):
                    updated = self.read(self.data / "portal_status.json")
                    if updated.get("usb_serial") == serial and updated.get("fw") == version and updated.get("ts", 0) >= written:
                        self.message = f"Portal firmware {version} verified"
                        log.info("прошивка Portal %s подтверждена после подключения", version)
                        return
                    await asyncio.sleep(1)
                self.message = "Image written. Portal version could not be confirmed"
                log.warning("прошивка Portal записана; версия по USB не подтверждена")
        except (OSError, RuntimeError, asyncio.TimeoutError) as exc:
            self.message = str(exc) or "Portal firmware update timed out"
            log.warning("обновление Portal остановлено: %s", self.message)
