"""Вечер, ночь и утро — порт wakeeyes.ino, eveningIn / clkNeuroBig (clockfx.ino), evn и morning (hfunct.ino).

Глаза рисуются на лету: веко — плавная кривая от дуги к сомкнутой, зрачки смотрят по сторонам, блик,
моргание, «z Z Z» над спящими глазами. Режимы по часам — как getTime / GET_SMODE на ESP (mode_now):
  20:00 — вечер: Сфера → порталы → «Приятного Вам вечера…» → Сфера нейросетью становится большими синими часами,
          изменившиеся цифры пересобирает сеть; яркость — пятая часть дневной;
  23:00 — ночь: «Спокойной ночи…» → Сфера становится открытыми глазами, они засыпают и гаснут; экран тёмный
          до 6:00 в будни, до 10:00 в выходные;
  утро  — сеть неспешно собирает сомкнутые веки, глаза просыпаются и разлетаются искрами, пожелание, тихий
          серый экран (день, температура, часы) — до 8:00 с Wake up или до 10:00; потом день.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import math

import fx
from clockrow import SMALL_Y, colon_small, drip_small, now, row_neuro
from matrix import BIG_X, BIG_Y, BLUE, W, Screen, big_points, center_x, draw_text, morph, text_points
from ticker import Row

GRAY = (48, 48, 48)  # на ESP (16,16,16); у Pi панель вечером и утром ещё и притушена — подобрать на живой
NIGHT_DIM = .2  # вечером и утром яркость — пятая часть дневной (на ESP 10 из 50)
GOOD_NIGHT = "Спокойной ночи друзья! Приятных снов!"
GREETED = False  # глаза уже просыпались при загрузке — утро их не повторяет (bootGreeted)
ON_SLEEP = None  # nc_matrix: после «Спокойной ночи» — погасить панель и отпустить ядро до утра
DAYS2 = ("MO", "TU", "WE", "TH", "FR", "SA", "SU")
EYE_CX, EYE_CY, EYE_RX, EYE_RY = (19, 45), 15.5, 8.5, 6.8


def mode_now(t: dt.datetime, weekend: bool, wake: bool) -> str:
    """day / evening / night / morning — как getTime и GET_SMODE на ESP."""
    h = t.hour
    if h >= 23 or h < (10 if weekend else 6):
        return "night"
    if 10 <= h < 20:
        return "day"
    if h >= 20:
        return "evening"
    return "day" if wake and not weekend and h >= 8 else "morning"


def wish_text(h: int) -> str:
    """Пожелание по части суток (wishText)."""
    if 4 <= h < 12:
        return "С добрым утром друзья! Хорошего вам дня!"
    if 12 <= h < 17:
        return "Привет! Хорошего Вам и продуктивного дня."
    if h >= 17:
        return "Приятного Вам вечера." + (" Перехожу в спокойный вечерний режим работы." if 20 <= h < 23 else "")
    return GOOD_NIGHT


# ---------- глаза ----------
class Eyes:
    def __init__(self, scr: Screen):
        self.scr = scr
        self.k, self.lx, self.ly, self.g, self.pup, self.hl = 1.0, 0.0, 0.0, 1.0, 1.8, .8  # веко, взгляд, яркость

    def _c(self, r, g, b) -> tuple:
        return (max(0, min(255, r * self.g)), max(0, min(255, g * self.g)), max(0, min(255, b * self.g)))

    @staticmethod
    def _closed(dx):
        q = dx / EYE_RX
        return 1.5 + 2.5 * (1 - q * q)

    @staticmethod
    def _arc(dx):
        q = 1 - (dx / EYE_RX) ** 2
        return EYE_RY * math.sqrt(q) if q > 0 else 0

    def _u(self, dx):
        dx = max(-EYE_RX, min(EYE_RX, dx))
        t = -self._arc(dx)
        return t + (self._closed(dx) - t) * self.k

    def _b(self, dx):
        dx = max(-EYE_RX, min(EYE_RX, dx))
        b = self._arc(dx)
        return b + (self._closed(dx) - b) * self.k

    @staticmethod
    def _edge(f, dx, dy) -> bool:
        a, b, c = f(dx - .5), f(dx), f(dx + .5)
        return dy - .5 < max(a, b, c) and dy + .5 >= min(a, b, c)

    def pix(self, dx: float, dy: float):
        if abs(dx) > EYE_RX + .5:
            return None
        if self._edge(self._u, dx, dy):
            return self._c(0, 210, 235)  # кромка верхнего века
        if self.k < .97 and self._edge(self._b, dx, dy):
            return self._c(0, 80, 105)   # нижнее — тусклее
        u = self._u(dx)
        if dy <= u or dy >= self._b(dx):
            return None
        ix, iy = dx - self.lx, dy - self.ly
        r = math.hypot(ix, iy)
        if math.hypot(ix + 1.5, iy + 1.5) < self.hl:
            return self._c(255, 255, 255)  # блик
        if r < self.pup:
            return None                    # зрачок
        if r < 4.3:                        # радужка: светлая у зрачка, тёмный ободок
            if r > 3.6:
                return self._c(0, 70, 120)
            t = (r - self.pup) / (3.6 - self.pup)
            return self._c(0, 230 - 90 * t, 255 - 60 * t)
        sh = max(.35, min(1, (dy - u) / 2.5))  # тень под веком
        return self._c(95 * sh, 105 * sh, 120 * sh)

    def _box(self):
        for cx in EYE_CX:
            for x in range(math.ceil(cx - EYE_RX - 1), math.floor(cx + EYE_RX + 1) + 1):
                for y in range(int(EYE_CY - EYE_RY - 1), int(EYE_CY + EYE_RY + 1.5) + 1):
                    yield x, y, self.pix(x - cx, y - EYE_CY)

    def points(self) -> tuple[list, list]:
        P, C = [], []
        for x, y, c in self._box():
            if c:
                P.append((x, y)); C.append(c)
        return P, C

    def draw(self) -> None:
        for x, y, c in self._box():
            self.scr.set(x, y, c or (0, 0, 0))

    async def to(self, k, lx, ly, frames, ms=18, pup=-1.0) -> None:
        """Плавно к новому положению век и взгляда; pup < 0 — зрачок прежний."""
        k0, x0, y0, p0 = self.k, self.lx, self.ly, self.pup
        pup = p0 if pup < 0 else pup
        for f in range(1, frames + 1):
            e = f / frames
            e = e * e * (3 - 2 * e)
            self.k, self.lx, self.ly, self.pup = k0 + (k - k0) * e, x0 + (lx - x0) * e, y0 + (ly - y0) * e, p0 + (pup - p0) * e
            self.draw()
            await self.scr.frame(ms / 1000)

    async def fade(self, g, frames) -> None:
        g0 = self.g
        for f in range(1, frames + 1):
            self.g = g0 + (g - g0) * f / frames
            self.draw()
            await self.scr.frame(.022)

    def closed(self) -> tuple[list, list]:
        """Сомкнутые веки — точки и цвета: из них сеть собирает глаза."""
        self.k, self.lx, self.ly, self.pup, self.hl, self.g = 1, 0, .5, 2.4, .8, 1
        return self.points()

    async def wake(self, built: bool = False) -> None:
        """Сеть неспешно собирает сомкнутые веки, глаза приоткрываются, сонно открываются, моргают, оглядываются.
        built — веки уже на экране (их выписала стая загрузки, awake.py)."""
        if built:
            self.closed()
        else:
            self.scr.clear()
            P, C = self.closed()
            await morph(self.scr, [], None, P, C, frame=.034)
        await self.scr.hold(.7)
        await self.to(.8, 0, .5, 10, 22)     # приоткрыл…
        await self.to(1, 0, .5, 8, 22)       # …и снова закрыл
        await self.scr.hold(.3)
        await self.to(.45, 0, 0, 24, 22)     # сонно открывает
        await self.scr.hold(.25)
        await self.to(1, 0, 0, 5)            # моргнул
        await self.to(.15, 0, 0, 7)
        await self.to(1, 0, 0, 4)            # и ещё раз
        await self.to(0, 0, 0, 8)            # проснулся
        await self.to(0, -3, -.5, 12, 20, 2.0)  # огляделся, зрачки сужаются — светло
        await self.scr.hold(.25)
        await self.to(0, 3, -.5, 16, 20, 1.6)
        await self.scr.hold(.25)
        await self.to(0, 0, 0, 10, 20)
        for f in range(8):  # блик подмигнул
            self.hl = 1.3 if f < 4 else .8
            self.draw()
            await self.scr.frame(.04)
        await self.scr.hold(.3)

    async def zzz(self) -> None:
        """«z Z Z» поднимаются над правым глазом, глаза дышат."""
        zs = [text_points(z, 0, 0) for z in ("z", "Z", "Z")]
        LIFE, GAP = 40, 20
        prev: list = []
        for f in range(GAP * 2 + LIFE):
            self.g = .75 + .25 * math.cos(f * .18)
            self.draw()
            for x, y in prev:
                self.scr.set(x, y, (0, 0, 0))
            prev = []
            for i, pts in enumerate(zs):
                t = (f - i * GAP) / LIFE
                if not 0 <= t <= 1:
                    continue
                a = math.sin(t * math.pi)
                ox, oy = 56 + t * 2 + math.sin(t * 7) * 1.5, 12 - t * 22
                for px, py in pts:
                    x, y = int(ox + px + .5), int(oy + py + .5)
                    if 0 <= x < W and 0 <= y < 32:
                        self.scr.set(x, y, (0, 200 * a, 235 * a)); prev.append((x, y))
            await self.scr.frame(.025)
        for x, y in prev:
            self.scr.set(x, y, (0, 0, 0))
        self.g = 1

    async def doze(self) -> None:
        """Открытые глаза засыпают: смотрят по сторонам, веки тяжелеют, «Zzz», гаснут."""
        await self.scr.hold(.3)
        await self.to(0, -2.5, .5, 18, 22)    # лениво смотрит в сторону
        await self.to(.35, -2.5, .8, 16, 24)  # веки тяжелеют
        await self.to(.3, 2.5, .8, 22, 24)
        await self.to(.6, 2.5, 1, 18, 26)     # засыпает…
        await self.to(.1, 0, 0, 5)            # встрепенулся
        await self.scr.hold(.2)
        await self.to(.5, 0, .8, 18, 26)
        await self.to(.75, 0, 1, 20, 30)
        await self.to(1, 0, 1, 22, 34)        # уснул
        await self.zzz()
        await self.fade(0, 16)
        self.scr.clear()


# ---------- большие часы ----------
def digits(t: dt.datetime) -> list:
    return [t.hour // 10, t.hour % 10, t.minute // 10, t.minute % 10]


def colon_big(scr: Screen, on: bool, color=BLUE) -> None:
    for y0 in (BIG_Y + 5, BIG_Y + 12):
        scr.fill(BIG_X[1] + 14, y0, 2, 2, color if on else (0, 0, 0))


async def big_neuro(scr: Screen, old: list, new: list, color=BLUE) -> None:
    """Изменившиеся цифры: старые стекают в узлы сети над их клетками, сеть собирает новые (clkNeuroBig).
    Двоеточие гаснет, только если меняется час (оно внутри области сети)."""
    k = next((j for j in range(4) if old[j] != new[j]), 4)
    if k == 4:
        return
    A = [p for j in range(k, 4) for p in big_points(old[j], j)]
    B = [p for j in range(k, 4) for p in big_points(new[j], j)]
    if k <= 1:
        colon_big(scr, False)
    await morph(scr, A, [color] * len(A), B, color, area=(BIG_X[k] - 1, 0, W, 32))


# ---------- режимы ----------
def settled(mode: str, clock) -> bool:
    return mode_now(now(), clock.weekend, getattr(clock, "wake", False)) == mode


async def day_start(scr: Screen, clock, mind) -> None:
    """Начало дня (home на ESP): пожелание бегущей строкой между вихревыми порталами."""
    scr.dim = 1.0
    mind.calm(.15)
    scr.clear()
    await Row(scr, 12).run(wish_text(now().hour), BLUE, neuro=False)


async def evening(scr: Screen, clock, mind) -> None:
    """20:00 (NREG, eveningIn, evn): экран растворяется в сети; Сфера → порталы → пожелание → большие часы."""
    scr.dim = NIGHT_DIM
    mind.calm(.08)
    A, C = scr.lit()
    if A:
        await morph(scr, A, C, [], None)
    scr.clear()
    shown = digits(now())
    B = [p for j, d in enumerate(shown) for p in big_points(d, j)]
    await Row(scr, 12).run(wish_text(now().hour), BLUE, B=B, cb=BLUE)
    while settled("evening", clock):
        d = digits(now())
        if d != shown:
            await big_neuro(scr, shown, d)
            shown = d
        colon_big(scr, now().second % 2 == 0)
        await scr.hold(.25)
    A, C = scr.lit()  # дальше — ночь (или день): часы растворяются в сети
    await morph(scr, A, C, [], None)
    scr.clear()


async def night(scr: Screen, clock, mind) -> None:
    """23:00 (slep, nightOut): Сфера → порталы → «Спокойной ночи…» → Сфера становится глазами, они засыпают и
    гаснут. Потом экран и стая тёмные, пока не наступит утро."""
    scr.dim = NIGHT_DIM
    mind.calm(.05)
    scr.clear()
    eyes = Eyes(scr)
    eyes.k, eyes.lx, eyes.ly, eyes.pup, eyes.hl, eyes.g = 0, 0, 0, 1.8, .8, 1
    P, C = eyes.points()
    await Row(scr, 12).run(GOOD_NIGHT, BLUE, B=P, cb=C)
    eyes.draw()
    await eyes.doze()
    mind.calm(0)
    if ON_SLEEP:  # служба выйдет и до утра будет только смотреть на часы — панель не обновляется
        ON_SLEEP()
    while settled("night", clock):  # превью и запасной путь: тёмный экран
        await scr.hold(5)


async def morning(scr: Screen, clock, mind) -> None:
    """Утро (morning): глаза просыпаются и разлетаются искрами, пожелание; тихий серый экран — день недели,
    температура, часы; каждые 10 с температура и погода словом сменяют друг друга."""
    global GREETED
    scr.dim = NIGHT_DIM
    mind.calm(.04)
    if GREETED:
        GREETED = False
        A, C = scr.lit()
        await morph(scr, A, C, [], None)
    else:
        await Eyes(scr).wake()
        await fx.scatter_out(scr)
    await Row(scr, 12).run(wish_text(now().hour), GRAY, neuro=False)
    scr.clear()
    w = clock.weather or {}
    t = now()
    today = f"{t.day:02d} {DAYS2[t.weekday()]}"
    temp = f"{w['temp1']:.1f}C" if "temp1" in w else ""
    atmos = w.get("main", "")
    await type_text(scr, today, 0, GRAY)
    await type_text(scr, temp, 12, GRAY)
    shown = t.strftime("%H:%M")
    await row_neuro(scr, shown, GRAY)
    show_temp, t0 = True, asyncio.get_running_loop().time()
    while settled("morning", clock):
        t = now()
        hm = t.strftime("%H:%M")
        if hm != shown:
            colon_small(scr, True, GRAY)
            await drip_small(scr, shown, hm, GRAY)
            shown = hm
        colon_small(scr, t.second % 2 == 0, GRAY)
        if asyncio.get_running_loop().time() - t0 > 10 and atmos:  # температура ↔ погода словом
            a, b = (temp, atmos) if show_temp else (atmos, temp)
            await split_out(scr, a, 12, GRAY)
            await come_in(scr, b, 12, GRAY)
            show_temp, t0 = not show_temp, asyncio.get_running_loop().time()
        await scr.hold(.25)
    A, C = scr.lit()
    await morph(scr, A, C, [], None)
    scr.clear()


# ---------- серые строки утра (type / hCenter / sCenter) ----------
async def type_text(scr: Screen, text: str, y: int, color, ms: float = .05) -> None:
    """Печатается по букве, под следующей мигает курсор."""
    x0 = center_x(text)
    scr.fill(0, y, W, 8)
    for i, ch in enumerate(text):
        draw_text(scr, ch, x0 + i * 6, y, color)
        await scr.frame(ms)
        scr.fill(x0 + (i + 1) * 6, y + 6, 6, 2, color)
        await scr.frame(ms / 2)
        scr.fill(x0 + (i + 1) * 6, y + 6, 6, 2)


async def split_out(scr: Screen, text: str, y: int, color) -> None:
    """Строка делится на две копии, они расходятся за края (hCenter)."""
    x0, w = center_x(text), len(text) * 6
    for off in range(0, W // 2 + w + 1, 3):
        scr.fill(0, y, W, 8)
        draw_text(scr, text, x0 - off, y, color); draw_text(scr, text, x0 + off, y, color)
        await scr.frame(.03)
    scr.fill(0, y, W, 8)


async def come_in(scr: Screen, text: str, y: int, color) -> None:
    """Две копии строки съезжаются с краёв и встают в одну по центру (sCenter)."""
    x0 = center_x(text)
    left, right = -len(text) * 6, W
    while left < x0 or right > x0:
        left, right = min(x0, left + 3), max(x0, right - 3)
        scr.fill(0, y, W, 8)
        draw_text(scr, text, left, y, color); draw_text(scr, text, right, y, color)
        await scr.frame(.03)
