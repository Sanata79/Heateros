#!/usr/bin/env python3
"""Системные настройки Pi для NeuroClock — то, что лежит вне релиза (/boot/firmware, /etc) и обновлением само
не меняется. Запускается после каждого обновления (nc_update.py) и вручную: python3 ~/nc/current/nc_system.py.

Сверяет с эталоном и выравнивает, ничего не трогая лишнего (меняемые файлы — с копией рядом, .nc-ГГГГММДД-ЧЧММ):
  /boot/firmware/config.txt   dtparam=audio=off (звук занимает ШИМ матрицы), dtoverlay=disable-bt (Bluetooth
                              делит радио с Wi-Fi — без него связь заметно лучше);
  /boot/firmware/cmdline.txt  isolcpus=3 — ядро только для обновления панели;
  модуль звука snd_bcm2835 — в чёрном списке (dtparam его не выключает), Wi-Fi без энергосбережения,
  постоянный журнал до 50 МБ, служба матрицы neuroclock-matrix — как в релизе;
  /etc/NetworkManager/dispatcher.d/50-neuroclock-wifi-ht — Wi-Fi без обрыва раз в минуту (см. WIFI_HT);
  /etc/NetworkManager/dnsmasq-shared.d/neuroclock-captive.conf — на точке доступа NeuroClock любое имя → часы
  (телефон сам открывает страницу); служба neuroclock-wifi-watch — сторож Wi-Fi (nc_wifi.py --watch);
  apt-daily(-upgrade).service.d/neuroclock-idle.conf — обновления системы самым низким приоритетом (APT_IDLE).
Библиотеку матрицы (~/nc/mvenv) только проверяет: собирается 20 минут — это руками (README). Итог — в
data/system.json: что поменялось, нужна ли перезагрузка (настройки загрузки), чего не хватает; его показывает веб.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = Path(os.getenv("NEUROCLOCK_DATA", "/home/sasha/nc/data"))
BOOT = Path("/boot/firmware")
STAMP = dt.datetime.now().strftime("%Y%m%d-%H%M")
# Драйвер Wi-Fi Zero 2 W (brcmfmac) при загрузке иногда не объявляет 802.11n, а связь с роутером идёт в n. Ядро через
# минуту после каждой смены страны проверяет канал (reg_check_chans_work), считает его недопустимым и рвёт связь;
# при обрыве страна ставится заново — и так по кругу каждые 61 с. Перечитать возможности чипа драйвер даёт только
# при настоящей смене страны: при подключении Wi-Fi, если n не объявлен, — на миг другая страна и обратно.
WIFI_HT = """#!/bin/sh
# NeuroClock (nc_system.py): Wi-Fi без обрыва раз в минуту — драйвер перечитывает 802.11n.
[ "$1" = wlan0 ] && [ "$2" = up ] || exit 0
iw phy phy0 info | grep -q HT20 && exit 0
c=$(iw reg get | awk '/^global/ {g=1} g && /^country/ {print substr($2, 1, 2); exit}')
[ -n "$c" ] && [ "$c" != 00 ] || c=RU
o=DE; [ "$c" = DE ] && o=GB
iw reg set $o; sleep 1; iw reg set $c
logger -t neuroclock "Wi-Fi: 802.11n перечитан (страна $c)"
"""
# Обновления системы (раз в день около 6:00; если часы были выключены — вскоре после включения) — самым низким
# приоритетом процессора и диска: идут только на том, что не нужно матрице, и не роняют кадры.
APT_IDLE = """[Service]
# NeuroClock (nc_system.py): обновления — только на свободном от часов процессоре
Nice=19
CPUSchedulingPolicy=idle
IOSchedulingClass=idle
"""
FILES = {  # файл → нужное содержимое целиком
    "/etc/modprobe.d/blacklist-rgb-matrix.conf": "blacklist snd_bcm2835\n",
    "/etc/NetworkManager/conf.d/99-wifi-powersave-off.conf": "[connection]\nwifi.powersave = 2\n",
    "/etc/systemd/journald.conf.d/neuroclock.conf": "[Journal]\nStorage=persistent\nSystemMaxUse=50M\n",
    "/etc/NetworkManager/dispatcher.d/50-neuroclock-wifi-ht": WIFI_HT,
    "/etc/NetworkManager/dnsmasq-shared.d/neuroclock-captive.conf": "address=/#/10.42.0.1\n",
    "/etc/systemd/system/apt-daily.service.d/neuroclock-idle.conf": APT_IDLE,
    "/etc/systemd/system/apt-daily-upgrade.service.d/neuroclock-idle.conf": APT_IDLE,
}
UNITS = ("neuroclock-matrix", "neuroclock-wifi-watch")  # службы из релиза: ставятся, включаются, запускаются


def sudo(*cmd: str, inp: str | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(["sudo", "-n", *cmd], input=inp, text=True, capture_output=True)


def read(p: str) -> str:
    try:
        return Path(p).read_text()
    except OSError:
        return ""


def write(p: str, text: str) -> None:
    """Через sudo: копия прежнего рядом (кроме dispatcher.d — там NetworkManager запустил бы и копию), новое — целиком."""
    if Path(p).exists() and "dispatcher.d" not in p:
        sudo("cp", "-p", p, f"{p}.nc-{STAMP}")
    sudo("mkdir", "-p", str(Path(p).parent))
    sudo("tee", p, inp=text)


def config_txt(changed: list) -> bool:
    p = str(BOOT / "config.txt")
    lines = read(p).splitlines()
    if not lines:
        return False
    new, have_bt = [], False
    for ln in lines:
        if ln.strip() == "dtparam=audio=on":
            ln = "dtparam=audio=off"
        have_bt |= ln.strip() == "dtoverlay=disable-bt"
        new.append(ln)
    if "dtparam=audio=off" not in (s.strip() for s in new):
        new.append("dtparam=audio=off")
    if not have_bt:
        last = next((s.strip() for s in reversed(new) if s.strip().startswith("[")), "[all]")
        if last != "[all]":  # дописать в общий раздел, а не в раздел другой модели
            new.append("[all]")
        new.append("dtoverlay=disable-bt")
    if new == lines:
        return False
    write(p, "\n".join(new) + "\n")
    changed.append("config.txt: audio off, Bluetooth off")
    return True


def cmdline_txt(changed: list) -> bool:
    p = str(BOOT / "cmdline.txt")
    line = read(p).strip()
    if not line or "isolcpus=3" in line.split():
        return False
    write(p, line + " isolcpus=3")  # одна строка, без перевода строки в конце — как было
    changed.append("cmdline.txt: isolcpus=3")
    return True


def files(changed: list) -> bool:
    boot = False
    for p, text in FILES.items():
        if read(p) == text:
            continue
        write(p, text)
        changed.append(p)
        if "modprobe" in p:
            sudo("update-initramfs", "-u")
            boot = True
        elif "journald" in p:
            sudo("mkdir", "-p", "/var/log/journal")
            sudo("systemd-tmpfiles", "--create", "--prefix", "/var/log/journal")
            sudo("systemctl", "restart", "systemd-journald")
        elif "dispatcher.d" in p:
            sudo("chmod", "755", p)  # NetworkManager запускает только исполняемые, root
        elif "NetworkManager" in p:
            sudo("systemctl", "reload", "NetworkManager")
        elif "/etc/systemd/system/" in p:
            sudo("systemctl", "daemon-reload")
    return boot


def units(changed: list, missing: list) -> None:
    lib = subprocess.run(["/home/sasha/nc/mvenv/bin/python", "-c", "import rgbmatrix"], capture_output=True)
    if lib.returncode != 0:
        missing.append("matrix library (~/nc/mvenv)")
    for name in UNITS:
        src, dst = HERE / f"{name}.service", f"/etc/systemd/system/{name}.service"
        if not src.exists():
            continue
        if read(dst) != src.read_text():
            write(dst, src.read_text())
            sudo("systemctl", "daemon-reload")
            changed.append(f"{name}.service")
        if sudo("systemctl", "is-enabled", name).stdout.strip() != "enabled":
            sudo("systemctl", "enable", name)
            changed.append(f"{name} enabled")
        if (name != "neuroclock-matrix" or lib.returncode == 0) and sudo("systemctl", "is-active", name).stdout.strip() != "active":
            sudo("systemctl", "start", name)


def main() -> int:
    if sudo("true").returncode != 0:
        print("нужен sudo без пароля для sasha")
        return 1
    changed, missing = [], []
    boot = config_txt(changed)
    boot |= cmdline_txt(changed)
    boot |= files(changed)
    units(changed, missing)
    prev = {}
    try:
        prev = json.loads((DATA / "system.json").read_text())
    except Exception:
        pass
    # перезагрузка нужна, пока не перезагрузились после правки загрузки
    up = float(read("/proc/uptime").split()[0] or 0)
    since = dt.datetime.now().timestamp() - up
    reboot = boot or (prev.get("reboot", False) and prev.get("boot_changed_at", 0) > since)
    st = {"ts": dt.datetime.now().strftime("%Y-%m-%d %H:%M"), "changed": changed, "missing": missing, "reboot": reboot,
          "boot_changed_at": dt.datetime.now().timestamp() if boot else prev.get("boot_changed_at", 0)}
    (DATA / "system.json").write_text(json.dumps(st, ensure_ascii=False, indent=1))
    print(json.dumps(st, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
