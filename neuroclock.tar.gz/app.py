#!/usr/bin/env python3
"""NeuroClock на Raspberry Pi Zero 2 W — пока без матрицы: веб часов и фоновые службы.

Та же страница «table», что у ESP32-часов (System, Setup, MQTT, Status, Sync), тот же JSON /api/state и
/api/set. Фоном: курсы ЦБ, погода OpenWeatherMap, производственный календарь (или дни недели), MQTT на
домашний брокер (сообщения Лины и датчики NEWOS), состояние синхронизации времени и системы.

Настройки — data/settings.json, учётные данные брокера — data/mqtt.json (chmod 600, не в коде).
Запуск: служба systemd neuroclock.service (порт 80).
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import os
import re
import shutil
import signal
import subprocess
import time
from pathlib import Path

import aiohttp
from aiohttp import web
import paho.mqtt.client as mqtt

HERE = Path(__file__).resolve().parent
DATA = Path(os.getenv("NEUROCLOCK_DATA", HERE / "data"))
PORT = int(os.getenv("NEUROCLOCK_PORT", "80"))
try:
    VERSION = (HERE / "VERSION").read_text().strip()  # пишет tools/release.sh
except OSError:
    VERSION = "dev"

CBR_URL = "https://www.cbr-xml-daily.ru/daily_json.js"
OWM_URL = ("http://api.openweathermap.org/data/2.5/weather?lat=59.89&lon=30.26&units=metric&lang=ru"
           "&appid=96c7cdd8ed88cc64ae4b4fd95c674eba")  # тот же запрос, что у ESP32-часов, по-русски
CAL_URL = "https://production-calendar.ru/get-period/{token}/ru/{date}/json"
TOPIC_ROOT = "user_579c2bbc/"
TOPICS = ["Lina1", "Lina2", "Lina3", "thome", "thome1", "CO", "Wstate", "hmode"]

# панель матрицы — те же умолчания, что у nc_matrix.py; значения из веба проверяются здесь
MATRIX_DEFAULTS = {"enabled": True, "mapping": "adafruit-hat", "brightness": 40, "limit_hz": 0, "panel_type": "",
                   "slowdown": 2, "pwm_bits": 11, "multiplexing": 0, "row_addr_type": 0}
MATRIX_CHOICES = {"limit_hz": (0, 100, 120, 150, 200), "panel_type": ("", "FM6126A", "FM6127"),
                  "mapping": ("adafruit-hat", "adafruit-hat-pwm"), "slowdown": (1, 2, 3, 4)}
DEFAULTS = {"wake": False, "autoupd": False, "prcall": True, "auth": "4f29f369544cfa4af9a6b6e2ee9d862f",
            "mqh": "192.168.0.50", "mqp": 1883, "diag": True, "diag_ai": True}

# диагностика (diag_run): ночью, пока часы спят, и по кнопке CHECK; итог — в топик OPUS и на матрицу (SYSTEM)
DIAG_AT = (3, 0)
OPUS = "OPUS"
MANIFEST = "https://raw.githubusercontent.com/Sanata79/Heateros/refs/heads/main/neuroclock.json"

# запасная точка доступа (nc_wifi.py): пока она поднята, матрица вместо сообщений Лины подсказывает, куда подключаться
AP_NAME, AP_SSID, AP_IP = "NeuroClock-AP", "NeuroClock", "10.42.0.1"
AP_LINA = {"Lina1": "Wi-Fi|Сети нет. Подключись к Wi-Fi NeuroClock, пароль neuroclock, страница 10.42.0.1",
           "Lina2": "", "Lina3": ""}

log = logging.getLogger("neuroclock")


class Clock:
    def __init__(self):
        DATA.mkdir(parents=True, exist_ok=True)
        self.settings = {**DEFAULTS, **self._load("settings.json")}
        self.sync = {"wsync": "no sync", "sync": "no sync", "msync": "no sync", "nsync": "no sync",
                     "rsync": "", "dsync": "", "ssync": "no connect", "hsync": "no sensor"}
        self.weather: dict = {}
        self._ap, self._ap_ts = False, 0.0
        self.ap_uuid = ""  # профиль точки доступа — в таблицу сетей не попадает
        self.currency: dict = {}
        self.mq: dict = {}  # последние сообщения MQTT: топик → текст
        self.weekend = False
        self.client: mqtt.Client | None = None
        self.download: dict = {}  # образ, который сейчас уходит в браузер
        self._cpu_prev = self._cpu_times()
        self.diag: dict = self._load("diag.json")  # последняя диагностика
        self.diag_lock = asyncio.Lock()

    # ---------- настройки ----------
    def _load(self, name: str) -> dict:
        try:
            return json.loads((DATA / name).read_text())
        except Exception:
            return {}

    def save(self):
        tmp = DATA / "settings.json.tmp"
        tmp.write_text(json.dumps(self.settings, ensure_ascii=False, indent=1))
        tmp.replace(DATA / "settings.json")

    # ---------- система ----------
    @staticmethod
    def meminfo() -> tuple[int, int]:
        info = {}
        try:
            for line in Path("/proc/meminfo").read_text().splitlines():
                k, v = line.split(":", 1)
                info[k] = int(v.split()[0]) * 1024
        except Exception:
            pass
        return info.get("MemAvailable", 0), info.get("MemTotal", 1)

    def hotspot(self) -> bool:
        """Поднята ли точка доступа NeuroClock (адрес 10.42.0.1 на wlan0) — проверка не чаще раза в 5 с."""
        now = time.monotonic()
        if now - self._ap_ts > 5:
            self._ap_ts, self._ap = now, AP_IP + "/" in self._cmd("ip", "-4", "-o", "addr", "show", "wlan0")
        return self._ap

    @staticmethod
    def rssi() -> int:
        try:
            for line in Path("/proc/net/wireless").read_text().splitlines()[2:]:
                return int(float(line.split()[3]))
        except Exception:
            pass
        return -100

    @staticmethod
    def cpu_temp() -> float:
        try:
            return int(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000
        except Exception:
            return 0.0

    @staticmethod
    def _cpu_times() -> tuple[int, int]:
        try:
            v = [int(x) for x in Path("/proc/stat").read_text().split("\n", 1)[0].split()[1:]]
            return sum(v), v[3] + v[4]  # всего, простой (idle + iowait)
        except Exception:
            return 0, 0

    def cpu_percent(self) -> float:
        """Загрузка процессора с прошлого опроса (страница спрашивает раз в секунду)."""
        total, idle = self._cpu_times()
        pt, pi = self._cpu_prev
        self._cpu_prev = (total, idle)
        return round(100 * (1 - (idle - pi) / (total - pt)), 1) if total > pt else 0.0

    @staticmethod
    def uptime() -> float:
        try:
            return float(Path("/proc/uptime").read_text().split()[0])
        except Exception:
            return time.monotonic()

    @staticmethod
    def _cmd(*args) -> str:
        try:
            return subprocess.run(args, capture_output=True, text=True, timeout=3).stdout.strip()
        except Exception:
            return ""

    @staticmethod
    def _read(path: str) -> str:
        try:
            return Path(path).read_text().strip().strip("\x00")
        except Exception:
            return ""

    def power(self) -> str:
        """vcgencmd get_throttled: просадка питания и троттлинг — сейчас и с момента загрузки."""
        raw = self._cmd("vcgencmd", "get_throttled")
        try:
            bits = int(raw.split("=")[1], 16)
        except Exception:
            return "unknown"
        now = [n for b, n in ((0, "LOW VOLTAGE"), (1, "freq capped"), (2, "throttled"), (3, "hot limit")) if bits >> b & 1]
        was = [n for b, n in ((16, "low voltage"), (17, "freq capped"), (18, "throttled"), (19, "hot limit")) if bits >> b & 1]
        if now:
            return "NOW: " + ", ".join(now)
        return "ok" + (" (was " + ", ".join(was) + ")" if was else "")

    def info(self) -> dict:
        """Паспорт системы для Info table — по запросу страницы, не каждую секунду."""
        os_name = next((l.split("=", 1)[1].strip('"') for l in self._read("/etc/os-release").splitlines()
                        if l.startswith("PRETTY_NAME=")), "")
        link = {k.strip(): v.strip() for k, v in (l.split(":", 1) for l in self._cmd("/usr/sbin/iw", "dev", "wlan0", "link").splitlines() if ":" in l)}
        ip = self._cmd("hostname", "-I").split()
        freq = self._read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
        sd = self._read("/sys/block/mmcblk0/size")
        volt = self._cmd("vcgencmd", "measure_volts", "core").replace("volt=", "")
        load = os.getloadavg()
        return {
            "Model": self._read("/proc/device-tree/model").replace("Raspberry Pi", "RPi"),
            "OS": os_name.replace("GNU/Linux ", ""),
            "Kernel": os.uname().release,
            "Host": os.uname().nodename + ".local",
            "IP": ip[0] if ip else "",
            "Wi-Fi": f"{link.get('SSID', '')} {link.get('freq', '').split('.')[0]} MHz",
            "Speed": link.get("tx bitrate", "").replace("MBit/s", "Mbit/s"),
            "CPU": f"{os.cpu_count()} cores {int(freq) // 1000 if freq.isdigit() else '?'} MHz",
            "Core V": volt,
            "Power": self.power(),
            "Load": " ".join(f"{x:.2f}" for x in load),
            "SD card": f"{int(sd) * 512 / 1e9:.1f} GB" if sd.isdigit() else "",
            "Python": ".".join(map(str, os.sys.version_info[:3])),
            "App": "NeuroClock " + VERSION,
        }

    def mode(self) -> str:  # как у ESP32-часов: ночь 23–6, утро до 8 (Wake Up в будни) или до 10, вечер с 20
        h = dt.datetime.now().hour
        if h >= 23 or h < 6:
            return "night"
        if h < (8 if self.settings["wake"] and not self.weekend else 10):
            return "morning"
        return "evening" if h >= 20 else "midday"

    def state(self) -> dict:
        free, total = self.meminfo()
        now = dt.datetime.now()
        self.sync["rsync"] = self.mode()
        return {**self.sync, "frhp": free, "totalHeap": total, "rssi": self.rssi(),
                "mqst": self.sync["ssync"], "wake": self.settings["wake"], "autoupd": self.settings["autoupd"],
                "prcall": self.settings["prcall"], "auth": self.settings["auth"], "mqh": self.settings["mqh"],
                "mqp": self.settings["mqp"], "ver": VERSION, "time": now.strftime("%H:%M"),
                "date": now.strftime("%d.%m.%Y"), "epoch": time.time(),
                "tzoff": int(now.astimezone().utcoffset().total_seconds()), "cpuTemp": round(self.cpu_temp(), 1),
                "ctemp": round(self.cpu_temp(), 1), "cpu": self.cpu_percent(), "uptime": int(self.uptime()),
                "disk": round(100 * (lambda u: u.used / u.total)(shutil.disk_usage("/")), 1),
                "load": round(os.getloadavg()[0], 2), "weather": self.weather, "currency": self.currency,
                "lina": AP_LINA if self.hotspot() else {t: self.mq.get(TOPIC_ROOT + t, "") for t in ("Lina1", "Lina2", "Lina3")},
                "hotspot": self.hotspot(),
                "heat": {k: self.mq.get(TOPIC_ROOT + t) for k, t in
                         (("t", "thome"), ("h", "thome1"), ("co", "CO"), ("st", "Wstate"), ("mode", "hmode"))},
                "room": self._load("room_demo.json"),  # пробные значения комнаты (SYSTEM), пока не приехал BME280
                "diagAuto": self.settings["diag"], "diagAi": self.settings["diag_ai"],
                "opus": {k: self.diag.get(k) for k in ("text", "level", "ts", "epoch")} if self.diag else {},
                "update": self._load("update.json"),
                "matrix": {**MATRIX_DEFAULTS, **self._load("matrix.json")}, "mstat": self._load("matrix_status.json"),
                "system": self._load("system.json"),
                "backup": {**self._load("backup.json"), "download": self.download}}

    # ---------- MQTT ----------
    def mqtt_start(self):
        if self.client:
            try:
                self.client.loop_stop(); self.client.disconnect()
            except Exception:
                pass
        cred = self._load("mqtt.json")
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="neuroclock")
        if cred.get("username"):
            c.username_pw_set(cred["username"], cred.get("password"))

        def on_connect(client, userdata, flags, rc, props=None):
            self.sync["ssync"] = "connected" if rc == 0 else f"error {rc}"
            if rc == 0:
                client.subscribe([(TOPIC_ROOT + t, 0) for t in TOPICS])

        def on_disconnect(client, userdata, flags, rc, props=None):
            self.sync["ssync"] = "no connect"

        def on_message(client, userdata, msg):
            self.mq[msg.topic] = msg.payload.decode("utf-8", "replace")
            self.sync["msync"] = dt.datetime.now().strftime("%H:%M")
            if msg.topic.endswith(("/thome", "/thome1", "/CO")):
                self.sync["hsync"] = "NEWOS ok"

        c.on_connect, c.on_disconnect, c.on_message = on_connect, on_disconnect, on_message
        c.reconnect_delay_set(2, 60)
        c.connect_async(self.settings["mqh"], int(self.settings["mqp"]), 30)
        c.loop_start()
        self.client = c

    # ---------- фоновые задачи ----------
    async def every(self, seconds: int, fn):
        """fn раз в seconds; не вышло (сеть ещё не поднялась после включения, сервер молчит) — повтор через 30 с,
        потом через 1, 2, 4… минуты, но не реже обычного интервала (на ESP курсы — раз в 30 с до успеха)."""
        retry = 30
        while True:
            try:
                await fn()
                retry = 30
                await asyncio.sleep(seconds)
            except Exception as exc:
                log.warning("%s: %s — повтор через %d с", fn.__name__, exc, retry)
                await asyncio.sleep(retry)
                retry = min(retry * 2, seconds)

    async def get_currency(self):
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
            async with s.get(CBR_URL) as r:
                d = json.loads(await r.text())
        cur = {}
        for code in ("USD", "EUR"):
            v = d["Valute"][code]
            cur[code] = {"value": round(v["Value"], 2), "delta": round(v["Value"] - v["Previous"], 2)}
        self.currency = cur
        self.sync["sync"] = dt.datetime.now().strftime("%H:%M")

    async def get_weather(self):
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
                async with s.get(OWM_URL) as r:
                    d = await r.json()
                try:  # прогноз на завтра — для матрицы, как getForecast на ESP
                    fc = await self.get_forecast(s)
                except Exception as exc:
                    log.debug("forecast: %s", exc)
                    fc = {"fok": False}
            hm = lambda ts: dt.datetime.fromtimestamp(ts).strftime("%H:%M")
            self.weather = {"town": d["name"], "temp": round(d["main"]["temp"]), "hum": d["main"]["humidity"],
                            "press": round(d["main"]["pressure"] * 0.750062), "wind": d["wind"]["speed"],
                            "main": d["weather"][0]["main"], "desc": d["weather"][0]["description"],
                            "icon": d["weather"][0]["icon"], "feels": round(d["main"]["feels_like"]),
                            "sunrise": hm(d["sys"]["sunrise"]), "sunset": hm(d["sys"]["sunset"]),
                            "lat": d["coord"]["lat"], "lon": d["coord"]["lon"],
                            "temp1": round(d["main"]["temp"], 1), "wdeg": d["wind"].get("deg", 0), **fc}
            self.sync["wsync"] = "sync: ok"
        except Exception:
            self.sync["wsync"] = "sync: error"
            raise

    @staticmethod
    async def get_forecast(s) -> dict:
        """Завтра (5 day / 3 hour, 48 часов вперёд): мин/макс температура, иконка и описание ближе к 13:00."""
        async with s.get(OWM_URL.replace("/weather?", "/forecast?") + "&cnt=16") as r:
            d = await r.json()
        tz = d["city"]["timezone"]
        tomorrow = (int(time.time()) + tz) // 86400 + 1
        tmin, tmax, best, icon, desc = 100.0, -100.0, 99, "", ""
        for e in d["list"]:
            local = e["dt"] + tz
            if local // 86400 != tomorrow:
                continue
            tmin, tmax = min(tmin, e["main"]["temp_min"]), max(tmax, e["main"]["temp_max"])
            dist = abs(local % 86400 // 3600 - 13)
            if dist < best:
                best, icon, desc = dist, e["weather"][0]["icon"], e["weather"][0]["description"]
        if best == 99:
            return {"fok": False}
        sg = lambda t: f"+{round(t)}" if round(t) > 0 else str(round(t))
        return {"fok": True, "fIcon": icon, "fDesc": desc, "fRange": f"{sg(tmin)}/{sg(tmax)}C"}

    async def get_day(self):
        today = dt.date.today()
        self.weekend = today.weekday() >= 5
        self.sync["dsync"] = ("weekend" if self.weekend else "working") + " n_pc"
        if not self.settings["prcall"]:
            return
        url = CAL_URL.format(token=self.settings["auth"], date=today.strftime("%d.%m.%Y"))
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
            async with s.get(url) as r:
                d = await r.json(content_type=None)
        day = d["days"][0]
        self.weekend = day["type_id"] not in (1, 5)
        self.sync["dsync"] = f"{'weekend' if self.weekend else 'working'} {day.get('working_hours', 0)} hours"

    async def get_ntp(self):
        # метку держит сам timesyncd, пока время сверено; timedatectl будил бы службу и писал 4 строки в журнал
        ok = Path("/run/systemd/timesync/synchronized").exists()
        self.sync["nsync"] = "sync ok" if ok else "no sync"


clock = Clock()


async def page(request):
    return web.FileResponse(HERE / "web" / "index.html", headers={"Cache-Control": "no-cache"})


async def bg(request):  # фон страницы; в ссылке ?v=N — сменили картинку, сменили N
    return web.FileResponse(HERE / "web" / "bg.jpg", headers={"Cache-Control": "max-age=31536000, immutable"})


async def api_state(request):
    return web.json_response(clock.state())


def start_update() -> bool:
    """Проверка обновления — отдельной службой (nc_update.py): она же перезапустит часы и при сбое откатит."""
    r = subprocess.run(["sudo", "-n", "systemctl", "start", "--no-block", "neuroclock-update-now"], capture_output=True)
    return r.returncode == 0


async def api_update(request):
    return web.Response(text="ok") if start_update() else web.Response(status=500, text="no updater")


BACKUP_CMD = "sync; sudo -n fstrim / >/dev/null 2>&1; sudo -n dd if=/dev/mmcblk0 bs=4M status=none | gzip -1"


MATRIX_STOP = "sudo -n systemctl stop neuroclock-matrix"
MATRIX_START = "sudo -n sh -c 'touch /run/neuroclock-matrix.quick; systemctl start neuroclock-matrix'"  # без заставки


async def sh(cmd: str) -> None:
    p = await asyncio.create_subprocess_shell(cmd)
    await p.wait()


async def matrix_notice() -> None:
    """Матрица сообщает о копировании (SIGUSR1) — ждём, пока она погаснет (до 30 с). Ночью, выключенная
    или без службы — сразу."""
    st = clock._load("matrix_status.json")
    if st.get("mode") not in ("matrix", "dry") or time.time() - st.get("ts", 0) > 40:
        return
    await sh("sudo -n systemctl kill -s USR1 neuroclock-matrix")
    for _ in range(60):
        await asyncio.sleep(.5)
        if clock._load("matrix_status.json").get("mode") == "backup":
            return


async def api_backup_image(request):
    """Полный образ SD-карты прямо в браузер (dd | gzip): файл сохраняется на устройстве, где нажали кнопку.
    Одновременно — только один образ; закрыли вкладку — dd останавливается. Пока идёт образ, матрица
    остановлена (панель тёмная): Pi занята только копированием и не перегревается; потом матрица — снова."""
    if clock.download.get("running"):
        return web.Response(status=409, text="backup already running")
    name = f"neuroclock-{dt.datetime.now():%Y%m%d-%H%M}.img.gz"
    resp = web.StreamResponse(headers={"Content-Type": "application/gzip",
                                       "Content-Disposition": f'attachment; filename="{name}"', "Cache-Control": "no-store"})
    await resp.prepare(request)
    clock.download = {"running": True, "sent": 0, "name": name, "started": dt.datetime.now().strftime("%H:%M")}
    await matrix_notice()
    await sh(MATRIX_STOP)
    proc = await asyncio.create_subprocess_shell(BACKUP_CMD, stdout=asyncio.subprocess.PIPE, start_new_session=True)
    ok = False
    try:
        while chunk := await proc.stdout.read(256 * 1024):
            await resp.write(chunk)
            clock.download["sent"] += len(chunk)
        ok = await proc.wait() == 0
        await resp.write_eof()
    except (ConnectionResetError, asyncio.CancelledError):
        raise
    finally:
        if proc.returncode is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        clock.download = {"running": False, "name": name, "sent": clock.download.get("sent", 0),
                          "result": "ok" if ok else "stopped", "ts": dt.datetime.now().strftime("%d.%m %H:%M")}
        asyncio.create_task(sh(MATRIX_START))  # и после обрыва тоже
    return resp


async def api_info(request):
    return web.json_response(clock.info())


# Журнал Pi (systemd-journald, на карте не больше 50 МБ — nc_system.py) — только читаем, на странице последние строки.
JOURNAL = {  # фильтр → аргументы journalctl
    "all": [],
    "err": ["-p", "warning"],
    "wifi": ["-t", "wpa_supplicant", "-t", "NetworkManager", "-t", "neuroclock"],
    "nc": ["-u", "neuroclock", "-u", "neuroclock-matrix", "-u", "neuroclock-update", "-u", "neuroclock-update-now",
           "-t", "neuroclock"],
}
JOURNAL_NOISE = ("sudo", "sshd-session", "systemd-logind")  # наши sudo и SSH-входы — не события часов
JOURNAL_SESSION = ("user@1000", "user-1000", "user-runtime-dir@1000", "run-user-1000", "session-", "Session ")  # и их след


async def journalctl(*args: str) -> str:
    p = await asyncio.create_subprocess_exec("journalctl", "-q", "--no-pager", *args,
                                             stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
    try:
        out, _ = await asyncio.wait_for(p.communicate(), 8)
    except asyncio.TimeoutError:
        p.kill()
        return ""
    return out.decode(errors="replace")


async def api_journal(request):
    f = request.query.get("f", "all")
    f = f if f in JOURNAL else "all"
    raw = await journalctl("-o", "json", "-n", "400", "--output-fields=PRIORITY,SYSLOG_IDENTIFIER,MESSAGE,_COMM,_UID",
                           *JOURNAL[f])
    lines = []
    for ln in raw.splitlines():
        try:
            e = json.loads(ln)
        except ValueError:
            continue
        who = e.get("SYSLOG_IDENTIFIER") or e.get("_COMM") or "?"
        msg = e.get("MESSAGE")
        if isinstance(msg, list):  # не UTF-8 — journalctl отдаёт байты
            msg = bytes(msg).decode(errors="replace")
        session = who in ("systemd", "(sd-pam)") and (e.get("_UID") not in (None, "0") or any(k in msg for k in JOURNAL_SESSION))
        if not msg or f == "all" and (who in JOURNAL_NOISE or session):  # systemd пользователя — только на время SSH
            continue
        ts = dt.datetime.fromtimestamp(int(e.get("__REALTIME_TIMESTAMP", 0)) / 1e6)
        lines.append({"t": ts.strftime("%d.%m %H:%M:%S"), "w": who, "m": msg[:300], "p": int(e.get("PRIORITY", 6))})
    lines = lines[-80:][::-1]  # новые сверху
    usage = await journalctl("--disk-usage")
    size = next((w for w in usage.split() if w[:1].isdigit()), "?")
    wifi = await journalctl("-b", "-o", "cat", "-t", "wpa_supplicant")
    boots = await journalctl("--list-boots")
    return web.json_response({"lines": lines, "size": size, "limit": "50M",
                              "drops": wifi.count("CTRL-EVENT-DISCONNECTED"),
                              "boots": len([b for b in boots.splitlines() if b.strip()])})


async def api_set(request):
    form = await request.post()
    k, v = form.get("k", ""), str(form.get("v", "")).strip()
    s = clock.settings
    if k in ("btn1", "btn2", "btn3"):
        key = {"btn1": "wake", "btn2": "autoupd", "btn3": "prcall"}[k]
        was = s[key]
        s[key] = v == "1"
        if k == "btn2" and s[key] and not was:  # включили Auto update — сразу проверка, как у ESP32-часов
            clock.save()
            start_update()
        if k == "btn3":
            asyncio.create_task(clock.get_day())
    elif k == "diag":  # ночная диагностика вкл/выкл
        s["diag"] = v == "1"
    elif k == "diag_ai":  # нашлась проблема — разбирается Claude (задача в приложении Claude на Маке, 3:30)
        s["diag_ai"] = v == "1"
    elif k == "auth":
        s["auth"] = v
    elif k == "mqh":
        if not v or len(v) > 63:
            return web.Response(status=400, text="bad host")
        s["mqh"] = v
    elif k == "mqp":
        if not v.isdigit() or not 0 < int(v) < 65536:
            return web.Response(status=400, text="bad port")
        s["mqp"] = int(v)
    elif k.startswith("m_"):  # панель Matrix: пишется в data/matrix.json, служба матрицы подхватывает сама
        return set_matrix(k[2:], v)
    else:
        return web.Response(status=400, text="unknown key")
    clock.save()
    if k in ("mqh", "mqp"):
        clock.mqtt_start()
    return web.Response(text="ok")


def set_matrix(key: str, v: str):
    m = {**MATRIX_DEFAULTS, **clock._load("matrix.json")}
    if key == "enabled":
        m[key] = v == "1"
    elif key == "brightness":
        if not v.isdigit() or not 1 <= int(v) <= 100:
            return web.Response(status=400, text="bad brightness")
        m[key] = int(v)
    elif key in MATRIX_CHOICES:
        val = int(v) if isinstance(MATRIX_CHOICES[key][0], int) and v.isdigit() else v
        if val not in MATRIX_CHOICES[key]:
            return web.Response(status=400, text="bad value")
        m[key] = val
    else:
        return web.Response(status=400, text="unknown key")
    tmp = DATA / "matrix.json.tmp"
    tmp.write_text(json.dumps(m, indent=1))
    tmp.replace(DATA / "matrix.json")
    return web.Response(text="ok")


# ---------- Wi-Fi: таблица сетей NetworkManager (Connection → Wi-Fi) ----------
# Пароль идёт через stdin: sudo пишет в журнал только «sh -c … uuid», nmcli получает пароль уже от root-оболочки;
# страница его обратно не получает никогда. Переход на сеть — nc_wifi.py отдельной службой: не вышло — откат.
NM = ("sudo", "-n", "nmcli")
PSK_SET = ("sudo", "-n", "sh", "-c", 'exec nmcli con modify uuid "$1" wifi-sec.psk "$(cat)"', "_")


async def run(*args: str, stdin: str | None = None, timeout: float = 20) -> tuple[int, str, str]:
    p = await asyncio.create_subprocess_exec(*args, stdin=asyncio.subprocess.PIPE if stdin is not None else None,
                                             stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    try:
        out, err = await asyncio.wait_for(p.communicate(stdin.encode() if stdin is not None else None), timeout)
    except asyncio.TimeoutError:
        p.kill()
        return -1, "", "timeout"
    return p.returncode, out.decode(errors="replace"), err.decode(errors="replace")


def nm_fields(line: str) -> list[str]:
    """Строка nmcli -t: поля через «:», внутри поля «\\:» и «\\\\»."""
    out, cur, esc_ = [], "", False
    for ch in line:
        if esc_:
            cur += ch; esc_ = False
        elif ch == "\\":
            esc_ = True
        elif ch == ":":
            out.append(cur); cur = ""
        else:
            cur += ch
    return out + [cur]


async def wifi_saved() -> list[dict]:
    if not clock.ap_uuid:
        _, u, _ = await run(*NM, "-g", "connection.uuid", "con", "show", AP_NAME)
        clock.ap_uuid = u.strip()
    _, out, _ = await run(*NM, "-t", "-f", "UUID,TYPE,AUTOCONNECT,AUTOCONNECT-PRIORITY,ACTIVE", "con", "show")
    nets = []
    for ln in out.splitlines():
        f = nm_fields(ln)
        if len(f) < 5 or f[1] != "802-11-wireless":
            continue
        if f[0] == clock.ap_uuid:
            continue
        _, s, _ = await run(*NM, "-g", "802-11-wireless.ssid,802-11-wireless-security.key-mgmt", "con", "show", "uuid", f[0])
        g = (s.splitlines() + ["", ""])[:2]
        nets.append({"uuid": f[0], "ssid": g[0], "open": not g[1], "auto": f[2] == "yes",
                     "prio": int(f[3]) if f[3].lstrip("-").isdigit() else 0, "active": f[4] == "yes"})
    return sorted(nets, key=lambda n: -n["prio"])


async def wifi_near(rescan: str = "no") -> list[dict]:
    """rescan: yes — искать заново (кнопка SCAN), auto — если прошлому поиску больше 30 с (открыли панель), no — что есть.
    На точке доступа Wi-Fi искать не может — тогда список, запомненный перед её подъёмом (data/wifi_scan.json)."""
    if clock.hotspot():
        return clock._load("wifi_scan.json").get("near", [])
    _, out, _ = await run(*NM, "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", rescan, timeout=30)
    seen: dict[str, dict] = {}
    for ln in out.splitlines():
        f = nm_fields(ln)
        if len(f) < 3 or not f[0]:
            continue
        sig = int(f[1]) if f[1].isdigit() else 0
        if f[0] == AP_SSID:
            continue
        if f[0] not in seen or sig > seen[f[0]]["signal"]:
            seen[f[0]] = {"ssid": f[0], "signal": sig, "sec": f[2]}
    return sorted(seen.values(), key=lambda n: -n["signal"])


async def api_wifi(request):
    scan = {"1": "yes", "auto": "auto"}.get(request.query.get("scan", ""), "no")
    saved, near = await wifi_saved(), await wifi_near(scan)
    sig = {n["ssid"]: n["signal"] for n in near}
    for n in saved:
        n["signal"] = sig.get(n["ssid"])
    names = {n["ssid"] for n in saved}
    _, ip, _ = await run("ip", "-4", "-o", "addr", "show", "wlan0")
    ip = next((w.split("/")[0] for w in ip.split()[3:4]), "")
    now = {"ssid": next((n["ssid"] for n in saved if n["active"]), ""), "ip": ip}  # живое: wifi.json — итог переключения
    return web.json_response({"saved": saved, "near": [n for n in near if n["ssid"] not in names][:8],
                              "status": clock._load("wifi.json"), "now": now, "hotspot": clock.hotspot()})


async def wifi_try(uuid: str, fresh: bool) -> web.Response:
    """Переход (или с uuid="--ap" — точка доступа) — службой neuroclock-wifi: одна за раз."""
    args = ["sudo", "-n", "systemd-run", "--unit=neuroclock-wifi", "--collect", "--quiet", f"--setenv=NEUROCLOCK_DATA={DATA}",
            "/usr/bin/python3", str(HERE / "nc_wifi.py"), uuid] + (["--new"] if fresh else [])
    rc, _, err = await run(*args)
    if rc:
        return web.Response(status=409, text="switch already in progress" if "exist" in err else err.strip()[:200])
    return web.Response(text="ok")


WIFI_LOCK = asyncio.Lock()  # nmcli modify на Pi — до 8 с (netplan): два быстрых нажатия иначе перепутают порядок


async def api_wifi_set(request):
    async with WIFI_LOCK:
        return await wifi_set(await request.post())


async def wifi_set(form):
    op = form.get("op", "")
    saved = await wifi_saved()
    by = {n["uuid"]: n for n in saved}
    if op == "add":  # mode=connect — пробуем сразу (с откатом); mode=save — для другого места, подключится там сам
        ssid, psk, mode = str(form.get("ssid", "")).strip(), str(form.get("psk", "")), form.get("mode", "connect")
        if not 0 < len(ssid.encode()) <= 32:
            return web.Response(status=400, text="network name: 1–32 bytes")
        if psk and not (8 <= len(psk) <= 63 and all(" " <= c <= "~" for c in psk)
                        or len(psk) == 64 and all(c in "0123456789abcdefABCDEF" for c in psk)):
            return web.Response(status=400, text="password: 8–63 Latin characters")
        if psk != psk.strip():
            return web.Response(status=400, text="password: no spaces at the start or end")
        same = next((n for n in saved if n["ssid"] == ssid), None)
        prio = max([n["prio"] for n in saved] + [0]) + 1
        if same:  # такая сеть уже есть — меняется пароль, сеть встаёт первой
            uuid = same["uuid"]
            rc, _, err = await run(*NM, "con", "modify", "uuid", uuid, "connection.autoconnect-priority", str(prio),
                                   *(["wifi-sec.key-mgmt", "wpa-psk", "wifi-sec.psk-flags", "0"] if psk and same["open"] else []))
        else:
            sec = next((n["sec"] for n in await wifi_near() if n["ssid"] == ssid), "")
            km = "sae" if "WPA3" in sec and "WPA2" not in sec and "WPA1" not in sec else "wpa-psk"
            rc, out, err = await run(*NM, "con", "add", "type", "wifi", "ifname", "wlan0", "con-name", ssid, "ssid", ssid,
                                     "autoconnect", "yes" if mode == "save" else "no", "connection.autoconnect-priority", str(prio),
                                     *(["wifi-sec.key-mgmt", km, "wifi-sec.psk-flags", "0"] if psk else []))
            uuid = next((w.strip("()") for w in out.split() if len(w.strip("()")) == 36 and w.count("-") == 4), "")
        if rc or not uuid:
            return web.Response(status=500, text=(err.strip() or "nmcli failed")[:200])
        if psk:
            rc, _, err = await run(*PSK_SET, uuid, stdin=psk)
            if rc:
                if not same:
                    await run(*NM, "con", "delete", "uuid", uuid)
                return web.Response(status=500, text="password not saved")
        log.info("Wi-Fi: сеть %s %s", ssid, "обновлена" if same else "добавлена")
        if mode == "save":
            if same and not same["auto"]:
                await run(*NM, "con", "modify", "uuid", uuid, "connection.autoconnect", "yes")
            return web.Response(text="saved")
        return await wifi_try(uuid, fresh=not same or not same["auto"])
    if op == "hotspot":
        if clock.hotspot():
            return web.Response(status=409, text="the hotspot is already on")
        log.warning("Wi-Fi: точка доступа — кнопкой из веба")
        return await wifi_try("--ap", False)
    uuid = str(form.get("uuid", ""))
    if op == "use":
        if uuid not in by:
            return web.Response(status=404, text="no such network")
        return await wifi_try(uuid, fresh=not by[uuid]["auto"])
    if op == "del":
        if uuid not in by:
            return web.Response(status=404, text="no such network")
        if by[uuid]["active"]:
            return web.Response(status=409, text="this network is in use — switch to another first")
        if len(saved) < 2:
            return web.Response(status=409, text="the last network cannot be deleted")
        rc, _, err = await run(*NM, "con", "delete", "uuid", uuid)
        log.info("Wi-Fi: сеть %s удалена", by[uuid]["ssid"])
        return web.Response(text="ok") if rc == 0 else web.Response(status=500, text=err.strip()[:200])
    if op == "order":  # сверху вниз — от высшего приоритета
        order = [u for u in str(form.get("uuids", "")).split(",") if u in by]
        if sorted(order) != sorted(by):
            return web.Response(status=400, text="bad order")
        for i, u in enumerate(order):  # все заново: сравнение со старым приоритетом и подвело 06.11 (оба стали 1)
            await run(*NM, "con", "modify", "uuid", u, "connection.autoconnect-priority", str(len(order) - i))
        return web.Response(text="ok")
    return web.Response(status=400, text="unknown op")


async def api_reboot(request):
    """Перезагрузка Pi кнопкой из веба: ответ уходит, через секунду — reboot."""
    log.warning("перезагрузка из веба")
    asyncio.get_running_loop().call_later(1, lambda: subprocess.Popen(["sudo", "-n", "systemctl", "reboot"]))
    return web.Response(text="ok")


async def api_shutdown(request):
    """Выключение Pi кнопкой из веба (штатно — карта не пострадает): через секунду — poweroff."""
    log.warning("выключение из веба")
    asyncio.get_running_loop().call_later(1, lambda: subprocess.Popen(["sudo", "-n", "systemctl", "poweroff"]))
    return web.Response(text="ok")


# ---------- диагностика: NeuroClock за сутки и связь с брокером ----------
def _since(text: str) -> dt.datetime | None:
    """«03.11 03:15» (без года) → дата; в будущем — значит, прошлый год."""
    try:
        d = dt.datetime.strptime(text.strip()[:11], "%d.%m %H:%M").replace(year=dt.date.today().year)
    except ValueError:
        return None
    return d.replace(year=d.year - 1) if d > dt.datetime.now() + dt.timedelta(days=1) else d


def _ver(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", v or ""))


async def diag_run(manual: bool = False) -> dict:
    """Проверка за сутки: что у часов не так. Каждый пункт — ok / warn / bad и короткий текст; итог — худший.
    Итог публикуется в топик OPUS («Opus|текст», retain) и показывается в конце экрана SYSTEM."""
    items = []

    def add(name: str, lvl: str, text: str) -> None:
        items.append({"k": name, "lvl": lvl, "t": text})

    m = await journalctl("--since", "-24h", "-u", "neuroclock-matrix", "-o", "cat")
    drops = re.findall(r"просадка до (\d+) кадр/с[^;]*?сцены: ([^;\n]*)", m)
    if drops:
        worst = min(int(f) for f, _ in drops)
        sc = {}
        for _, names in drops:
            for n in names.split(", "):
                sc[n] = sc.get(n, 0) + 1
        top = ", ".join(n for n, _ in sorted(sc.items(), key=lambda x: -x[1])[:2])
        add("Кадры", "bad" if worst < 35 or len(drops) > 20 else "warn" if worst < 45 or len(drops) > 3 else "ok",
            f"просадок {len(drops)}, худшая до {worst} кадр/с ({top})")
    else:
        add("Кадры", "ok", "без просадок")
    crashed = re.findall(r"сцена (\w+) упала", m)
    if crashed:
        add("Сцены", "bad", f"падали: {', '.join(sorted(set(crashed)))} ({len(crashed)} раз)")
    rc, act, _ = await run("systemctl", "is-active", "neuroclock-matrix")
    ms = clock._load("matrix_status.json")
    if act.strip() != "active":
        add("Матрица", "bad", f"служба матрицы: {act.strip() or 'не запущена'}")
    elif ms.get("mode") == "error":
        add("Матрица", "bad", f"ошибка панели: {ms.get('error', '')[:80]}")
    else:
        add("Матрица", "ok", f"{ms['fps']} кадр/с" if ms.get("fps") else "работает")

    w = await journalctl("--since", "-24h", "-t", "wpa_supplicant", "-o", "cat")
    cuts = w.count("CTRL-EVENT-DISCONNECTED")
    ap = (await journalctl("--since", "-24h", "-t", "neuroclock", "-o", "cat")).count("точка доступа NeuroClock поднята")
    add("Wi-Fi", "bad" if ap else "warn" if cuts > 3 else "ok",
        (f"точка доступа поднималась {ap} раз; " if ap else "") + (f"обрывов {cuts}" if cuts else "без обрывов")
        + f", сигнал {clock.rssi()} дБм")

    th = clock._cmd("vcgencmd", "get_throttled").strip().split("=")[-1]
    try:
        tv = int(th, 16)
    except ValueError:
        tv = 0
    t = clock.cpu_temp()
    if tv & 0x10001:
        add("Питание", "bad", "была просадка питания — блок питания или провод слабые")
    elif tv & 0xE000E:
        add("Питание", "warn", "процессор сбавлял частоту (жарко или мало питания)")
    else:
        add("Питание", "ok", "без просадок")
    add("Нагрев", "bad" if t >= 75 else "warn" if t >= 68 else "ok", f"процессор {t:.0f} °C")

    du = shutil.disk_usage("/")
    pct = 100 * du.used / du.total
    add("Карта", "bad" if pct >= 90 else "warn" if pct >= 80 else "ok", f"занято {pct:.0f} %, свободно {du.free / 1e9:.1f} ГБ")

    bk = _since(clock._load("backup.json").get("data", ""))
    if bk is None:
        add("Копия", "warn", "резервной копии настроек ещё не было")
    else:
        days = (dt.datetime.now() - bk).days
        add("Копия", "warn" if days >= 3 else "ok", f"настройки на Маке — {bk:%d.%m}" + (f", {days} дн. назад" if days else ""))

    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as ses:
            async with ses.get(MANIFEST, params={"t": str(int(time.time()))}) as r:
                gh = json.loads(await r.text()).get("version", "")
        if _ver(gh) > _ver(VERSION):
            add("Версия", "warn", f"на GitHub новее: {gh} (на часах {VERSION})")
        elif _ver(gh) < _ver(VERSION):
            add("Версия", "warn", f"на часах {VERSION}, на GitHub {gh} — залить в GitHub")
        else:
            add("Версия", "ok", f"{VERSION}, как на GitHub")
    except Exception:
        add("Версия", "warn", f"{VERSION}; GitHub не ответил")

    errs = [ln for ln in (await journalctl("--since", "-24h", "-u", "neuroclock", "-p", "err", "-o", "cat")).splitlines() if ln.strip()]
    if errs:
        add("Веб", "warn", f"ошибок {len(errs)}: {errs[-1][:60]}")

    mq = clock.sync.get("ssync")
    add("MQTT", "ok" if mq == "connected" else "bad", "связь с брокером есть" if mq == "connected"
        else f"нет связи с брокером {clock.settings['mqh']}")

    rank = {"ok": 0, "warn": 1, "bad": 2}
    level = max((i["lvl"] for i in items), key=rank.get, default="ok")
    if level == "ok":
        text = f"Всё в порядке: {ms.get('fps', 50)} кадр/с, {t:.0f} °C, Wi-Fi без обрывов, MQTT на связи"
    else:
        bad = sorted((i for i in items if i["lvl"] != "ok"), key=lambda i: -rank[i["lvl"]])
        text = "; ".join(f"{i['k']}: {i['t']}" for i in bad)
    now = dt.datetime.now()
    res = {"ts": now.strftime("%d.%m %H:%M"), "epoch": time.time(), "level": level, "text": text[:280],
           "items": items, "manual": manual}
    clock.diag = res
    tmp = DATA / "diag.json.tmp"
    tmp.write_text(json.dumps(res, ensure_ascii=False, indent=1))
    tmp.replace(DATA / "diag.json")
    if clock.client and mq == "connected":
        clock.client.publish(TOPIC_ROOT + OPUS, "Opus|" + res["text"], qos=0, retain=True)
    log.info("диагностика: %s — %s", level, res["text"])
    return res


async def diag_tick() -> None:
    """Раз в минуту: в 3:00–3:10, пока часы спят, — ночная проверка (если включена и сегодня ещё не было)."""
    now = dt.datetime.now()
    if not clock.settings.get("diag") or not (DIAG_AT <= (now.hour, now.minute) < (DIAG_AT[0], DIAG_AT[1] + 10)):
        return
    last = clock.diag.get("epoch", 0)
    if dt.date.fromtimestamp(last) == now.date() and not clock.diag.get("manual"):
        return
    if dt.datetime.fromtimestamp(last) >= now.replace(hour=DIAG_AT[0], minute=DIAG_AT[1], second=0):
        return
    async with clock.diag_lock:
        await diag_run()


async def api_opus(request):
    """Вывод Claude к последней проверке (когда она нашла проблему): заменяет текст отчёта — на страницу, в топик
    OPUS и на матрицу. Поля: text (до 280 знаков), level ok / warn / bad."""
    form = await request.post()
    text, level = str(form.get("text", "")).strip()[:280], str(form.get("level", "")).strip()
    if not text or level not in ("ok", "warn", "bad") or not clock.diag:
        return web.Response(status=400, text="need text, level ok|warn|bad and a check to answer")
    clock.diag = {**clock.diag, "text": text, "level": level, "by": "claude", "epoch": time.time(),
                  "ts_claude": dt.datetime.now().strftime("%d.%m %H:%M")}
    tmp = DATA / "diag.json.tmp"
    tmp.write_text(json.dumps(clock.diag, ensure_ascii=False, indent=1))
    tmp.replace(DATA / "diag.json")
    if clock.client and clock.sync.get("ssync") == "connected":
        clock.client.publish(TOPIC_ROOT + OPUS, "Opus|" + text, qos=0, retain=True)
    log.info("Claude о диагностике: %s — %s", level, text)
    return web.Response(text="ok")


async def api_diag(request):
    if request.method == "POST":
        if clock.diag_lock.locked():
            return web.Response(status=409, text="already running")
        async with clock.diag_lock:
            return web.json_response(await diag_run(manual=True))
    return web.json_response(clock.diag)


async def on_start(app):
    clock.mqtt_start()
    for sec, fn in ((1800, clock.get_currency), (600, clock.get_weather), (3600, clock.get_day), (60, clock.get_ntp),
                    (60, diag_tick)):
        asyncio.create_task(clock.every(sec, fn))


@web.middleware
async def captive(request, handler):
    """Телефон на точке доступа проверяет интернет (captive.apple.com, connectivitycheck…) — DNS точки отвечает
    адресом часов на любое имя; чужое имя → сюда, на страницу часов: телефон сам показывает её окном входа."""
    if request.remote and request.remote.startswith("10.42.0.") and request.host.split(":")[0] != AP_IP:
        raise web.HTTPFound(f"http://{AP_IP}/")
    return await handler(request)


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    app = web.Application(middlewares=[captive])
    app.router.add_get("/", page)
    app.router.add_get("/bg.jpg", bg)
    app.router.add_get("/api/state", api_state)
    app.router.add_post("/api/set", api_set)
    app.router.add_get("/api/info", api_info)
    app.router.add_get("/api/journal", api_journal)
    app.router.add_get("/api/diag", api_diag)
    app.router.add_post("/api/diag", api_diag)
    app.router.add_post("/api/opus", api_opus)
    app.router.add_post("/api/update", api_update)
    app.router.add_get("/api/wifi", api_wifi)
    app.router.add_post("/api/wifi", api_wifi_set)
    app.router.add_post("/api/reboot", api_reboot)
    app.router.add_post("/api/shutdown", api_shutdown)
    app.router.add_get("/api/backup/image", api_backup_image)
    app.router.add_get("/ping", lambda r: web.Response(text="ok"))
    app.on_startup.append(on_start)
    web.run_app(app, port=PORT, access_log=None)


if __name__ == "__main__":
    main()
