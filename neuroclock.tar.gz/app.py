#!/usr/bin/env python3
"""NeuroClock на Raspberry Pi Zero 2 W — пока без матрицы: веб часов и фоновые службы.

Та же страница «table», что у ESP32-часов (System, Setup, MQTT, Status, Sync), тот же JSON /api/state и
/api/set. Фоном: курсы ЦБ, погода OpenWeatherMap, производственный календарь (или дни недели), MQTT на
домашний брокер (сообщения Лины и датчики NEWOS), состояние синхронизации времени и системы.

Настройки — data/settings.json, учётные данные брокера — data/mqtt.json (chmod 600, не в коде).
Запуск: служба systemd neuroclock.service (порт 80).
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

import aiohttp
from aiohttp import web
import paho.mqtt.client as mqtt

HERE = Path(__file__).resolve().parent
DATA = Path(os.getenv("NEUROCLOCK_DATA", HERE / "data"))
PORT = int(os.getenv("NEUROCLOCK_PORT", "80"))
try:
    VERSION = (HERE / "VERSION").read_text().strip()  # пишет tools/release.sh
except OSError:
    VERSION = "dev"

CBR_URL = "https://www.cbr-xml-daily.ru/daily_json.js"
OWM_URL = ("http://api.openweathermap.org/data/2.5/weather?lat=59.89&lon=30.26&units=metric"
           "&appid=96c7cdd8ed88cc64ae4b4fd95c674eba")  # тот же запрос, что у ESP32-часов
CAL_URL = "https://production-calendar.ru/get-period/{token}/ru/{date}/json"
TOPIC_ROOT = "user_579c2bbc/"
TOPICS = ["Lina1", "Lina2", "Lina3", "thome", "thome1", "CO", "Wstate", "hmode"]

DEFAULTS = {"wake": False, "autoupd": False, "prcall": True, "auth": "4f29f369544cfa4af9a6b6e2ee9d862f",
            "mqh": "192.168.0.50", "mqp": 1883}

log = logging.getLogger("neuroclock")


class Clock:
    def __init__(self):
        DATA.mkdir(parents=True, exist_ok=True)
        self.settings = {**DEFAULTS, **self._load("settings.json")}
        self.sync = {"wsync": "no sync", "sync": "no sync", "msync": "no sync", "nsync": "no sync",
                     "rsync": "", "dsync": "", "ssync": "no connect", "hsync": "no sensor"}
        self.weather: dict = {}
        self.currency: dict = {}
        self.mq: dict = {}  # последние сообщения MQTT: топик → текст
        self.weekend = False
        self.client: mqtt.Client | None = None
        self.download: dict = {}  # образ, который сейчас уходит в браузер
        self._cpu_prev = self._cpu_times()

    # ---------- настройки ----------
    def _load(self, name: str) -> dict:
        try:
            return json.loads((DATA / name).read_text())
        except Exception:
            return {}

    def save(self):
        tmp = DATA / "settings.json.tmp"
        tmp.write_text(json.dumps(self.settings, ensure_ascii=False, indent=1))
        tmp.replace(DATA / "settings.json")

    # ---------- система ----------
    @staticmethod
    def meminfo() -> tuple[int, int]:
        info = {}
        try:
            for line in Path("/proc/meminfo").read_text().splitlines():
                k, v = line.split(":", 1)
                info[k] = int(v.split()[0]) * 1024
        except Exception:
            pass
        return info.get("MemAvailable", 0), info.get("MemTotal", 1)

    @staticmethod
    def rssi() -> int:
        try:
            for line in Path("/proc/net/wireless").read_text().splitlines()[2:]:
                return int(float(line.split()[3]))
        except Exception:
            pass
        return -100

    @staticmethod
    def cpu_temp() -> float:
        try:
            return int(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000
        except Exception:
            return 0.0

    @staticmethod
    def _cpu_times() -> tuple[int, int]:
        try:
            v = [int(x) for x in Path("/proc/stat").read_text().split("\n", 1)[0].split()[1:]]
            return sum(v), v[3] + v[4]  # всего, простой (idle + iowait)
        except Exception:
            return 0, 0

    def cpu_percent(self) -> float:
        """Загрузка процессора с прошлого опроса (страница спрашивает раз в секунду)."""
        total, idle = self._cpu_times()
        pt, pi = self._cpu_prev
        self._cpu_prev = (total, idle)
        return round(100 * (1 - (idle - pi) / (total - pt)), 1) if total > pt else 0.0

    @staticmethod
    def uptime() -> float:
        try:
            return float(Path("/proc/uptime").read_text().split()[0])
        except Exception:
            return time.monotonic()

    @staticmethod
    def _cmd(*args) -> str:
        try:
            return subprocess.run(args, capture_output=True, text=True, timeout=3).stdout.strip()
        except Exception:
            return ""

    @staticmethod
    def _read(path: str) -> str:
        try:
            return Path(path).read_text().strip().strip("\x00")
        except Exception:
            return ""

    def power(self) -> str:
        """vcgencmd get_throttled: просадка питания и троттлинг — сейчас и с момента загрузки."""
        raw = self._cmd("vcgencmd", "get_throttled")
        try:
            bits = int(raw.split("=")[1], 16)
        except Exception:
            return "unknown"
        now = [n for b, n in ((0, "LOW VOLTAGE"), (1, "freq capped"), (2, "throttled"), (3, "hot limit")) if bits >> b & 1]
        was = [n for b, n in ((16, "low voltage"), (17, "freq capped"), (18, "throttled"), (19, "hot limit")) if bits >> b & 1]
        if now:
            return "NOW: " + ", ".join(now)
        return "ok" + (" (was " + ", ".join(was) + ")" if was else "")

    def info(self) -> dict:
        """Паспорт системы для Info table — по запросу страницы, не каждую секунду."""
        os_name = next((l.split("=", 1)[1].strip('"') for l in self._read("/etc/os-release").splitlines()
                        if l.startswith("PRETTY_NAME=")), "")
        link = {k.strip(): v.strip() for k, v in (l.split(":", 1) for l in self._cmd("/usr/sbin/iw", "dev", "wlan0", "link").splitlines() if ":" in l)}
        ip = self._cmd("hostname", "-I").split()
        freq = self._read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
        sd = self._read("/sys/block/mmcblk0/size")
        volt = self._cmd("vcgencmd", "measure_volts", "core").replace("volt=", "")
        load = os.getloadavg()
        return {
            "Model": self._read("/proc/device-tree/model").replace("Raspberry Pi", "RPi"),
            "OS": os_name.replace("GNU/Linux ", ""),
            "Kernel": os.uname().release,
            "Host": os.uname().nodename + ".local",
            "IP": ip[0] if ip else "",
            "Wi-Fi": f"{link.get('SSID', '')} {link.get('freq', '').split('.')[0]} MHz",
            "Speed": link.get("tx bitrate", "").replace("MBit/s", "Mbit/s"),
            "CPU": f"{os.cpu_count()} cores {int(freq) // 1000 if freq.isdigit() else '?'} MHz",
            "Core V": volt,
            "Power": self.power(),
            "Load": " ".join(f"{x:.2f}" for x in load),
            "SD card": f"{int(sd) * 512 / 1e9:.1f} GB" if sd.isdigit() else "",
            "Python": ".".join(map(str, os.sys.version_info[:3])),
            "App": "NeuroClock " + VERSION,
        }

    def mode(self) -> str:  # как у ESP32-часов: ночь 23–6, утро до 8 (Wake Up в будни) или до 10, вечер с 20
        h = dt.datetime.now().hour
        if h >= 23 or h < 6:
            return "night"
        if h < (8 if self.settings["wake"] and not self.weekend else 10):
            return "morning"
        return "evening" if h >= 20 else "midday"

    def state(self) -> dict:
        free, total = self.meminfo()
        now = dt.datetime.now()
        self.sync["rsync"] = self.mode()
        return {**self.sync, "frhp": free, "totalHeap": total, "rssi": self.rssi(),
                "mqst": self.sync["ssync"], "wake": self.settings["wake"], "autoupd": self.settings["autoupd"],
                "prcall": self.settings["prcall"], "auth": self.settings["auth"], "mqh": self.settings["mqh"],
                "mqp": self.settings["mqp"], "ver": VERSION, "time": now.strftime("%H:%M"),
                "date": now.strftime("%d.%m.%Y"), "cpuTemp": round(self.cpu_temp(), 1),
                "ctemp": round(self.cpu_temp(), 1), "cpu": self.cpu_percent(), "uptime": int(self.uptime()),
                "disk": round(100 * (lambda u: u.used / u.total)(shutil.disk_usage("/")), 1),
                "load": round(os.getloadavg()[0], 2), "weather": self.weather, "currency": self.currency,
                "lina": {t: self.mq.get(TOPIC_ROOT + t, "") for t in ("Lina1", "Lina2", "Lina3")},
                "update": self._load("update.json"),
                "backup": {**self._load("backup.json"), "download": self.download}}

    # ---------- MQTT ----------
    def mqtt_start(self):
        if self.client:
            try:
                self.client.loop_stop(); self.client.disconnect()
            except Exception:
                pass
        cred = self._load("mqtt.json")
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="neuroclock")
        if cred.get("username"):
            c.username_pw_set(cred["username"], cred.get("password"))

        def on_connect(client, userdata, flags, rc, props=None):
            self.sync["ssync"] = "connected" if rc == 0 else f"error {rc}"
            if rc == 0:
                client.subscribe([(TOPIC_ROOT + t, 0) for t in TOPICS])

        def on_disconnect(client, userdata, flags, rc, props=None):
            self.sync["ssync"] = "no connect"

        def on_message(client, userdata, msg):
            self.mq[msg.topic] = msg.payload.decode("utf-8", "replace")
            self.sync["msync"] = dt.datetime.now().strftime("%H:%M")
            if msg.topic.endswith(("/thome", "/thome1", "/CO")):
                self.sync["hsync"] = "NEWOS ok"

        c.on_connect, c.on_disconnect, c.on_message = on_connect, on_disconnect, on_message
        c.reconnect_delay_set(2, 60)
        c.connect_async(self.settings["mqh"], int(self.settings["mqp"]), 30)
        c.loop_start()
        self.client = c

    # ---------- фоновые задачи ----------
    async def every(self, seconds: int, fn):
        while True:
            try:
                await fn()
            except Exception as exc:
                log.warning("%s: %s", fn.__name__, exc)
            await asyncio.sleep(seconds)

    async def get_currency(self):
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
            async with s.get(CBR_URL) as r:
                d = json.loads(await r.text())
        cur = {}
        for code in ("USD", "EUR"):
            v = d["Valute"][code]
            cur[code] = {"value": round(v["Value"], 2), "delta": round(v["Value"] - v["Previous"], 2)}
        self.currency = cur
        self.sync["sync"] = dt.datetime.now().strftime("%H:%M")

    async def get_weather(self):
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
                async with s.get(OWM_URL) as r:
                    d = await r.json()
            self.weather = {"town": d["name"], "temp": round(d["main"]["temp"]), "hum": d["main"]["humidity"],
                            "press": round(d["main"]["pressure"] * 0.750062), "wind": d["wind"]["speed"],
                            "main": d["weather"][0]["main"], "desc": d["weather"][0]["description"]}
            self.sync["wsync"] = "sync: ok"
        except Exception:
            self.sync["wsync"] = "sync: error"
            raise

    async def get_day(self):
        today = dt.date.today()
        self.weekend = today.weekday() >= 5
        self.sync["dsync"] = ("weekend" if self.weekend else "working") + " n_pc"
        if not self.settings["prcall"]:
            return
        url = CAL_URL.format(token=self.settings["auth"], date=today.strftime("%d.%m.%Y"))
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
            async with s.get(url) as r:
                d = await r.json(content_type=None)
        day = d["days"][0]
        self.weekend = day["type_id"] not in (1, 5)
        self.sync["dsync"] = f"{'weekend' if self.weekend else 'working'} {day.get('working_hours', 0)} hours"

    async def get_ntp(self):
        out = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"],
                             capture_output=True, text=True).stdout.strip()
        self.sync["nsync"] = "sync ok" if out == "yes" else "no sync"


clock = Clock()


async def page(request):
    return web.FileResponse(HERE / "web" / "index.html", headers={"Cache-Control": "no-cache"})


async def api_state(request):
    return web.json_response(clock.state())


def start_update() -> bool:
    """Проверка обновления — отдельной службой (nc_update.py): она же перезапустит часы и при сбое откатит."""
    r = subprocess.run(["sudo", "-n", "systemctl", "start", "--no-block", "neuroclock-update-now"], capture_output=True)
    return r.returncode == 0


async def api_update(request):
    return web.Response(text="ok") if start_update() else web.Response(status=500, text="no updater")


BACKUP_CMD = "sync; sudo -n fstrim / >/dev/null 2>&1; sudo -n dd if=/dev/mmcblk0 bs=4M status=none | gzip -1"


async def api_backup_image(request):
    """Полный образ SD-карты прямо в браузер (dd | gzip): файл сохраняется на устройстве, где нажали кнопку.
    Одновременно — только один образ; закрыли вкладку — dd останавливается."""
    if clock.download.get("running"):
        return web.Response(status=409, text="backup already running")
    name = f"neuroclock-{dt.datetime.now():%Y%m%d-%H%M}.img.gz"
    resp = web.StreamResponse(headers={"Content-Type": "application/gzip",
                                       "Content-Disposition": f'attachment; filename="{name}"', "Cache-Control": "no-store"})
    await resp.prepare(request)
    proc = await asyncio.create_subprocess_shell(BACKUP_CMD, stdout=asyncio.subprocess.PIPE, start_new_session=True)
    clock.download = {"running": True, "sent": 0, "name": name, "started": dt.datetime.now().strftime("%H:%M")}
    ok = False
    try:
        while chunk := await proc.stdout.read(256 * 1024):
            await resp.write(chunk)
            clock.download["sent"] += len(chunk)
        ok = await proc.wait() == 0
        await resp.write_eof()
    except (ConnectionResetError, asyncio.CancelledError):
        raise
    finally:
        if proc.returncode is None:
            try:
                os.killpg(proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        clock.download = {"running": False, "name": name, "sent": clock.download.get("sent", 0),
                          "result": "ok" if ok else "stopped", "ts": dt.datetime.now().strftime("%d.%m %H:%M")}
    return resp


async def api_info(request):
    return web.json_response(clock.info())


async def api_set(request):
    form = await request.post()
    k, v = form.get("k", ""), str(form.get("v", "")).strip()
    s = clock.settings
    if k in ("btn1", "btn2", "btn3"):
        key = {"btn1": "wake", "btn2": "autoupd", "btn3": "prcall"}[k]
        was = s[key]
        s[key] = v == "1"
        if k == "btn2" and s[key] and not was:  # включили Auto update — сразу проверка, как у ESP32-часов
            clock.save()
            start_update()
        if k == "btn3":
            asyncio.create_task(clock.get_day())
    elif k == "auth":
        s["auth"] = v
    elif k == "mqh":
        if not v or len(v) > 63:
            return web.Response(status=400, text="bad host")
        s["mqh"] = v
    elif k == "mqp":
        if not v.isdigit() or not 0 < int(v) < 65536:
            return web.Response(status=400, text="bad port")
        s["mqp"] = int(v)
    else:
        return web.Response(status=400, text="unknown key")
    clock.save()
    if k in ("mqh", "mqp"):
        clock.mqtt_start()
    return web.Response(text="ok")


async def on_start(app):
    clock.mqtt_start()
    for sec, fn in ((1800, clock.get_currency), (600, clock.get_weather), (3600, clock.get_day), (60, clock.get_ntp)):
        asyncio.create_task(clock.every(sec, fn))


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    app = web.Application()
    app.router.add_get("/", page)
    app.router.add_get("/api/state", api_state)
    app.router.add_post("/api/set", api_set)
    app.router.add_get("/api/info", api_info)
    app.router.add_post("/api/update", api_update)
    app.router.add_get("/api/backup/image", api_backup_image)
    app.router.add_get("/ping", lambda r: web.Response(text="ok"))
    app.on_startup.append(on_start)
    web.run_app(app, port=PORT, access_log=None)


if __name__ == "__main__":
    main()
