#!/usr/bin/env python3
"""Обновление NeuroClock — как у ESP32-часов: манифест на GitHub, архив, контрольная сумма.

Раскладка на Pi (корень NC_ROOT, по умолчанию /home/sasha/nc):
  releases/<версия>/   — программа (app.py, web/, VERSION …)
  current, previous    — ссылки на рабочую и прошлую версию
  data/                — настройки и состояние, общие для всех версий; data/update.json — итог последней проверки

Запуск: служба neuroclock-update (таймер раз в сутки — только при включённом Auto update; кнопка в вебе —
всегда) или вручную с локальным архивом: nc_update.py --file archive.tar.gz --sha256 HEX.
Новая версия ставится рядом, ссылка current переключается, служба перезапускается; если часы за 40 секунд
не ответили на /ping — откат на previous.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(os.getenv("NC_ROOT", "/home/sasha/nc"))
MANIFEST = os.getenv("NC_MANIFEST", "https://raw.githubusercontent.com/Sanata79/Heateros/refs/heads/main/neuroclock.json")
DATA = ROOT / "data"
STATUS = DATA / "update.json"
KEEP = 3  # сколько версий хранить в releases


def status(**kw) -> None:
    st = {}
    try:
        st = json.loads(STATUS.read_text())
    except Exception:
        pass
    st.update(kw, ts=time.strftime("%Y-%m-%d %H:%M"))
    STATUS.write_text(json.dumps(st, ensure_ascii=False, indent=1))
    print(json.dumps(kw, ensure_ascii=False))


def vkey(v: str) -> tuple:
    return tuple(int(x) if x.isdigit() else 0 for x in v.split("."))


def current_version() -> str:
    try:
        return (ROOT / "current" / "VERSION").read_text().strip()
    except Exception:
        return "0"


def alive(timeout: float = 40) -> bool:
    end = time.time() + timeout
    while time.time() < end:
        try:
            with urllib.request.urlopen("http://127.0.0.1/ping", timeout=3) as r:
                if r.status == 200 and urllib.request.urlopen("http://127.0.0.1/api/state", timeout=3).status == 200:
                    return True
        except Exception:
            pass
        time.sleep(2)
    return False


def system_check() -> None:
    """Системные настройки Pi (nc_system.py текущей версии) — их обновление само не меняет."""
    script = ROOT / "current" / "nc_system.py"
    if script.exists():
        subprocess.run([sys.executable, str(script)], timeout=600, check=False)


def restart() -> None:
    subprocess.run(["sudo", "-n", "systemctl", "restart", "neuroclock"], check=False)
    subprocess.run(["sudo", "-n", "systemctl", "try-restart", "neuroclock-matrix"], check=False)  # матрица — если запущена
    subprocess.run(["sudo", "-n", "systemctl", "try-restart", "neuroclock-wifi-watch"], check=False)  # сторож Wi-Fi


def install(archive: Path, sha256: str, notes: str = "") -> bool:
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if sha256 and digest != sha256.lower():
        status(result="error", error="sha256 mismatch")
        return False
    tmp = ROOT / "releases" / ".incoming"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    with tarfile.open(archive) as tar:
        tar.extractall(tmp, filter="data")  # без абсолютных путей и выходов за папку
    version = (tmp / "VERSION").read_text().strip()
    dest = ROOT / "releases" / version
    if dest.resolve() == (ROOT / "current").resolve():
        shutil.rmtree(tmp)
        status(result="latest", version=version)
        return True
    shutil.rmtree(dest, ignore_errors=True)
    tmp.rename(dest)
    old = (ROOT / "current").resolve() if (ROOT / "current").exists() else None
    older = (ROOT / "previous").resolve() if (ROOT / "previous").exists() else None
    if old:
        _link(ROOT / "previous", old)
    _link(ROOT / "current", dest)
    restart()
    if alive():
        status(result="updated", version=version, previous=old.name if old else "", notes=notes)
        _prune()
        system_check()
        return True
    if old:  # не поднялась — откат: прежняя версия снова рабочая, сломанная удаляется
        _link(ROOT / "current", old)
        if older:
            _link(ROOT / "previous", older)
        restart()
        shutil.rmtree(dest, ignore_errors=True)
        status(result="rolled back", version=old.name, failed=version, alive=alive())
    else:
        status(result="error", error=f"{version} did not start")
    return False


def _link(name: Path, target: Path) -> None:
    tmp = name.with_name(name.name + ".new")
    if tmp.is_symlink() or tmp.exists():
        tmp.unlink()
    tmp.symlink_to(target)
    tmp.replace(name)  # атомарно


def _prune() -> None:
    keep = {(ROOT / n).resolve() for n in ("current", "previous") if (ROOT / n).exists()}
    rel = sorted((p for p in (ROOT / "releases").iterdir() if p.is_dir() and not p.name.startswith(".")),
                 key=lambda p: vkey(p.name), reverse=True)
    for p in rel[KEEP:]:
        if p.resolve() not in keep:
            shutil.rmtree(p, ignore_errors=True)


def check(force: bool) -> bool:
    try:
        settings = json.loads((DATA / "settings.json").read_text())
    except Exception:
        settings = {}
    if not force and not settings.get("autoupd"):
        print("auto update off")
        return True
    try:
        with urllib.request.urlopen(MANIFEST + f"?t={int(time.time())}", timeout=20) as r:
            m = json.loads(r.read().decode())
    except Exception as exc:
        status(result="error", error=f"manifest: {exc}")
        return False
    cur = current_version()
    if vkey(str(m.get("version", "0"))) <= vkey(cur):
        status(result="latest", version=cur)
        system_check()  # и без новой версии — настройки системы сверить (кнопка CHECK)
        return True
    status(result="downloading", version=cur, available=m["version"])
    path = DATA / "download.tar.gz"
    try:
        with urllib.request.urlopen(m["url"], timeout=60) as r, open(path, "wb") as f:
            shutil.copyfileobj(r, f)
    except Exception as exc:
        status(result="error", error=f"download: {exc}")
        return False
    try:
        return install(path, m.get("sha256", ""), m.get("notes", ""))
    finally:
        path.unlink(missing_ok=True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true", help="проверить, даже если Auto update выключен")
    ap.add_argument("--file", help="поставить локальный архив")
    ap.add_argument("--sha256", default="")
    a = ap.parse_args()
    DATA.mkdir(parents=True, exist_ok=True)
    if a.file:
        return 0 if install(Path(a.file), a.sha256) else 1
    return 0 if check(a.force or os.getenv("NC_FORCE") == "1") else 1


if __name__ == "__main__":
    sys.exit(main())
