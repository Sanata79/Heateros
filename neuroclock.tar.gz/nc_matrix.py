#!/usr/bin/env python3
"""Матрица NeuroClock: сцены (scenes.py) на HUB75 64x32 через rpi-rgb-led-matrix и Adafruit Bonnet.

Отдельная служба neuroclock-matrix: веб (app.py) живёт сам по себе, данные для сцен матрица берёт у него
по http://127.0.0.1/api/state. Нет библиотеки — сцены идут «вхолостую». Настройки — data/matrix.json
(правит веб, панель Matrix): вкл/выкл, яркость, предел частоты, тип чипа панели (FM6126A у части китайских),
подключение, замедление GPIO. Файл проверяется дважды в секунду: яркость меняется на лету, остальное —
выход, systemd поднимает службу заново с новыми настройками. Состояние — data/matrix_status.json.
Библиотека — в окружении /home/sasha/nc/mvenv (pip install ~/rpi-rgb-led-matrix).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import time
import urllib.request
from pathlib import Path

import matrix
import scenes
from mind import Mind, MindProc

try:
    from PIL import Image, ImageChops
except ImportError:  # превью на Mac — без PIL, стая в том же процессе
    Image = None

DATA = Path(os.getenv("NEUROCLOCK_DATA", "/home/sasha/nc/data"))
API = "http://127.0.0.1/api/state"
DEFAULTS = {"enabled": True, "mapping": "adafruit-hat", "brightness": 40, "limit_hz": 0, "panel_type": "",
            "slowdown": 2, "pwm_bits": 11, "multiplexing": 0, "row_addr_type": 0}
STATUS = DATA / "matrix_status.json"
QUICK = Path("/run/neuroclock-matrix.quick")  # перезапуск из-за настроек — без загрузочной заставки
log = logging.getLogger("neuroclock.matrix")


def settings() -> dict:
    path = DATA / "matrix.json"
    try:
        s = {**DEFAULTS, **json.loads(path.read_text())}
    except Exception:
        s = dict(DEFAULTS)
        try:
            path.write_text(json.dumps(s, indent=1))
        except OSError:
            pass
    return s


class Feed:
    """Данные для сцен — из веб-части часов, теми же полями, что у Clock в app.py."""
    weekend = False
    currency: dict = {}
    weather: dict = {}
    wake = False   # Wake up 8:00 из Setup
    ready = False  # данные хотя бы раз получены
    heat: dict = {}
    lina: dict = {}

    def pull(self) -> None:
        with urllib.request.urlopen(API, timeout=3) as r:
            s = json.loads(r.read())
        self.weekend = str(s.get("dsync", "")).startswith("weekend")
        self.currency = s.get("currency") or {}
        self.weather = s.get("weather") or {}
        self.state = s  # всё состояние — для этапов загрузки
        self.wake = bool(s.get("wake"))
        self.ready = True
        self.heat = s.get("heat") or {}
        self.lina = s.get("lina") or {}


async def feed_loop(feed: Feed) -> None:
    loop = asyncio.get_running_loop()
    while True:
        try:
            await loop.run_in_executor(None, feed.pull)
        except Exception as exc:
            log.debug("state: %s", exc)
        await asyncio.sleep(10)


class Panel:
    """Вывод кадров на матрицу; без библиотеки или при ошибке запуска — только счёт кадров."""

    def __init__(self, s: dict):
        self.hw = None
        self.frames = 0
        self.error = ""
        self.base = int(s["brightness"])  # дневная яркость; на панели — base × Screen.dim
        self.applied = self.base
        try:
            from PIL import Image
            from rgbmatrix import RGBMatrix, RGBMatrixOptions
        except ImportError as exc:
            log.warning("нет библиотеки матрицы (%s) — вхолостую", exc)
            return
        o = RGBMatrixOptions()
        o.rows, o.cols = 32, 64
        o.hardware_mapping = s["mapping"]
        o.brightness = int(s["brightness"])
        o.gpio_slowdown = int(s["slowdown"])
        o.pwm_bits = int(s["pwm_bits"])
        o.multiplexing = int(s["multiplexing"])
        o.row_address_type = int(s["row_addr_type"])
        o.limit_refresh_rate_hz = int(s["limit_hz"])
        if s["panel_type"]:
            o.panel_type = s["panel_type"]
        o.drop_privileges = False  # данные и модули лежат у sasha — без смены пользователя после запуска
        if "snd_bcm2835" in Path("/proc/modules").read_text():  # звук занимает ШИМ, которой матрица светит
            o.disable_hardware_pulsing = True
            log.warning("включён звук (snd_bcm2835) — без аппаратной ШИМ, возможно мерцание; нужен dtparam=audio=off")
        try:
            self.hw = RGBMatrix(options=o)
        except Exception as exc:
            log.error("матрица не запустилась (%s) — вхолостую", exc)
            self.error = str(exc)
            return
        self.Image = Image
        self.cv = self.hw.CreateFrameCanvas()
        log.info("матрица: %s, яркость %s%%", s["mapping"], s["brightness"])

    def show(self, px: bytes) -> None:
        self.frames += 1
        if self.hw:
            self.cv.SetImage(self.Image.frombytes("RGB", (matrix.W, matrix.H), bytes(px)))
            self.cv = self.hw.SwapOnVSync(self.cv)

    def show_img(self, img) -> None:
        self.frames += 1
        if self.hw:
            self.cv.SetImage(img)
            self.cv = self.hw.SwapOnVSync(self.cv)

    def bright(self, v: int) -> None:
        if self.hw:
            self.hw.brightness = max(1, min(100, int(v)))

    def close(self) -> None:
        if self.hw:  # иначе панель застынет на последнем кадре, а одна строка может гореть в полную яркость
            self.hw.Clear()


async def compositor(scr: matrix.Screen, mind, panel) -> None:
    """50 раз в секунду: кадр сцены поверх стаи — на панель. Сцены рисуют в своём темпе. Стая в своём
    процессе (MindProc) — слой из общей памяти, сложение — PIL; иначе — шаг стаи здесь же."""
    loop = asyncio.get_running_loop()
    nxt = loop.time()
    size = (matrix.W, matrix.H)
    while True:
        want = max(1, round(getattr(panel, "base", 0) * scr.dim))
        if getattr(panel, "applied", want) != want:  # режим (вечер, утро) или яркость из веба
            panel.bright(want)
            panel.applied = want
        if isinstance(mind, MindProc):
            panel.show_img(ImageChops.lighter(Image.frombytes("RGB", size, bytes(scr.px)), Image.frombytes("RGB", size, mind.layer())))
        else:
            mind.step()
            panel.show(mind.compose(scr.px))
        nxt += matrix.FRAME
        now = loop.time()
        if nxt < now - 0.2:  # отстали (долгая сцена, нагрузка) — без догоняющих рывков
            nxt = now
        await asyncio.sleep(max(0.0, nxt - now))


def status(**kw) -> None:
    """Состояние для веба; файл — владельцу папки data (служба работает от root)."""
    try:
        tmp = STATUS.with_suffix(".tmp")
        tmp.write_text(json.dumps({**kw, "ts": round(time.time())}))
        st = DATA.stat()
        os.chown(tmp, st.st_uid, st.st_gid)
        tmp.replace(STATUS)
    except OSError as exc:
        log.debug("status: %s", exc)


async def stats(panel: Panel) -> None:
    """Каждые 15 с — в matrix_status.json, раз в минуту — в журнал: кадры в секунду, процессор на сцены
    (главный поток) и на обновление панели (поток библиотеки, при isolcpus=3 — на своём ядре)."""
    mode = "matrix" if panel.hw else "error" if panel.error else "dry"
    status(mode=mode, error=panel.error)
    n = 0
    while True:
        f0, p0, m0, t0 = panel.frames, time.process_time(), time.thread_time(), time.monotonic()
        await asyncio.sleep(15)
        dt = time.monotonic() - t0
        main = time.thread_time() - m0
        fps, sc, pn = (panel.frames - f0) / dt, 100 * main / dt, 100 * (time.process_time() - p0 - main) / dt
        status(mode=mode, error=panel.error, fps=round(fps, 1), scenes=round(sc), panel=round(pn))
        n += 1
        if n % 4 == 0:
            log.info("%s: %.1f кадр/с, сцены %.0f%%, панель %.0f%% ядра", mode, fps, sc, pn)


async def watch(panel: Panel | None, s: dict) -> None:
    """Настройки из веба: яркость — сразу, остальное — выход и перезапуск службой systemd."""
    path = DATA / "matrix.json"
    mt = path.stat().st_mtime if path.exists() else 0
    while True:
        await asyncio.sleep(0.5)
        try:
            m = path.stat().st_mtime
        except OSError:
            continue
        if m == mt:
            continue
        mt = m
        nu = settings()
        if {k: v for k, v in nu.items() if k != "brightness"} != {k: v for k, v in s.items() if k != "brightness"}:
            log.info("настройки матрицы изменились — перезапуск")
            try:
                QUICK.touch()
            except OSError:
                pass
            return
        if panel and nu["brightness"] != s["brightness"]:
            panel.base = int(nu["brightness"])  # компоновщик применит с учётом режима
        s = nu


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
    s = settings()
    loop = asyncio.get_running_loop()
    task = asyncio.current_task()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, task.cancel)
    if not s["enabled"]:  # выключена из веба: панель тёмная, ядро свободно; ждём, пока включат
        log.info("матрица выключена")
        status(mode="off")
        try:
            await watch(None, s)
        except asyncio.CancelledError:
            pass
        return
    quick = QUICK.exists()
    QUICK.unlink(missing_ok=True)
    mind = MindProc() if Image else Mind()  # до матрицы: дочерний процесс — без её потоков
    panel = Panel(s)
    scr, feed = matrix.Screen(), Feed()
    bg = [asyncio.create_task(feed_loop(feed)), asyncio.create_task(stats(panel)),
          asyncio.create_task(compositor(scr, mind, panel)), asyncio.create_task(scenes.run(scr, feed, mind, boot=not quick))]
    try:
        await watch(panel, s)
    except asyncio.CancelledError:
        pass
    finally:
        for t in bg:
            t.cancel()
        panel.close()
        if isinstance(mind, MindProc):
            mind.close()


if __name__ == "__main__":
    asyncio.run(main())
