#!/usr/bin/env python3
"""Матрица NeuroClock: сцены (scenes.py) на HUB75 64x32 через rpi-rgb-led-matrix и Adafruit Bonnet.

Отдельная служба neuroclock-matrix: веб (app.py) живёт сам по себе, данные для сцен матрица берёт у него
по http://127.0.0.1/api/state. Нет библиотеки или панели — сцены идут «вхолостую», в журнал раз в минуту
пишутся кадры в секунду и загрузка процессора. Настройки — data/matrix.json (создаётся с умолчаниями):
схема подключения, яркость, тип чипа панели (FM6126A у части китайских), замедление GPIO.
Библиотека — в окружении /home/sasha/nc/mvenv (pip install ~/rpi-rgb-led-matrix).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import time
import urllib.request
from pathlib import Path

import matrix
import scenes

DATA = Path(os.getenv("NEUROCLOCK_DATA", "/home/sasha/nc/data"))
API = "http://127.0.0.1/api/state"
DEFAULTS = {"mapping": "adafruit-hat", "brightness": 40, "panel_type": "", "slowdown": 2, "pwm_bits": 11,
            "multiplexing": 0, "row_addr_type": 0}
log = logging.getLogger("neuroclock.matrix")


def settings() -> dict:
    path = DATA / "matrix.json"
    try:
        s = {**DEFAULTS, **json.loads(path.read_text())}
    except Exception:
        s = dict(DEFAULTS)
        try:
            path.write_text(json.dumps(s, indent=1))
        except OSError:
            pass
    return s


class Feed:
    """Данные для сцен — из веб-части часов, теми же полями, что у Clock в app.py."""
    weekend = False
    currency: dict = {}
    weather: dict = {}

    def pull(self) -> None:
        with urllib.request.urlopen(API, timeout=3) as r:
            s = json.loads(r.read())
        self.weekend = str(s.get("dsync", "")).startswith("weekend")
        self.currency = s.get("currency") or {}
        self.weather = s.get("weather") or {}


async def feed_loop(feed: Feed) -> None:
    loop = asyncio.get_running_loop()
    while True:
        try:
            await loop.run_in_executor(None, feed.pull)
        except Exception as exc:
            log.debug("state: %s", exc)
        await asyncio.sleep(10)


class Panel:
    """Вывод кадров на матрицу; без библиотеки или при ошибке запуска — только счёт кадров."""

    def __init__(self, s: dict):
        self.hw = None
        self.frames = 0
        try:
            from PIL import Image
            from rgbmatrix import RGBMatrix, RGBMatrixOptions
        except ImportError as exc:
            log.warning("нет библиотеки матрицы (%s) — вхолостую", exc)
            return
        o = RGBMatrixOptions()
        o.rows, o.cols = 32, 64
        o.hardware_mapping = s["mapping"]
        o.brightness = int(s["brightness"])
        o.gpio_slowdown = int(s["slowdown"])
        o.pwm_bits = int(s["pwm_bits"])
        o.multiplexing = int(s["multiplexing"])
        o.row_address_type = int(s["row_addr_type"])
        if s["panel_type"]:
            o.panel_type = s["panel_type"]
        o.drop_privileges = False  # данные и модули лежат у sasha — без смены пользователя после запуска
        if "snd_bcm2835" in Path("/proc/modules").read_text():  # звук занимает ШИМ, которой матрица светит
            o.disable_hardware_pulsing = True
            log.warning("включён звук (snd_bcm2835) — без аппаратной ШИМ, возможно мерцание; нужен dtparam=audio=off")
        try:
            self.hw = RGBMatrix(options=o)
        except Exception as exc:
            log.error("матрица не запустилась (%s) — вхолостую", exc)
            return
        self.Image = Image
        self.cv = self.hw.CreateFrameCanvas()
        log.info("матрица: %s, яркость %s%%", s["mapping"], s["brightness"])

    def show(self, px: bytearray) -> None:
        self.frames += 1
        if self.hw:
            self.cv.SetImage(self.Image.frombytes("RGB", (matrix.W, matrix.H), bytes(px)))
            self.cv = self.hw.SwapOnVSync(self.cv)

    def close(self) -> None:
        if self.hw:  # иначе панель застынет на последнем кадре, а одна строка может гореть в полную яркость
            self.hw.Clear()


async def stats(panel: Panel) -> None:
    while True:
        f0, c0, t0 = panel.frames, time.process_time(), time.monotonic()
        await asyncio.sleep(60)
        dt = time.monotonic() - t0
        log.info("%s: %.1f кадр/с, процессор %.0f%%", "матрица" if panel.hw else "вхолостую",
                 (panel.frames - f0) / dt, 100 * (time.process_time() - c0) / dt)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
    panel = Panel(settings())
    scr = matrix.Screen()
    scr.out = panel.show
    feed = Feed()
    task = asyncio.current_task()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, task.cancel)
    bg = [asyncio.create_task(feed_loop(feed)), asyncio.create_task(stats(panel))]
    try:
        await scenes.run(scr, feed)
    except asyncio.CancelledError:
        pass
    finally:
        for t in bg:
            t.cancel()
        panel.close()


if __name__ == "__main__":
    asyncio.run(main())
