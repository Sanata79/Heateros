#!/usr/bin/env python3
"""Матрица NeuroClock: сцены (scenes.py) на HUB75 64x32 через rpi-rgb-led-matrix и Adafruit Bonnet.

Отдельная служба neuroclock-matrix: веб (app.py) живёт сам по себе, данные для сцен матрица берёт у него
по http://127.0.0.1/api/state. Нет библиотеки — сцены идут «вхолостую». Настройки — data/matrix.json
(правит веб, панель Matrix): вкл/выкл, яркость, предел частоты, тип чипа панели (FM6126A у части китайских),
подключение, замедление GPIO. Файл проверяется дважды в секунду: яркость меняется на лету, остальное —
выход, systemd поднимает службу заново с новыми настройками. Состояние — data/matrix_status.json.
Библиотека — в окружении /home/sasha/nc/mvenv (pip install ~/rpi-rgb-led-matrix).
"""
from __future__ import annotations

import asyncio
import collections
import json
import logging
import os
import signal
import sys
import threading
import time
import urllib.request
from pathlib import Path

import matrix
import night
import scenes
from mind import Mind, MindProc

try:
    from PIL import Image, ImageChops
except ImportError:  # превью на Mac — без PIL, стая в том же процессе
    Image = None

DATA = Path(os.getenv("NEUROCLOCK_DATA", "/home/sasha/nc/data"))
API = "http://127.0.0.1/api/state"
DEFAULTS = {"enabled": True, "mapping": "adafruit-hat", "brightness": 40, "limit_hz": 0, "panel_type": "",
            "slowdown": 2, "pwm_bits": 11, "multiplexing": 0, "row_addr_type": 0}
STATUS = DATA / "matrix_status.json"
QUICK = Path("/run/neuroclock-matrix.quick")  # перезапуск из-за настроек — без загрузочной заставки
NIGHT = Path("/run/neuroclock-matrix.night")  # ночь: панель погашена, библиотека матрицы не запущена
WOKE = Path("/run/neuroclock-matrix.woke")    # утро после ночи: стая сначала тихонько просыпается (night.WOKE)
log = logging.getLogger("neuroclock.matrix")


def settings() -> dict:
    path = DATA / "matrix.json"
    try:
        s = {**DEFAULTS, **json.loads(path.read_text())}
    except Exception:
        s = dict(DEFAULTS)
        try:
            path.write_text(json.dumps(s, indent=1))
        except OSError:
            pass
    return s


class Feed:
    """Данные для сцен — из веб-части часов, теми же полями, что у Clock в app.py."""
    weekend = False
    currency: dict = {}
    weather: dict = {}
    wake = False   # Wake up 8:00 из Setup
    ready = False  # данные хотя бы раз получены
    heat: dict = {}
    lina: dict = {}
    stir = 0.0     # что-то изменилось с прошлого раза — стая вздрогнет (feed_loop → mind.stir)
    _sig = None
    STIR = {"lina": 1.0, "heat": .7, "weather": .6, "currency": .5}  # сила события

    def pull(self) -> None:
        with urllib.request.urlopen(API, timeout=3) as r:
            s = json.loads(r.read())
        self.weekend = str(s.get("dsync", "")).startswith("weekend")
        self.currency = s.get("currency") or {}
        self.weather = s.get("weather") or {}
        self.state = s  # всё состояние — для этапов загрузки
        self.wake = bool(s.get("wake"))
        self.ready = True
        self.heat = s.get("heat") or {}
        self.lina = s.get("lina") or {}
        w, h = self.weather, self.heat
        sig = {"lina": json.dumps(self.lina, sort_keys=True), "heat": (h.get("st"), h.get("mode")),
               "weather": (w.get("temp1"), w.get("icon")), "currency": json.dumps(self.currency, sort_keys=True)}
        if self._sig:  # первое получение — не событие
            self.stir = max([self.stir] + [self.STIR[k] for k in sig if sig[k] != self._sig[k]])
        self._sig = sig


async def feed_loop(feed: Feed, mind=None) -> None:
    loop = asyncio.get_running_loop()
    while True:
        try:
            await loop.run_in_executor(None, feed.pull)
        except Exception as exc:
            log.debug("state: %s", exc)
        if mind and feed.stir:  # новое сообщение, погода, термостат, курс — стая чувствует раньше экрана
            mind.stir(feed.stir)
            feed.stir = 0.0
        await asyncio.sleep(10)


class Panel:
    """Вывод кадров на матрицу; без библиотеки или при ошибке запуска — только счёт кадров."""

    def __init__(self, s: dict):
        self.hw = None
        self.frames = 0
        self.error = ""
        self.base = int(s["brightness"])  # дневная яркость; на панели — base × Screen.dim
        self.applied = self.base
        try:
            from PIL import Image
            from rgbmatrix import RGBMatrix, RGBMatrixOptions
        except ImportError as exc:
            log.warning("нет библиотеки матрицы (%s) — вхолостую", exc)
            return
        o = RGBMatrixOptions()
        o.rows, o.cols = 32, 64
        o.hardware_mapping = s["mapping"]
        o.brightness = int(s["brightness"])
        o.gpio_slowdown = int(s["slowdown"])
        o.pwm_bits = int(s["pwm_bits"])
        o.multiplexing = int(s["multiplexing"])
        o.row_address_type = int(s["row_addr_type"])
        o.limit_refresh_rate_hz = int(s["limit_hz"])
        if s["panel_type"]:
            o.panel_type = s["panel_type"]
        o.drop_privileges = False  # данные и модули лежат у sasha — без смены пользователя после запуска
        if "snd_bcm2835" in Path("/proc/modules").read_text():  # звук занимает ШИМ, которой матрица светит
            o.disable_hardware_pulsing = True
            log.warning("включён звук (snd_bcm2835) — без аппаратной ШИМ, возможно мерцание; нужен dtparam=audio=off")
        try:
            self.hw = RGBMatrix(options=o)
        except Exception as exc:
            log.error("матрица не запустилась (%s) — вхолостую", exc)
            self.error = str(exc)
            return
        self.Image = Image
        self.cv = self.hw.CreateFrameCanvas()
        log.info("матрица: %s, яркость %s%%", s["mapping"], s["brightness"])

    def show(self, px: bytes) -> None:
        self.frames += 1
        if self.hw:
            self.cv.SetImage(self.Image.frombytes("RGB", (matrix.W, matrix.H), bytes(px)))
            self.cv = self.hw.SwapOnVSync(self.cv)

    def show_img(self, img) -> None:
        self.frames += 1
        if self.hw:
            self.cv.SetImage(img)
            self.cv = self.hw.SwapOnVSync(self.cv)

    def bright(self, v: int) -> None:
        if self.hw:
            self.hw.brightness = max(1, min(100, int(v)))

    def close(self) -> None:
        if self.hw:  # иначе панель застынет на последнем кадре, а одна строка может гореть в полную яркость
            self.hw.Clear()


async def compositor(scr: matrix.Screen, mind, panel) -> None:
    """50 раз в секунду: кадр сцены поверх стаи — на панель. Сцены рисуют в своём темпе. Стая в своём
    процессе (MindProc) — слой из общей памяти, сложение — PIL; иначе — шаг стаи здесь же."""
    loop = asyncio.get_running_loop()
    nxt = loop.time()
    size = (matrix.W, matrix.H)
    n = 0
    while True:
        n += 1
        if n % 25 == 0:  # раз в полсекунды — где сейчас информация: стае на память
            px = scr.px
            pts = [(i // 3 % matrix.W, i // 3 // matrix.W) for i in range(0, len(px), 3) if px[i] | px[i + 1] | px[i + 2]]
            if pts:
                mind.imprint(pts)
        want = max(1, round(getattr(panel, "base", 0) * scr.dim))
        if getattr(panel, "applied", want) != want:  # режим (вечер, утро) или яркость из веба
            panel.bright(want)
            panel.applied = want
        if isinstance(mind, MindProc):
            panel.show_img(ImageChops.lighter(Image.frombytes("RGB", size, bytes(scr.px)), Image.frombytes("RGB", size, mind.layer())))
        else:
            mind.step()
            panel.show(mind.compose(scr.px))
        nxt += matrix.FRAME
        now = loop.time()
        if nxt < now - 0.2:  # отстали (долгая сцена, нагрузка) — без догоняющих рывков
            nxt = now
        await asyncio.sleep(max(0.0, nxt - now))


def status(**kw) -> None:
    """Состояние для веба; файл — владельцу папки data (служба работает от root)."""
    try:
        tmp = STATUS.with_suffix(".tmp")
        tmp.write_text(json.dumps({**kw, "ts": round(time.time())}))
        st = DATA.stat()
        os.chown(tmp, st.st_uid, st.st_gid)
        tmp.replace(STATUS)
    except OSError as exc:
        log.debug("status: %s", exc)


MODE = ""  # что пишет stats в matrix_status.json: matrix / dry / error, перед образом — backup


FPS_WARN = 48  # ниже — просадка: сторож плавности пишет её в журнал
HERE = {os.path.dirname(os.path.abspath(__file__)), os.path.dirname(os.path.realpath(__file__))}  # current и releases/…


class Busy(threading.Thread):
    """Чем занят главный поток (сцены и сборка кадра): 50 раз в секунду — цепочка функций часов сверху стека.
    В просадке сторож плавности называет, на что ушло время, — виновника видно прямо в журнале."""

    def __init__(self):
        super().__init__(daemon=True, name="busy")
        self.main = threading.main_thread().ident
        self.hits: collections.Counter = collections.Counter()

    def run(self) -> None:
        while True:
            time.sleep(.02)
            f = sys._current_frames().get(self.main)
            self.hits[None] += 1  # всего взглядов: пока поток занят, сторож просыпается реже 50 раз в секунду
            if f is None or f.f_code.co_filename.endswith("selectors.py"):  # ждёт событий — свободен
                continue
            chain = []
            while f and len(chain) < 3:
                if os.path.dirname(f.f_code.co_filename) in HERE:
                    chain.append(f"{Path(f.f_code.co_filename).stem}.{f.f_code.co_name}")
                f = f.f_back
            if chain:
                self.hits["←".join(chain)] += 1

    def take(self) -> collections.Counter:
        h, self.hits = self.hits, collections.Counter()
        return h


def busy_text(h: collections.Counter) -> str:
    """Самые дорогие места: доля времени главного потока за просадку (h[None] — всего взглядов)."""
    top = [(k, v) for k, v in h.most_common(5) if k][:4]
    return ", ".join(f"{k} {100 * v / h[None]:.0f}%" for k, v in top) or "—"


async def stats(panel: Panel) -> None:
    """Каждые 15 с — в matrix_status.json, раз в минуту — в журнал: кадры в секунду, процессор на сцены
    (главный поток) и на обновление панели (поток библиотеки, при isolcpus=3 — на своём ядре).
    Сторож плавности: кадров меньше FPS_WARN — одна строка-предупреждение на всю просадку, когда она кончилась
    (насколько упало, сколько длилось, какие сцены шли); тянется дольше 10 мин — ещё одна, промежуточная."""
    global MODE
    MODE = "matrix" if panel.hw else "error" if panel.error else "dry"
    status(mode=MODE, error=panel.error)
    n = 0
    drop = None  # просадка: начало, худшее, сцены, сказали ли уже о долгой, чем был занят главный поток
    busy = Busy()
    busy.start()
    while True:
        f0, p0, m0, t0 = panel.frames, time.process_time(), time.thread_time(), time.monotonic()
        await asyncio.sleep(15)
        dt = time.monotonic() - t0
        main = time.thread_time() - m0
        fps, sc, pn = (panel.frames - f0) / dt, 100 * main / dt, 100 * (time.process_time() - p0 - main) / dt
        status(mode=MODE, error=panel.error, fps=round(fps, 1), scenes=round(sc), panel=round(pn))
        n += 1
        if n % 4 == 0:
            log.info("%s: %.1f кадр/с, сцены %.0f%%, панель %.0f%% ядра", MODE, fps, sc, pn)
        seen = scenes.SEEN | {scenes.NOW}  # что шло за окно и что идёт сейчас (сцена бывает длиннее окна)
        scenes.SEEN.clear()
        hits = busy.take()
        if MODE != "matrix" or n == 1:  # первое окно — со стартом процесса, не в счёт
            continue
        if fps < FPS_WARN:
            if drop is None:
                drop = [time.monotonic() - dt, fps, seen, False, hits]
            else:
                drop[1] = min(drop[1], fps); drop[2] |= seen; drop[4] += hits
            if not drop[3] and time.monotonic() - drop[0] > 600:
                drop[3] = True
                log.warning("просадка продолжается: до %.0f кадр/с уже %d мин, сцены: %s; занято: %s", drop[1],
                            (time.monotonic() - drop[0]) // 60, ", ".join(sorted(drop[2])) or "—",
                            busy_text(drop[4]))
        elif drop:
            sec = time.monotonic() - drop[0] - dt
            log.warning("просадка до %.0f кадр/с, %d с, сцены: %s; занято: %s", drop[1], sec,
                        ", ".join(sorted(drop[2])) or "—", busy_text(drop[4]))
            drop = None


async def watch(panel: Panel | None, s: dict) -> None:
    """Настройки из веба: яркость — сразу, остальное — выход и перезапуск службой systemd."""
    path = DATA / "matrix.json"
    mt = path.stat().st_mtime if path.exists() else 0
    while True:
        await asyncio.sleep(0.5)
        try:
            m = path.stat().st_mtime
        except OSError:
            continue
        if m == mt:
            continue
        mt = m
        nu = settings()
        if {k: v for k, v in nu.items() if k != "brightness"} != {k: v for k, v in s.items() if k != "brightness"}:
            log.info("настройки матрицы изменились — перезапуск")
            try:
                QUICK.touch()
            except OSError:
                pass
            return
        if panel and nu["brightness"] != s["brightness"]:
            panel.base = int(nu["brightness"])  # компоновщик применит с учётом режима
        s = nu


async def sleep_till_morning() -> None:
    """Ночь после «Спокойной ночи»: ни матрицы, ни стаи — ядро свободно. Раз в 30 с — который час (будни или
    выходной и Wake up — с веб-части); утро — выход, systemd поднимает службу заново, уже с матрицей."""
    import night
    feed = Feed()
    log.info("ночь: панель погашена до утра")
    while True:
        try:
            await asyncio.get_running_loop().run_in_executor(None, feed.pull)
        except Exception:
            pass
        if night.mode_now(night.now(), feed.weekend, feed.wake) != "night":
            break
        status(mode="sleep")
        await asyncio.sleep(30)
    NIGHT.unlink(missing_ok=True)
    QUICK.touch()  # утро — без загрузочной заставки
    WOKE.touch()   # но стая просыпается: из искры, тихо
    log.info("утро: запуск матрицы")


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
    s = settings()
    loop = asyncio.get_running_loop()
    task = asyncio.current_task()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, task.cancel)
    backup = asyncio.Event()  # SIGUSR1 — сейчас начнётся образ SD-карты (app.py, tools/backup.sh)
    loop.add_signal_handler(signal.SIGUSR1, backup.set)
    if not s["enabled"]:  # выключена из веба: панель тёмная, ядро свободно; ждём, пока включат
        log.info("матрица выключена")
        status(mode="off")
        try:
            await watch(None, s)
        except asyncio.CancelledError:
            pass
        return
    if NIGHT.exists():
        try:
            await sleep_till_morning()
        except asyncio.CancelledError:
            pass
        return
    quick = QUICK.exists()
    QUICK.unlink(missing_ok=True)
    night.WOKE = WOKE.exists()
    WOKE.unlink(missing_ok=True)
    mind = MindProc() if Image else Mind()  # до матрицы: дочерний процесс — без её потоков
    panel = Panel(s)
    scr, feed = matrix.Screen(), Feed()
    run = asyncio.create_task(scenes.run(scr, feed, mind, boot=not quick))
    bg = [asyncio.create_task(feed_loop(feed, mind)), asyncio.create_task(stats(panel)),
          asyncio.create_task(compositor(scr, mind, panel)), run]

    async def before_backup() -> None:  # сообщение на матрице, потом тёмная панель — дальше службу остановят
        global MODE
        await backup.wait()
        run.cancel()
        try:
            await scenes.backup_notice(scr, mind)
        except Exception:
            log.exception("сообщение о копировании")
            scr.clear()
        MODE = "backup"
        status(mode=MODE)
    bg.append(asyncio.create_task(before_backup()))
    asleep = asyncio.Event()

    def go_sleep() -> None:  # после «Спокойной ночи» (night.py): отметка — и выход, панель гасится в finally
        if panel.hw:
            NIGHT.touch()
            asleep.set()
    night.ON_SLEEP = go_sleep
    try:
        done, _ = await asyncio.wait([asyncio.create_task(watch(panel, s)), asyncio.create_task(asleep.wait())],
                                     return_when=asyncio.FIRST_COMPLETED)
    except asyncio.CancelledError:
        pass
    finally:
        for t in bg:
            t.cancel()
        panel.close()
        if isinstance(mind, MindProc):
            mind.close()


if __name__ == "__main__":
    asyncio.run(main())
