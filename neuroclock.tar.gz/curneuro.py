"""Экран CURRENCY в стиле нейросети — порт neurocur.ino с ESP32-часов.

Нейросеть собирает наверху код валюты; под ним из нейронов рождается шар, раскрывается двумя нейропорталами,
и из правого выезжает блок «стрелка · курс · стрелка»: встаёт по центру, через 2 с барабан проворачивается с
изменения «+0.42» на новый курс (стрелки вверх — подорожал, вниз — подешевел). Блок уезжает в левый портал,
рассыпаясь искрами, порталы съезжаются в шар; код USD и шар распадаются на нейроны, сеть собирает EUR, и всё
повторяется для EUR. Цвет — как у ESP: курс рубля окреп (валюта не подорожала) — зелёный, иначе красный.
"""
from __future__ import annotations

import asyncio
import math

from matrix import BLUE, GREEN, RED, W, Screen, center_x, glyph, morph, rnd, text_points
from ticker import OPEN, PR, PW, SPLIT, Row, dim

AW = 7  # ширина стрелки


class Grp:
    """Блок одной валюты: a — изменение, b — курс (одной длины), барабан, тренд, цвет."""

    def __init__(self, code: str, cur: dict, k: int):
        v, dl = cur["value"], cur["delta"]
        a = "0.00" if abs(dl) < .005 else f"{dl:+.2f}"
        b = f"{v:.2f}"
        L = max(len(a), len(b))
        self.a, self.b = a.rjust(L), b.rjust(L)
        self.L = min(8, L)
        self.w = AW + 2 + self.L * 6 + 1 + AW
        self.trend = (dl > .005) - (dl < -.005)
        self.col = GREEN if dl <= .005 else RED
        self.k, self.code = k, code
        up = self.trend >= 0
        self.seq = []
        for c in range(self.L):
            x, y = self.a[c], self.b[c]
            mid = [str((int(x) + (j if up else 10 - j)) % 10) if x.isdigit() else str((c * 3 + j * 7) % 10) for j in (1, 2, 3)]
            self.seq.append([x] + mid + [y])

    def center(self) -> int:
        return (W - self.w) // 2


class Cur:
    def __init__(self, scr: Screen, y: int):
        self.scr, self.row, self.f = scr, Row(scr, y), 0
        self.title: list = []

    # ---------- блок ----------
    def arrow(self, g: Grp, x0: int) -> None:
        """Стрелка тренда высотой в строку: шевроны бегут вверх или вниз, «–» пульсирует (не изменился)."""
        t = self.f * .02
        for y in range(8):
            for x in range(AW):
                a = 0.0
                if g.trend == 0:
                    if y in (3, 4) and 0 < x < AW - 1:
                        a = .45 + .55 * (.5 + .5 * math.sin(t * 4))
                else:
                    ph = math.fmod(t * 12, 5)
                    for k in range(-1, 3):
                        yc = k * 5 + 5 - ph if g.trend > 0 else k * 5 + ph - 1
                        d = abs(x - 3)
                        yy = rnd(yc + (d if g.trend > 0 else 3 - d))
                        if yy == y and d < 4:
                            a = max(a, .35 + .65 * math.sin(math.pi * (y + .5) / 8))  # к краям строки тускнеет
                if a > 0:
                    self.row.put(x0 + x, y, dim(g.col, a), x0 + x + 31 * g.k, 2)

    def number(self, g: Grp, x0: int, fr: int) -> None:
        """fr < 0 — изменение «+0.42», иначе кадр барабана: разряды трогаются по очереди, отскок в конце."""
        K, D, F, up = 3, 3, 28, g.trend >= 0
        for i in range(g.L):
            sq = g.seq[i]
            still = fr < 0 or (sq[0] == sq[4] and not sq[0].isdigit())  # точка и пробел не крутятся
            t = 0 if fr < 0 else 1 if still else min(1.0, max(0.0, (fr - i * D) / F))
            u = t - 1
            o = ((0 if fr < 0 else (K + 1) * 8) if still else (1 + 1.7 * u ** 3 + .7 * u * u) * (K + 1) * 8)
            moving = 0 < t < 1
            for j in range(K + 2):
                gy = j * 8 - o if up else o - j * 8
                if abs(gy) >= 8:
                    continue
                cols = glyph(sq[j])
                for c in range(5):
                    for r in range(8):
                        if not cols[c] >> r & 1:
                            continue
                        yy = r + rnd(gy)
                        if not 0 <= yy <= 7:
                            continue
                        s = .35 + .65 * math.sin(math.pi * (yy + .5) / 8) if moving else 1  # цилиндр: у краёв темнее
                        px = x0 + i * 6 + c
                        self.row.put(px, yy, dim(g.col, s) if s < 1 else g.col, px + 31 * g.k, 5)

    def group(self, g: Grp, xs: int, fr: int) -> None:
        self.arrow(g, xs)
        self.number(g, xs + AW + 2, fr)
        self.arrow(g, xs + g.w - AW)

    async def frame(self, g: Grp | None, x: int, fr: int) -> None:
        """Кадр строки: блок на месте x, порталы раскрыты, искры летят влево."""
        row = self.row
        row.portal(0, self.f, -1); row.portal(1, self.f, -1)  # только положения узлов — к ним летят точки
        if g:
            self.group(g, x, fr)
        row.sparks()
        row.portal(0, self.f, 1); row.portal(1, self.f, 1)
        row.show()
        self.f += 1
        await self.scr.frame()

    async def hold(self, g: Grp, sec: float, rolled: bool) -> None:
        loop = asyncio.get_running_loop()
        end = loop.time() + sec
        while loop.time() < end:
            await self.frame(g, g.center(), 999 if rolled else -1)

    # ---------- код валюты наверху ----------
    async def set_title(self, t: str) -> None:
        B = text_points(t, center_x(t), 0)
        await morph(self.scr, self.title, [BLUE] * len(self.title), B, BLUE, area=(0, 0, W, 11))
        self.title = B

    async def dissolve_to(self, t: str) -> None:
        """Код валюты и шар распадаются на нейроны, сеть собирает новый код (над часами)."""
        A = self.title + self.row.bp
        ca = [BLUE] * len(self.title) + self.row.bc
        B = text_points(t, center_x(t), 0)
        await morph(self.scr, A, ca, B, BLUE, area=(0, 0, W, 24))
        self.title = B

    # ---------- валюта целиком ----------
    async def show(self, g: Grp) -> None:
        """Шар из нейронов → порталы → блок выезжает из правого, барабан → уезжает в левый → порталы
        съезжаются в шар; шар остаётся на экране."""
        self.row.clear()
        await self.row.ball_in(OPEN)
        self.f = OPEN
        for x in range(PR, g.center() - 1, -1):  # выезжает из правого портала
            await self.frame(g, x, -1)
        await self.hold(g, 2, False)
        for fr in range((g.L - 1) * 3 + 29):  # барабан
            await self.frame(g, g.center(), fr)
        await self.hold(g, 3, True)
        x = g.center()
        while x + g.w >= PW - 2:  # уходит в левый
            await self.frame(g, x, 999)
            x -= 1
        for _ in range(12):  # последние искры
            await self.frame(None, 0, 0)
        await self.row.ball_close(self.f)
        self.f += SPLIT + 6


async def currency(scr: Screen, clock, mind) -> bool:
    """Весь экран курсов: USD целиком, распад на нейроны и EUR, EUR целиком. False — курсов нет."""
    cur = clock.currency or {}
    groups = [Grp(c, cur[c], k) for k, c in enumerate(("USD", "EUR")) if c in cur]
    if not groups:
        return False
    c = Cur(scr, 12)
    await c.set_title(groups[0].code)
    for n, g in enumerate(groups):
        if n:
            await c.dissolve_to(g.code)
        await c.show(g)
    return True
