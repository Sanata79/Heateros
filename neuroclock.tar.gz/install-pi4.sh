#!/usr/bin/env bash
# Install the staged NeuroClockPi services on the dedicated Raspberry Pi 4.
set -euo pipefail

if [[ $EUID != 0 || ${SUDO_USER:-} != sasha ]]; then
    printf '%s\n' 'Run this installer as sasha with sudo.' >&2
    exit 1
fi
root=/home/sasha/nc
kind=$(tr -d '\0' </proc/device-tree/model)
if [[ $kind != 'Raspberry Pi 4 Model B'* ]]; then
    printf 'Expected a Raspberry Pi 4 Model B, found %s\n' "$kind" >&2
    exit 1
fi

install_power_permissions() (
    rule=$(mktemp /etc/sudoers.d/.neuroclock-power.XXXXXX)
    trap 'rm -f -- "$rule"' EXIT
    printf '%s\n' 'sasha ALL=(root) NOPASSWD: /usr/bin/systemctl reboot, /usr/bin/systemctl poweroff' > "$rule"
    chmod 0440 "$rule"
    /usr/sbin/visudo -cf "$rule"
    mv -fT "$rule" /etc/sudoers.d/090-neuroclock-power
)

install_update_support() (
    units=(neuroclock-update.service neuroclock-update-now.service neuroclock-update.timer)
    for unit in "${units[@]}"; do test -f "$root/current/$unit"; done
    rule=$(mktemp /etc/sudoers.d/.neuroclock-update.XXXXXX)
    trap 'rm -f -- "$rule"' EXIT
    printf '%s\n' 'sasha ALL=(root) NOPASSWD: /usr/bin/systemctl start --no-block neuroclock-update-now.service, /usr/bin/systemctl restart neuroclock.service, /usr/bin/systemctl try-restart neuroclock-matrix.service' > "$rule"
    chmod 0440 "$rule"
    /usr/sbin/visudo -cf "$rule"
    for unit in "${units[@]}"; do install -m 0644 "$root/current/$unit" /etc/systemd/system/; done
    for unit in neuroclock-update.service neuroclock-update-now.service; do
        install -d -m 0755 "/etc/systemd/system/$unit.d"
        printf '[Service]\nEnvironment=NC_PI4=1\n' > "/etc/systemd/system/$unit.d/pi4.conf"
    done
    mv -fT "$rule" /etc/sudoers.d/091-neuroclock-update
)

if [[ ${1:-} == --power-only && $# == 1 ]]; then
    install_power_permissions
    exit
fi
if [[ ${1:-} == --updates-only && $# == 1 ]]; then
    install_update_support
    systemctl daemon-reload
    systemctl enable --now neuroclock-update.timer
    exit
fi
if [[ $# != 0 ]]; then
    printf '%s\n' 'Usage: install-pi4.sh [--power-only|--updates-only]' >&2
    exit 2
fi

test -f "$root/current/app.py"
test -f "$root/current/nc_portal.py"

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends iw python3-aiohttp python3-paho-mqtt python3-pil
install -m 0644 "$root/current/neuroclock.service" "$root/current/neuroclock-matrix.service" /etc/systemd/system/
install -d -m 0755 /etc/systemd/system/neuroclock.service.d /etc/systemd/system/neuroclock-matrix.service.d
cat > /etc/systemd/system/neuroclock.service.d/pi4.conf <<'UNIT'
[Service]
Environment=NEUROCLOCK_MATRIX_BACKEND=portal
Environment=NEUROCLOCK_MQTT_CLIENT_ID=neuroclock-pi4
UNIT
cat > /etc/systemd/system/neuroclock-matrix.service.d/pi4.conf <<'UNIT'
[Service]
User=sasha
SupplementaryGroups=dialout
Environment=NEUROCLOCK_MATRIX_BACKEND=portal
Environment=NEUROCLOCK_RUNTIME_DIR=/run/neuroclock-matrix
RuntimeDirectory=neuroclock-matrix
RuntimeDirectoryPreserve=restart
ExecStart=
ExecStart=/usr/bin/python3 /home/sasha/nc/current/nc_matrix.py
UNIT
install_power_permissions
install_update_support
systemctl daemon-reload
systemctl enable --now neuroclock-update.timer
systemctl enable neuroclock.service neuroclock-matrix.service
systemctl restart neuroclock.service neuroclock-matrix.service
systemctl --no-pager is-active neuroclock.service neuroclock-matrix.service
