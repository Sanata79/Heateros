"""Экран 64x32 NeuroClock и нейросеть — порт ainet.ino с ESP32-часов.

Screen — то, что сейчас рисует сцена; на панель его вместе со стаей (mind.py) отдаёт компоновщик nc_matrix.py.
Эффект собирает кадр в своём буфере со сложением света (линии, хвосты, вспышки) и выводит только свою
область, как hiShow на ESP32. Кадр — 20 мс, как animDelay(20) в прошивке, поэтому темп тот же.
"""
from __future__ import annotations

import asyncio
import math
import random

import fonts

W, H = 64, 32
RED, GREEN, BLUE, WHITE, BLACK = (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 255), (0, 0, 0)
FRAME = 0.02


def rnd(v: float) -> int:  # как lround в C: половина — от нуля
    return int(v + 0.5) if v >= 0 else -int(0.5 - v)


class Screen:
    def __init__(self):
        self.px = bytearray(W * H * 3)
        self.version = 0
        self._next = 0.0
        self.dim = 1.0  # доля дневной яркости панели: вечером и утром меньше (night.py)

    def set(self, x: int, y: int, c) -> None:
        if 0 <= x < W and 0 <= y < H:
            i = (y * W + x) * 3
            px = self.px
            px[i] = int(c[0]); px[i + 1] = int(c[1]); px[i + 2] = int(c[2])

    def get(self, x: int, y: int) -> tuple:
        i = (y * W + x) * 3
        return tuple(self.px[i:i + 3])

    def fill(self, x: int, y: int, w: int, h: int, c=BLACK) -> None:
        for yy in range(max(0, y), min(H, y + h)):
            for xx in range(max(0, x), min(W, x + w)):
                self.set(xx, yy, c)

    def clear(self) -> None:
        self.px = bytearray(W * H * 3)

    def lit(self) -> tuple[list, list]:
        """Горящие точки и их цвета — из них следующий эффект «стекает» в сеть."""
        pts, cols = [], []
        for y in range(H):
            for x in range(W):
                c = self.get(x, y)
                if any(c):
                    pts.append((x, y)); cols.append(c)
        return pts, cols

    async def frame(self, seconds: float = FRAME) -> None:
        """Кадр готов: показать и выдержать темп (как animDelay в прошивке)."""
        self.version += 1
        loop = asyncio.get_running_loop()
        now = loop.time()
        self._next = max(now, self._next + seconds) if self._next > now - 0.2 else now + seconds
        await asyncio.sleep(max(0.0, self._next - now))

    async def hold(self, seconds: float) -> None:
        self.version += 1
        await asyncio.sleep(seconds)


# ---------- текст ----------
def glyph(ch: str) -> tuple:
    cp = ord(ch)
    if cp in fonts.LOOK:
        cp = ord(fonts.LOOK[cp])
    if 0x20 <= cp < 0x7F:
        return fonts.ASCII[cp - 0x20]
    return fonts.CYR.get(cp, fonts.ASCII[ord("?") - 0x20])


def text_points(text: str, x0: int, y0: int, sx: int = 1, sy: int = 1) -> list:
    pts = []
    for k, ch in enumerate(text):
        cols = glyph(ch)
        for c in range(5):
            for r in range(8):
                if cols[c] >> r & 1:
                    for dx in range(sx):
                        for dy in range(sy):
                            pts.append((x0 + (k * 6 + c) * sx + dx, y0 + r * sy + dy))
    return pts


def center_x(text: str) -> int:  # как getTextArea в прошивке
    return (W - len(text) * 6) // 2


def draw_text(scr: Screen, text: str, x0: int, y0: int, c) -> None:
    for x, y in text_points(text, x0, y0):
        scr.set(x, y, c)


# большие часы: клетки цифр и двоеточие, как bigClockLayout(6) в прошивке
BIG_X = (4, 17, 36, 49)
BIG_Y = 6


def big_points(d: int, j: int) -> list:
    return [(BIG_X[j] + x, BIG_Y + y) for x, y in fonts.BIG[d]]


# ---------- нейросеть ----------
HI_P, HI_R, HI_T = 6, 19.0, 24
GRAD = ((0, 210, 255), (40, 110, 255), (170, 60, 255), (0, 210, 255))


def grad(x: float, t: float) -> tuple:
    """Градиент «ИИ»: бирюза → синий → фиолет → бирюза, бежит по x со временем t."""
    h = x * 0.04 - t
    h = (h - math.floor(h)) * 3
    i = min(2, int(h)); k = h - i; k = k * k * (3 - 2 * k)
    a, b = GRAD[i], GRAD[i + 1]
    return tuple(a[j] + (b[j] - a[j]) * k for j in range(3))


def ease(k: float) -> float:
    return 4 * k * k * k if k < 0.5 else 1 - (-2 * k + 2) ** 3 / 2


class Net:
    def __init__(self, scr: Screen, area=(0, 0, W, H)):
        self.scr = scr
        self.x0, self.y0, self.x1, self.y1 = area
        self.n = max(2, min(4, (self.x1 - self.x0) // 12)) * 4
        self.fb = [0] * (W * H * 3)
        self.nd: list[list] = []  # x, y, vx, vy, hx, hy, ph, born, die
        self.pl = [[-1, 0, 0.0, 0.0] for _ in range(HI_P)]  # a, b, t, sp

    def add(self, x: int, y: int, r: float, g: float, b: float) -> None:
        if self.x0 <= x < self.x1 and self.y0 <= y < self.y1:
            i = (y * W + x) * 3
            fb = self.fb
            fb[i] = min(255, fb[i] + int(r)); fb[i + 1] = min(255, fb[i + 1] + int(g)); fb[i + 2] = min(255, fb[i + 2] + int(b))

    def show(self) -> None:
        px, fb = self.scr.px, self.fb
        for y in range(self.y0, self.y1):
            a, b = (y * W + self.x0) * 3, (y * W + self.x1) * 3
            px[a:b] = bytes(fb[a:b])
        self.fb = [0] * (W * H * 3)

    def line(self, x0, y0, x1, y1, r, g, b) -> None:
        n = math.ceil(max(abs(x1 - x0), abs(y1 - y0)))
        for s in range(1, n):
            k = s / n
            self.add(rnd(x0 + (x1 - x0) * k), rnd(y0 + (y1 - y0) * k), r, g, b)

    def spawn(self, i: int, x: float, y: float, born: int, die: int) -> None:
        a, v = random.uniform(0, 6.283), random.uniform(0.6, 1.3)
        nc = self.n // 4
        w = self.x1 - self.x0
        jx = w / (nc * 4)
        hx = self.x0 + w * ((i % nc) + 0.5) / nc + random.uniform(-jx, jx)
        hy = self.y0 + 4 + (i // nc) * (self.y1 - self.y0 - 8) / 3 + random.uniform(-2, 2)
        nd = [x, y, math.cos(a) * v, math.sin(a) * v, hx, hy, random.uniform(0, 6.283), born, die]
        if i < len(self.nd):
            self.nd[i] = nd
        else:
            self.nd.append(nd)

    def alpha(self, i: int, f: int) -> float:
        n = self.nd[i]
        return min(1.0, max(0.0, (f - n[7]) / 10)) * min(1.0, max(0.0, (n[8] - f) / 20))

    def dist(self, a: int, b: int) -> float:
        return math.hypot(self.nd[a][0] - self.nd[b][0], self.nd[a][1] - self.nd[b][1])

    def step(self, f: int, pulses: bool) -> None:
        """Дрейф узлов, связи, сигналы по связям (pulses — запускать ли новые)."""
        al = [self.alpha(i, f) for i in range(self.n)]
        for n in self.nd:
            if f < n[7]:
                continue
            n[2] = (n[2] + (n[4] + math.sin(f * 0.05 + n[6]) * 2.5 - n[0]) * 0.04) * 0.88
            n[3] = (n[3] + (n[5] + math.cos(f * 0.04 + n[6]) * 1.5 - n[1]) * 0.04) * 0.88
            n[0] = min(self.x1 - 1.0, max(float(self.x0), n[0] + n[2]))
            n[1] = min(self.y1 - 1.0, max(float(self.y0), n[1] + n[3]))
        for i in range(self.n):
            for j in range(i + 1, self.n):
                w = min(al[i], al[j])
                if w <= 0:
                    continue
                d = self.dist(i, j)
                if d < HI_R:
                    w *= 1 - d / HI_R
                    self.line(self.nd[i][0], self.nd[i][1], self.nd[j][0], self.nd[j][1], 55 * w, 25 * w, 130 * w)
        for i in range(self.n):
            a = al[i]
            if a <= 0:
                continue
            x, y = rnd(self.nd[i][0]), rnd(self.nd[i][1])
            self.add(x, y, 0, 170 * a, 255 * a)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                self.add(x + dx, y + dy, 0, 30 * a, 70 * a)
        for s in self.pl:
            if s[0] < 0:  # новый сигнал — на случайную живую связь
                if not pulses or random.randrange(4):
                    continue
                a, b = random.randrange(self.n), random.randrange(self.n)
                if a == b or al[a] < 0.6 or al[b] < 0.6 or self.dist(a, b) >= HI_R:
                    continue
                s[:] = [a, b, 0.0, random.uniform(0.07, 0.13)]
            a, b = s[0], s[1]
            w = min(al[a], al[b])
            for k, q in ((0, 1.0), (1, 0.45), (2, 0.18)):  # голова и хвост
                t = s[2] - k * 0.1
                if t < 0:
                    break
                na, nb = self.nd[a], self.nd[b]
                self.add(rnd(na[0] + (nb[0] - na[0]) * t), rnd(na[1] + (nb[1] - na[1]) * t), 200 * w * q, 240 * w * q, 255 * w * q)
            s[2] += s[3]
            if s[2] >= 1:  # дошёл — передаётся дальше соседу
                nx = -1
                for _ in range(8):
                    j = random.randrange(self.n)
                    if j != a and j != b and al[j] > 0.6 and self.dist(b, j) < HI_R:
                        nx = j
                        break
                if nx < 0 or not pulses:
                    s[0] = -1
                else:
                    s[:] = [b, nx, 0.0, s[3]]


def arc(q: list, tx: float, ty: float, e: float, k: float) -> tuple:
    """Положение точки на дуге от (sx, sy) к (tx, ty); e — пройденная доля пути."""
    dx, dy = tx - q[0], ty - q[1]
    l = max(1.0, math.hypot(dx, dy))
    s = math.sin(math.pi * k) * q[3]
    return q[0] + dx * e - dy / l * s, q[1] + dy * e + dx / l * s


async def morph(scr: Screen, A: list, ca, B: list, cb=None, beam: bool = False, area=(0, 0, W, H),
                frame: float = FRAME) -> None:
    """Перетекание через сеть (hiMorph): точки A (цвета ca, без них — градиент) стекают в узлы, сеть «думает»,
    узлы дугами собирают B слева направо — цветом cb (один цвет или список по точкам, None — градиент);
    beam — по B проходит луч распознавания. Без A сеть рождается из пустоты, без B — гаснет."""
    net = Net(scr, area)
    n = net.n
    bx0 = min((p[0] for p in B), default=W); bx1 = max((p[0] for p in B), default=0)
    by0 = min((p[1] for p in B), default=area[3]); by1 = max((p[1] for p in B), default=area[1])
    FA = 34 if A else 50
    db = []  # sx, sy, d, arc, j
    last_b = 0
    for p in B:
        d = FA + int((p[0] - bx0) * 0.8) + random.randrange(6)
        db.append([0.0, 0.0, d, random.randint(-4, 4), random.randrange(n)])
        last_b = max(last_b, d + HI_T + 5)
    da = [[float(p[0]), float(p[1]), random.randrange(14), random.randint(-5, 5), random.randrange(n)] for p in A]
    for i in range(n):
        die = last_b - 8 + random.randrange(16) if B else 34 + random.randrange(16)
        if A:
            e = random.choice(A)
            net.spawn(i, e[0], e[1], random.randrange(6), die)
        else:
            net.spawn(i, random.uniform(area[0] + 2, area[2] - 2), random.uniform(area[1] + 2, area[3] - 2), random.randrange(20), die)
    FS = last_b
    FE = FS + (bx1 - bx0 + 8) // 2 if beam and B else last_b
    end = max([FE] + [nd[8] for nd in net.nd])

    def color(i: int) -> tuple:
        if isinstance(cb, list):
            return cb[i]
        return cb if cb else grad(B[i][0], 0)

    for f in range(end + 1):
        net.step(f, 6 <= f < FA + 30)
        for i, q in enumerate(da):  # A стекает в свой узел и гаснет
            k = max(0.0, (f - q[2]) / 18)
            if k >= 1:
                continue
            nd = net.nd[q[4]]
            x, y = arc(q, nd[0], nd[1], k * k, k)
            r, g, b = ca[i] if ca else grad(q[0], 0)
            m = 1 - k
            net.add(rnd(x), rnd(y), (r + (170 - r) * k) * m, (g + (60 - g) * k) * m, b * m)
        bx = bx0 - 4 + (f - FS) * 2
        for i, q in enumerate(db):  # узлы собирают B
            if f < q[2]:
                continue
            if f == q[2]:
                q[0], q[1] = net.nd[q[4]][0], net.nd[q[4]][1]
            k = (f - q[2]) / HI_T
            px, py = B[i]
            if k < 1:  # летит с хвостом, фиолет → бирюза
                for s, m in ((0, 0.5 + 0.5 * k), (1, 0.35), (2, 0.12)):
                    kk = k - s * 0.05
                    if kk < 0:
                        break
                    x, y = arc(q, px, py, ease(kk), kk)
                    net.add(rnd(x), rnd(y), (170 - 170 * kk) * m, (70 + 130 * kk) * m, 255 * m)
                continue
            a = f - q[2] - HI_T
            if beam and not (f >= FS and px < bx - 1):
                r, g, b = 0, 120, 180  # ждёт луча
            else:
                r, g, b = color(i)
            if a < 5:  # вспышка на месте
                w = 1 - a / 5
                r, g, b = r + (255 - r) * w, g + (255 - g) * w, b + (255 - b) * w
            if beam and f >= FS and abs(px - bx) < 1.5:
                r = g = b = 255
            net.add(px, py, r, g, b)
        if beam and B and FS <= f <= FE:
            for y in range(by0 - 3, by1 + 4):
                net.add(rnd(bx), y, 0, 60, 90); net.add(rnd(bx) - 1, y, 0, 18, 30); net.add(rnd(bx) + 1, y, 0, 18, 30)
        net.show()
        await scr.frame(frame)
    for i, p in enumerate(B):
        net.add(p[0], p[1], *color(i))
    net.show()  # начисто: только готовая B
    await scr.frame(frame)
