"""Пробуждение NeuroClock — загрузка, которую ведёт стая (вместо порта bootfx.ino с ESP32).

1. Рождение: в темноте бьётся одна искра — тук-тук, — и делится: 1 → 2 → 4 … → 30; между нейронами
   прорастают синапсы, по ним бегут первые импульсы.
2. Имя: каждый нейрон тянет нить и выписывает свой кусок NEURO (красным) / CLOCK (бирюзой); дописали —
   стая разом вспыхивает, надпись светлеет: узнала своё имя.
3. Разрыв: синапсы ощупывают буквы, цепляют пиксели и растаскивают их в нейроны — стая «съела» своё имя
   и разгорается.
4. Мир: на каждую проверку (Wi-Fi, время, система, погода, MQTT, обновление) стая выписывает значок и мелкую
   подпись (IP, время, …); проверка прошла — значок вспыхивает зелёным (нет — красным), стая забирает его в
   себя, и один нейрон остаётся гореть этим цветом — нейрон памяти. Шесть их — вместо полосы загрузки.
5. Пробуждение: стая разом вспыхивает (нейроны памяти растворяются в ней) и выписывает сомкнутые веки —
   дальше глаза просыпаются (night.Eyes.wake): часы ожили и увидели человека; стая живёт вокруг них.

Стая загрузки рисуется в кадр сцены сама (свет складывается, как в Net у морфа), настоящая стая (mind) на
это время погашена.
"""
from __future__ import annotations

import math
import random
import socket

from clockrow import now
from matrix import H, RED, W, Screen, rnd, text_points

try:  # на Pi синапсы рисует PIL (на C — Pi Zero иначе не успевает за 20 мс)
    from PIL import Image, ImageChops, ImageDraw
except ImportError:  # превью на Mac — линии рисует Python
    Image = None

CYAN = (0, 200, 255)
OK, FAIL = (60, 255, 90), (255, 40, 40)
N = 30
LINK = 11.0     # синапс — между нейронами ближе этого
LINKS = 3       # и не больше трёх у нейрона (в плотном значке иначе связан каждый с каждым — 180 линий на кадр)
CX, CY = 31.5, 15.5


def clamp(v, a=0.0, b=1.0):
    return max(a, min(b, v))


class Brain:
    """Стая загрузки: нейроны (x, y, vx, vy, вспышка, заряд, проявленность), синапсы, импульсы."""

    def __init__(self, scr: Screen):
        self.scr = scr
        self.nd: list[list] = []
        self.pl: list[list] = []   # импульсы: a, b, t, скорость
        self.fb = [0] * (W * H * 3)
        self.sep = 3.0             # на каком расстоянии нейроны расталкиваются — растёт с колонией
        self.pulses = False
        self.near: list = []       # близкие пары (d², i, j) — считает move(), рисует draw()
        self.adj: list = []        # кто с кем связан синапсом
        self.lv = 1.0              # общая яркость
        self.mem: dict = {}        # нейроны памяти: пройденный этап — нейрон горит его цветом (зелёный / красный)
        self.tint = None           # один цвет на всё, без вспышек (ранняя серая стая утра — early)
        self.base = None           # неподвижный экран под стаей (bytes): стая меняет на нём только своё (swap)
        self.mix = 0.0             # 0 — цвет tint, 1 — обычные цвета стаи (серая становится голубой — dawn)
        self.st = bytearray(W * H * 3)  # неподвижные точки (буквы, значок): кладутся раз, к кадру — целиком
        self.lut, self._gk = None, None  # их яркость: таблица на 768 (по 256 на цвет) или None
        if Image:  # слой синапсов: линии — PIL, к точкам он прибавляется в show()
            self.lay = Image.new("RGB", (W, H))
            self.dr = ImageDraw.Draw(self.lay)

    # ---------- свет ----------
    def add(self, x: int, y: int, r: float, g: float, b: float) -> None:
        if 0 <= x < W and 0 <= y < H:
            i = (y * W + x) * 3
            fb = self.fb
            v = fb[i] + int(r); fb[i] = v if v < 255 else 255
            v = fb[i + 1] + int(g); fb[i + 1] = v if v < 255 else 255
            v = fb[i + 2] + int(b); fb[i + 2] = v if v < 255 else 255

    def line(self, x0, y0, x1, y1, r, g, b) -> None:
        """Отрезок без концов (концы — нейроны). Одним циклом — на Pi это большая часть кадра;
        тусклее, чем видно на матрице, — не рисуется."""
        r, g, b = int(r), int(g), int(b)
        if r < 4 and g < 4 and b < 4:
            return
        if Image:
            self.dr.line((int(x0 + .5), int(y0 + .5), int(x1 + .5), int(y1 + .5)), fill=(min(r, 255), min(g, 255), min(b, 255)))
            return
        n = math.ceil(max(abs(x1 - x0), abs(y1 - y0)))
        if n < 2:
            return
        fb = self.fb
        sx, sy = (x1 - x0) / n, (y1 - y0) / n
        x, y = x0 + .5, y0 + .5  # +.5 — округление через int
        for _ in range(n - 1):
            x += sx; y += sy
            if 0 <= x < W and 0 <= y < H:
                i = (int(y) * W + int(x)) * 3
                v = fb[i] + r; fb[i] = v if v < 255 else 255
                v = fb[i + 1] + g; fb[i + 1] = v if v < 255 else 255
                v = fb[i + 2] + b; fb[i + 2] = v if v < 255 else 255

    def put(self, x: int, y: int, c) -> None:
        """Неподвижная точка (или (0, 0, 0) — убрать)."""
        if 0 <= x < W and 0 <= y < H:
            i = (y * W + x) * 3
            st = self.st
            st[i] = min(255, int(c[0])); st[i + 1] = min(255, int(c[1])); st[i + 2] = min(255, int(c[2]))

    def glow(self, up: float = 1.0, extra=(0, 0, 0)) -> None:
        """Яркость неподвижных точек: ×up и +extra по цветам (чёрное остаётся чёрным)."""
        key = (round(up, 2), tuple(int(e) for e in extra))
        if key == self._gk:
            return
        self._gk = key
        up, extra = key
        self.lut = None if key == (1.0, (0, 0, 0)) else \
            [0 if v == 0 else min(255, int(v * up + extra[c])) for c in range(3) for v in range(256)]

    def show(self) -> None:
        if Image:
            st = Image.frombytes("RGB", (W, H), bytes(self.st))
            if self.lut:
                st = st.point(self.lut)
            out = ImageChops.add(ImageChops.add(Image.frombytes("RGB", (W, H), bytes(self.fb)), self.lay), st)
            if self.base:
                out = ImageChops.add(out, Image.frombytes("RGB", (W, H), self.base))
            self.scr.px = bytearray(out.tobytes())
            self.lay.paste((0, 0, 0), (0, 0, W, H))
        else:
            fb, st, lut, base = self.fb, self.st, self.lut, self.base
            for i in range(W * H * 3):
                v = st[i]
                if v:
                    if lut:
                        v = lut[i % 3 * 256 + v]
                    v += fb[i]
                    fb[i] = v if v < 255 else 255
                if base and base[i]:
                    v = fb[i] + base[i]
                    fb[i] = v if v < 255 else 255
            self.scr.px = bytearray(fb)
        self.fb = [0] * (W * H * 3)

    # ---------- жизнь ----------
    def spawn(self, x: float, y: float, vx=0.0, vy=0.0) -> list:
        n = [x, y, vx, vy, 1.0, random.random() * .4, 0.0]
        self.nd.append(n)
        return n

    def divide(self) -> None:
        """Каждый нейрон делится надвое: дочерний отталкивается в сторону, оба вспыхивают."""
        for n in list(self.nd):
            if len(self.nd) >= N:
                break
            a, v = random.uniform(0, 6.283), random.uniform(.35, .6)
            dx, dy = math.cos(a) * v, math.sin(a) * v
            c = self.spawn(n[0], n[1], n[2] + dx, n[3] + dy)
            c[6] = n[6] * .6
            n[2] -= dx; n[3] -= dy; n[4] = 1.0

    def move(self, targets: dict | None = None, centre: float = 1.0, damp: float = .9, jitter: float = .02) -> None:
        """Шаг: расталкиваются ближе sep, тянутся к центру (centre — сила), к своей цели (targets: i → x, y, k).
        Расстояния пар — один раз за кадр (на Pi это заметная доля кадра): заодно близкие пары для синапсов (near)."""
        nd, sep = self.nd, self.sep
        n, sep2, L2 = len(nd), sep * sep, LINK * LINK
        fx = [(CX - a[0]) * .0015 * centre for a in nd]
        fy = [(CY - a[1]) * .003 * centre for a in nd]
        near = []
        for i in range(n):
            ax, ay = nd[i][0], nd[i][1]
            for j in range(i + 1, n):
                b = nd[j]
                dx, dy = ax - b[0], ay - b[1]
                d2 = dx * dx + dy * dy
                if d2 < L2:
                    near.append((d2, i, j))
                if d2 < sep2:
                    d = math.sqrt(d2) or .01
                    k = (sep - d) / sep * .05 / d
                    fx[i] += dx * k; fy[i] += dy * k
                    fx[j] -= dx * k; fy[j] -= dy * k
        near.sort()
        self.near = near
        for i, a in enumerate(nd):
            gx, gy = fx[i], fy[i]
            if targets and i in targets:
                tx, ty, k = targets[i]
                gx += (tx - a[0]) * k; gy += (ty - a[1]) * k
            a[2] = (a[2] + gx + random.uniform(-jitter, jitter)) * damp
            a[3] = (a[3] + gy + random.uniform(-jitter, jitter)) * damp
            a[0] += a[2]; a[1] += a[3]
            if not .5 <= a[0] <= W - 1.5:
                a[2] *= -.5; a[0] = clamp(a[0], .5, W - 1.5)
            if not .5 <= a[1] <= H - 1.5:
                a[3] *= -.5; a[1] = clamp(a[1], .5, H - 1.5)

    def think(self, rate: float = .012) -> None:
        """Заряд копится, накопил — вспышка и импульсы соседям; дошедший импульс подзаряжает."""
        nd = self.nd
        for i, a in enumerate(nd):
            a[6] = min(1.0, a[6] + .04)
            a[4] *= .9
            if not self.pulses:
                continue
            a[5] += rate * random.uniform(.5, 1.5)
            if a[5] >= 1:
                a[5], a[4] = 0.0, 1.0
                for j in self.adj[i] if i < len(self.adj) else ():  # импульсы — по видимым синапсам
                    if random.random() < .5 and len(self.pl) < 24:
                        self.pl.append([i, j, 0.0, random.uniform(.06, .11)])
        keep = []
        for p in self.pl:
            p[2] += p[3]
            if p[2] >= 1:
                nd[p[1]][5] += .25
            else:
                keep.append(p)
        self.pl = keep

    def draw(self, links: float = 1.0) -> None:
        nd, lv = self.nd, self.lv
        deg = [0] * len(nd)
        adj = [[] for _ in nd]
        for d2, i, j in self.near:  # у нейрона не больше трёх синапсов — к ближайшим, как у главной стаи
            if deg[i] >= LINKS or deg[j] >= LINKS:
                continue
            deg[i] += 1; deg[j] += 1
            adj[i].append(j); adj[j].append(i)
            a, b = nd[i], nd[j]
            w = (1 - math.sqrt(d2) / LINK) * min(a[6], b[6]) * links * lv * (1 if self.tint else 1 + 1.2 * max(a[4], b[4]))
            if self.tint:
                c = self.blend([v * .4 for v in self.tint], (40, 18, 100))
                self.line(a[0], a[1], b[0], b[1], c[0] * w, c[1] * w, c[2] * w)
            else:
                self.line(a[0], a[1], b[0], b[1], 40 * w, 18 * w, 100 * w)
        self.adj = adj  # по ним и импульсы (think)
        for p in self.pl:
            a, b = nd[p[0]], nd[p[1]]
            w = min(a[6], b[6]) * lv
            for k, q in ((0, 1.0), (1, .45), (2, .18)):  # голова и хвост
                t = p[2] - k * .1
                if t < 0:
                    break
                c = self.blend(self.tint, (200, 240, 255)) if self.tint else (200, 240, 255)
                self.add(rnd(a[0] + (b[0] - a[0]) * t), rnd(a[1] + (b[1] - a[1]) * t), c[0] * w * q, c[1] * w * q, c[2] * w * q)
        for k, a in enumerate(nd):
            self.neuron(a[0], a[1], a[6] * lv, a[4], self.mem.get(k))

    def blend(self, tc, nc) -> tuple:
        m = self.mix
        return tuple(tc[i] + (nc[i] - tc[i]) * m for i in range(3))

    def neuron(self, x: float, y: float, al: float, fl: float, mc=None) -> None:
        x, y = rnd(x), rnd(y)
        if self.tint:  # ровный свет своим цветом, без вспышек (mix — уже наполовину обычный)
            r, g, b = self.blend(self.tint, (0, 170, 255))
            hr, hg, hb = self.blend([v * .25 for v in self.tint], (0, 30, 70))
            self.add(x, y, r * al, g * al, b * al)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                self.add(x + dx, y + dy, hr * al, hg * al, hb * al)
            return
        h = al * (1 + 1.5 * fl)
        if mc:  # нейрон памяти — ярче и своим цветом
            r, g, b = mc
            self.add(x, y, (r + (255 - r) * fl) * al, (g + (255 - g) * fl) * al, (b + (255 - b) * fl) * al)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                self.add(x + dx, y + dy, r * .3 * h, g * .3 * h, b * .3 * h)
            return
        self.add(x, y, 220 * fl * al, (170 + 85 * fl) * al, 255 * al)
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            self.add(x + dx, y + dy, 40 * fl * h, 30 * h, 70 * h)


# ---------- 1. рождение ----------
def beat(f: int) -> float:
    """Сердцебиение: тук (сильный) — тук (слабее), пауза; период 36 кадров."""
    t = f % 36
    return math.exp(-t / 3.5) + (.65 * math.exp(-(t - 8) / 3.5) if t >= 8 else 0)


async def birth(scr: Screen, br: Brain) -> None:
    br.nd, br.pl, br.sep, br.pulses = [], [], 2.5, False
    for f in range(84):  # одна искра бьётся в темноте, с каждым ударом ярче
        b = beat(f) * clamp(.35 + f / 84) * br.lv  # утром — тише (wake_up)
        for dy in range(-3, 4):
            for dx in range(-3, 4):
                w = clamp(1 - math.hypot(dx, dy) / (1.6 + 1.6 * b)) * b
                if w > 0:
                    if br.tint:
                        br.add(31 + dx, 15 + dy, br.tint[0] * w, br.tint[1] * w, br.tint[2] * w)
                    else:
                        br.add(31 + dx, 15 + dy, 160 * w * w, 200 * w, 255 * w)
        br.show()
        await scr.frame()
    br.spawn(31, 15)[6] = 1.0
    cuts = (0, 24, 44, 60, 74)  # деления всё чаще: 1 → 2 → 4 → 8 → 16 → 30
    for f in range(170):
        if f in cuts:
            br.divide()
        br.sep = 2.5 + 8.5 * len(br.nd) / N  # колония растёт — расходится по всему экрану
        br.pulses = len(br.nd) >= 8
        br.move(centre=.25 + .35 * (len(br.nd) < 16))
        br.think()
        br.draw()
        br.show()
        await scr.frame()




# ---------- стая пишет: каждый нейрон — свой кусок, нитью от точки к точке ----------
def groups(T: list, n: int, rounds: int = 1) -> list[list[int]]:
    """Точки — на n кусков поблизости (k-средних, rounds проходов): кусок — нить одного нейрона.
    Значку хватает одного прохода; имя (700 точек) — четыре, оно считается заранее."""
    n = min(n, len(T))
    order = sorted(range(len(T)), key=lambda i: (T[i][1] >= 16, T[i][0]))
    seeds = [list(map(float, T[order[int((k + .5) * len(T) / n)]])) for k in range(n)]
    for _ in range(rounds):
        g = [[] for _ in seeds]
        for i, (x, y) in enumerate(T):
            best, bk = 1e9, 0
            for k, (sx, sy) in enumerate(seeds):
                d = (sx - x) * (sx - x) + (sy - y) * (sy - y) * 2
                if d < best:
                    best, bk = d, k
            g[bk].append(i)
        for k in range(n):
            if g[k]:
                seeds[k] = [sum(T[i][0] for i in g[k]) / len(g[k]), sum(T[i][1] for i in g[k]) / len(g[k])]
    return [x for x in g if x]


def chain(T: list, idx: list[int], x: float, y: float) -> list[int]:
    """Порядок, в котором нейрон выписывает свой кусок: от ближайшей точки — к соседней."""
    left, out = list(idx), []
    while left:
        j = min(left, key=lambda i: (T[i][0] - x) ** 2 + (T[i][1] - y) ** 2)
        left.remove(j); out.append(j)
        x, y = T[j]
    return out


class Writing:
    """Стая выписывает точки T цветами cols: кусок — ближайшему нейрону, за ним нить к свежей точке;
    свежая точка вспыхивает белым и сразу в свой цвет, потом ложится в неподвижный слой (br.st).
    step() — кадр письма, hover() — дописали, кружат рядом."""

    def __init__(self, br: Brain, T: list, cols: list, delay: int = 18, G: list | None = None):
        self.br, self.T, self.cols = br, T, list(cols)
        self.free = list(range(len(br.nd)))
        self.job = {}  # нейрон → очередь своих точек
        for g in G or groups(T, len(br.nd)):  # G — куски, разложенные заранее
            gx, gy = sum(T[i][0] for i in g) / len(g), sum(T[i][1] for i in g) / len(g)
            k = min(self.free, key=lambda i: (br.nd[i][0] - gx) ** 2 + (br.nd[i][1] - gy) ** 2)
            self.free.remove(k)
            self.job[k] = chain(T, g, br.nd[k][0], br.nd[k][1])
        self.home = {k: (sum(T[i][0] for i in q) / len(q), sum(T[i][1] for i in q) / len(q)) for k, q in self.job.items()}
        self.lit = [-1] * len(T)  # кадр, когда точку выписали
        self.fresh: list = []     # только что выписанные — ещё вспыхивают
        self.settled: list = []   # устоялись — лежат в br.st
        self.last = {}            # нейрон → его последняя точка (откуда тянется нить)
        self.start = {k: random.randrange(delay + 1) for k in self.job}
        self.f = 0
        br.st = bytearray(W * H * 3)
        br.glow()

    def _wander(self, tg: dict) -> None:
        f = self.f
        for k in self.job:
            if k not in tg:
                hx, hy = self.home[k]
                tg[k] = (hx + math.sin(f * .07 + k) * 3, hy + math.cos(f * .05 + k * 2) * 2, .02)
        for k in self.free:  # лишние нейроны (кусков меньше) кружат по экрану
            tg[k] = (CX + math.sin(f * .03 + k) * 24, CY + math.cos(f * .04 + k) * 12, .01)

    def paint(self, up: float = 1.0, cols=None) -> None:
        """Свежие точки — в кадр; устоялись — в неподвижный слой. cols — другие цвета (итог этапа), up — ярче."""
        br, T = self.br, self.T
        if cols is not None and cols != self.cols:
            self.cols = list(cols)
            for i in self.settled:
                br.put(T[i][0], T[i][1], self.cols[i])
        keep = []
        for i in self.fresh:
            x, y = T[i]
            w = (self.f - self.lit[i]) / 10
            if w >= 1:
                br.put(x, y, self.cols[i]); self.settled.append(i)
                continue
            r, g, b = self.cols[i]
            if br.tint:  # тихо: точка просто проявляется своим цветом
                br.add(x, y, r * w, g * w, b * w)
            else:
                br.add(x, y, 255 * (1 - w) + r * w, 255 * (1 - w) + g * w, 255 * (1 - w) + b * w)
            keep.append(i)
        self.fresh = keep
        e = 60 * (up - 1)
        br.glow(up, (e, e, e))

    def step(self, least: int = 40) -> bool:
        """Кадр письма; True — всё выписано (и прошло не меньше least кадров)."""
        br, T, f, tg = self.br, self.T, self.f, {}
        for k, q in self.job.items():
            if f < self.start[k] or not q:
                continue
            tx, ty = T[q[0]]
            a = br.nd[k]
            if math.hypot(tx - a[0], ty - a[1]) < .8:
                i = q.pop(0)
                self.lit[i] = f; self.fresh.append(i); self.last[k] = (tx, ty)
                if q:
                    tx, ty = T[q[0]]
            tg[k] = (tx, ty, .22)
        self._wander(tg)
        br.sep = 2.0
        br.move(tg, centre=0, damp=.62, jitter=.01)
        br.think(.006)
        br.draw(.45)
        for k, p in self.last.items():  # нить: от нейрона к только что выписанной точке
            if self.job[k]:
                a = br.nd[k]
                t = br.tint or (100, 225, 350)  # нить: голубая, у ранней стаи — её цветом
                br.line(a[0], a[1], p[0], p[1], t[0] * .4, t[1] * .4, t[2] * .4)
        self.paint()
        self.f += 1
        return not any(self.job.values()) and not self.fresh and self.f >= least

    def hover(self, up: float = 1.0, cols=None, lv: float = .6, jitter: float = .01) -> None:
        tg = {}
        self._wander(tg)
        self.br.move(tg, centre=.2, damp=.8, jitter=jitter)
        self.br.think(.006)
        self.br.lv = lv
        self.br.draw(.45)
        self.paint(up, cols)
        self.f += 1


# ---------- 2. имя ----------
def name_plan() -> tuple:
    """Надпись и её куски по нейронам — считается заранее (на Pi это доли секунды), пока экран тёмный."""
    top = text_points("NEURO", 3, 1, 2, 2)
    T = top + text_points("CLOCK", 3, 17, 2, 2)
    return T, [RED] * len(top) + [CYAN] * (len(T) - len(top)), groups(T, N, 4)


async def name(scr: Screen, br: Brain, plan: tuple | None = None) -> list:
    """Стая выписывает NEURO (красным) / CLOCK (бирюзой); дописала — разом вспыхивает, надпись светлеет."""
    T, after, G = plan or name_plan()
    wr = Writing(br, T, after, G=G)
    while not wr.step():
        br.show()
        await scr.frame()
    for a in br.nd:  # стая узнала своё имя
        a[4] = 1.0
    for g in range(60):
        k = clamp(1 - g / 25)
        wr.hover(1 + .5 * k, lv=.6 + .4 * k)
        br.show()
        await scr.frame()
    return list(zip(T, after))


# ---------- 3. разрыв на нейроны ----------
async def absorb(scr: Screen, br: Brain, P: list, feel: int = 55, grab: int = 70, wave: bool = True,
                 flash: float = .8, lv_to: float = 1.0) -> None:
    """Синапсы ощупывают точки P (точка, цвет), цепляют их и растаскивают в нейроны; wave — потом по стае
    волна вспышек: разгорелась. flash — вспышка нейрона, поймавшего точку; lv_to — до какой яркости стая
    разгорается, съев всё (засыпание — не разгорается). Точки на месте — в неподвижном слое (br.st)."""
    nd, n = br.nd, len(P)
    home = [p[0] for p in P]
    col = [p[1] for p in P]
    own, dist = [], []
    for x, y in home:  # чья точка — ближайшего нейрона
        best, bk = 1e9, 0
        for k, a in enumerate(nd):
            d = (a[0] - x) * (a[0] - x) + (a[1] - y) * (a[1] - y)
            if d < best:
                best, bk = d, k
        own.append(bk); dist.append(math.sqrt(best))
    order = sorted(range(n), key=lambda i: dist[i] + random.uniform(0, 4))
    go = [0] * n
    start: dict = {}
    for r, i in enumerate(order):  # ближние срываются первыми
        go[i] = feel + int(r / n * grab)
        start.setdefault(go[i], []).append(i)
    fly = [random.randint(12, 20) for _ in range(n)]
    cnt, sx, sy = [0] * len(nd), [0.0] * len(nd), [0.0] * len(nd)  # что у нейрона ещё на месте
    br.st = bytearray(W * H * 3)
    for i, (x, y) in enumerate(home):
        br.put(x, y, col[i])
        k = own[i]; cnt[k] += 1; sx[k] += x; sy[k] += y
    flying, eaten = [], 0
    lv0 = br.lv
    br.sep = 9.0
    f = 0
    while eaten < n or (wave and f < feel + grab + 40):
        for i in start.get(f, ()):  # сорвалась
            x, y = home[i]
            br.put(x, y, (0, 0, 0))
            k = own[i]; cnt[k] -= 1; sx[k] -= x; sy[k] -= y
            flying.append(i)
        tg = {}
        for k, a in enumerate(nd):
            if not cnt[k]:
                tg[k] = (CX + (a[0] - CX) * 1.02, CY + (a[1] - CY) * 1.02, .004)  # своё съел — отплывает
                continue
            mx, my = sx[k] / cnt[k], sy[k] / cnt[k]
            if f < feel:  # подкрадывается к своим точкам
                tg[k] = (mx + math.sin(f * .2 + k) * 2, my + math.cos(f * .17 + k) * 2, .03)
            else:  # тянет на себя — отходит, канат натягивается
                tg[k] = (a[0] + (a[0] - mx) * .3, a[1] + (a[1] - my) * .3, .015)
        br.move(tg, centre=.1, damp=.82)
        br.pulses = True
        br.think(.01)
        br.lv = min(1.0, lv0 + (lv_to - lv0) * eaten / n)
        br.draw(.6)
        fe = clamp(f / feel) if feel else 1.0
        br.glow(1 + .35 * fe, (0, 30 * fe, 30 * fe))  # синапсы ощупывают — точки ярче
        if f < feel + 20:  # касания: дрожащие синапсы к своим точкам
            for _ in range(int(8 * fe)):
                i = random.randrange(n)
                if f < go[i] and dist[i] < 7:
                    a = nd[own[i]]
                    br.line(a[0], a[1], home[i][0], home[i][1], 40, 70, 120)
        keep = []
        for i in flying:
            a = nd[own[i]]
            k = (f - go[i]) / fly[i]
            if k >= 1:  # дошла — нейрон вспыхивает и заряжается
                eaten += 1
                a[4] = max(a[4], flash); a[5] += .12
                continue
            e = k * k * k  # сперва нехотя, потом рывком
            hx, hy = home[i]
            x = hx + (a[0] - hx) * e; y = hy + (a[1] - hy) * e
            m = 1 - k
            r, g, b = col[i]
            if i & 1:  # натянутый синапс — у каждой второй: рывком летит сотня точек, линий хватает
                br.line(x, y, a[0], a[1], 30 * m, 60 * m, 110 * m)
            br.add(rnd(x), rnd(y), r * m + 200 * k, g * m + 230 * k, b * m + 255 * k)
            keep.append(i)
        flying = keep
        br.show()
        await scr.frame()
        f += 1
    br.glow()
    if not wave:
        return
    for k, a in enumerate(nd):  # стая разгорелась: волна вспышек
        a[5] = 1 - k / len(nd) * .5
    for f in range(90):
        br.move(centre=.15)
        br.think(.02)
        br.lv = 1.0
        br.draw(1 + .6 * clamp(1 - f / 90))
        br.show()
        await scr.frame()


async def tear(scr: Screen, br: Brain, P: list) -> None:
    br.lv = .8
    await absorb(scr, br, P)


# ---------- 4. мир: значки этапов, мелкие подписи ----------
TINY = {  # цифры 3x5 (точка и двоеточие — в столбец) — IP, время, версия влезают в 64 точки
    "0": ("111", "101", "101", "101", "111"), "1": ("01", "11", "01", "01", "01"), "2": ("111", "001", "111", "100", "111"),
    "3": ("111", "001", "111", "001", "111"), "4": ("101", "101", "111", "001", "001"), "5": ("111", "100", "111", "001", "111"),
    "6": ("111", "100", "111", "101", "111"), "7": ("111", "001", "010", "010", "010"), "8": ("111", "101", "111", "101", "111"),
    "9": ("111", "101", "111", "001", "111"), ".": ("0", "0", "0", "0", "1"), ":": ("0", "1", "0", "1", "0"),
    "+": ("000", "010", "111", "010", "000"), "-": ("000", "000", "111", "000", "000"), "C": ("111", "100", "100", "100", "111"),
    "°": ("11", "11", "00", "00", "00"),
}


def tiny(text: str, y0: int = 22) -> list:
    text = "".join(c for c in text if c in TINY)
    w = sum(len(TINY[c][0]) + 1 for c in text) - 1
    x, pts = (W - w) // 2, []
    for ch in text:
        g = TINY[ch]
        pts += [(x + c, y0 + r) for r, row in enumerate(g) for c, b in enumerate(row) if b == "1"]
        x += len(g[0]) + 1
    return pts


def ring(cx: float, cy: float, r: float, w: float = .5, keep=None) -> list:
    R = int(r + w) + 1  # только рамка вокруг круга — на Pi весь экран перебирать долго
    return [(x, y) for y in range(max(0, int(cy) - R), min(H, int(cy) + R + 1)) for x in range(max(0, int(cx) - R), min(W, int(cx) + R + 1))
            if abs(math.hypot(x - cx, y - cy) - r) < w and (keep is None or keep(x - cx, y - cy))]


def wifi_icon() -> tuple[list, list]:
    """Точки значка Wi-Fi и номер дуги каждой (0 — точка, 1…3 — дуги изнутри наружу)."""
    P, A = [], []
    for y in range(9):
        for x in range(23, 42):
            dx, dy = x + .5 - 32, y + .5 - 8.5
            d = math.hypot(dx, dy)
            cone = dy < 0 and abs(dx) < -dy * 1.05
            arc = 0 if d < 1.3 else 1 if cone and abs(d - 3.5) < .6 else 2 if cone and abs(d - 6) < .6 else 3 if cone and abs(d - 8.5) < .6 else -1
            if arc >= 0:
                P.append((x, y + 6)); A.append(arc)
    return P, A


def clock_icon(h: int, m: int) -> list:
    """Циферблат со стрелками — на настоящее время."""
    P = set(ring(32, 10, 6.2))
    for ang, L in ((m / 60 * 6.283, 4.6), ((h % 12 + m / 60) / 12 * 6.283, 3.0)):
        for s in range(int(L * 2) + 1):
            P.add((rnd(32 + math.sin(ang) * s / 2), rnd(10 - math.cos(ang) * s / 2)))
    return sorted(P)


def chip_icon() -> list:
    P = {(x, y) for x in range(28, 37) for y in (6, 14)} | {(x, y) for x in (28, 36) for y in range(6, 15)}
    P |= {(x, y) for x in range(31, 34) for y in range(9, 12)}
    for o in (8, 10, 12):
        P |= {(26, o), (27, o), (37, o), (38, o)}
    for o in (30, 32, 34):
        P |= {(o, 4), (o, 5), (o, 15), (o, 16)}
    return sorted(P)


def cloud(dy: int = 0) -> list:
    """Контур облака: три круга и ровное дно."""
    inside = lambda x, y: y <= 14 + dy and (math.hypot(x - 27, y - 11 - dy) < 3.4 or math.hypot(x - 32.5, y - 8.5 - dy) < 4.6
                                           or math.hypot(x - 38, y - 11 - dy) < 3.2 or (25 <= x <= 39 and 11 + dy <= y))
    return [(x, y) for y in range(0, 17) for x in range(22, 43) if inside(x, y)
            and not all(inside(x + ex, y + ey) for ex, ey in ((1, 0), (-1, 0), (0, 1), (0, -1)))]


def weather_icon(main: str) -> list:
    if main == "Clear":  # солнце: круг и лучи
        P = set(ring(32, 10, 2.8, .55))
        for k in range(8):
            a = k * .785
            for t in (4.6, 5.6):
                P.add((rnd(32 + math.cos(a) * t), rnd(10 + math.sin(a) * t)))
        return sorted(P)
    if main in ("Rain", "Drizzle", "Thunderstorm"):  # облако выше, под ним капли
        return cloud(-2) + [(28, 14), (27, 16), (32, 14), (31, 16), (36, 14), (35, 16)]
    if main == "Snow":
        return cloud(-2) + [(28, 15), (32, 16), (36, 15)]
    return cloud()


def mqtt_icon() -> list:
    """Антенна: мачта и волны в обе стороны."""
    P = set(ring(32, 7, 3.6, .55, lambda dx, dy: abs(dx) > abs(dy) * 1.3))
    P |= set(ring(32, 7, 6.4, .55, lambda dx, dy: abs(dx) > abs(dy) * 1.3))
    P |= {(31, 6), (32, 6), (31, 7), (32, 7)} | {(x, y) for x in (31, 32) for y in range(8, 16)} | {(x, 16) for x in range(29, 35)}
    return sorted(P)


def update_icon() -> list:
    """Стрелка вниз — в лоток."""
    P = {(32, y) for y in range(3, 12)}
    P |= {(32 - i, 11 - i) for i in range(1, 5)} | {(32 + i, 11 - i) for i in range(1, 5)}
    P |= {(x, 15) for x in range(26, 39)} | {(x, y) for x in (26, 38) for y in range(12, 15)}
    return sorted(P)


def my_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.168.0.1", 9))  # пакет не уходит — только выбор интерфейса
            return s.getsockname()[0]
    except OSError:
        return ""


async def learn(scr: Screen, br: Brain, icon: list, cap: list, ok, arcs: list | None = None, timeout: float = 30) -> bool:
    """Этап: стая выписывает значок (бирюзой) и подпись; ok — прошла ли проверка (или функция — ждём, пока
    станет True, не дольше timeout; дуги arcs бегут, стая тревожно мечется). Итог — вспышка зелёным или
    красным, стая забирает значок в себя, ближайший нейрон становится нейроном памяти."""
    T = icon + cap
    cols = [CYAN] * len(icon) + [(150, 190, 255)] * len(cap)
    wr = Writing(br, T, cols, delay=8)
    while not wr.step(30):
        br.show()
        await scr.frame()
    if callable(ok):
        f0 = wr.f
        while not ok() and (wr.f - f0) * .02 < timeout:
            lit = int((wr.f - f0) * .02 / .22) % 5 - 1  # дуги бегут
            c = [CYAN if arcs and i < len(arcs) and arcs[i] <= lit else (0, 30, 40) if arcs and i < len(arcs) else cols[i]
                 for i in range(len(T))]
            wr.hover(cols=c, jitter=.12)
            br.show()
            await scr.frame()
        ok = ok()
    res = OK if ok else FAIL
    fin = [res] * len(icon) + cols[len(icon):]
    for a in br.nd:
        a[4] = max(a[4], .5)
    for g in range(45):  # вспышка итогом: белым — и в зелёный (красный)
        k = clamp(g / 12)
        c = [tuple(255 * (1 - k) + v * k for v in fin[i]) if i < len(icon) else fin[i] for i in range(len(T))]
        wr.hover(1 + .4 * (1 - k), c)
        br.show()
        await scr.frame()
    await absorb(scr, br, list(zip(T, fin)), feel=8, grab=22, wave=False)
    free = [k for k in range(len(br.nd)) if k not in br.mem]
    if free:
        k = min(free, key=lambda i: (br.nd[i][0] - 32) ** 2 + (br.nd[i][1] - 10) ** 2)
        br.mem[k] = res
        br.nd[k][4] = 1.0
    return ok


async def world(scr: Screen, br: Brain, clock) -> None:
    """Шесть проверок — шесть значков и нейронов памяти."""
    st = lambda: getattr(clock, "state", {}) or {}
    ready = lambda: bool(getattr(clock, "ready", False)) and st().get("rssi", -100) > -100
    P, A = wifi_icon()
    await learn(scr, br, P, tiny(my_ip()), ready, A)
    s = st()
    t = now()
    await learn(scr, br, clock_icon(t.hour, t.minute), tiny(f"{t.hour:02d}:{t.minute:02d}"), s.get("nsync") == "sync ok")
    s = st()
    await learn(scr, br, chip_icon(), tiny(f"{s.get('ctemp', 0):.1f}C"), s.get("ctemp", 0) < 75)
    w = s.get("weather") or {}
    await learn(scr, br, weather_icon(w.get("main", "")), tiny(f"{round(w['temp1']):+d}°") if "temp1" in w else [], bool(w))
    await learn(scr, br, mqtt_icon(), tiny(s.get("mqh", "")), s.get("mqst") == "connected")
    u = s.get("update") or {}
    await learn(scr, br, update_icon(), tiny(s.get("ver", "")), u.get("result") != "error")


# ---------- 5. пробуждение ----------
async def awaken(scr: Screen, br: Brain, eyes: list, ecol: list, mind=None, rest: float = .25) -> None:
    """Стая разом вспыхивает — нейроны памяти растворяются в ней — и выписывает сомкнутые веки (eyes, ecol);
    стая притихает до rest — её нейроны принимает настоящая стая (mind.adopt) и живёт вокруг глаз, а глаза
    просыпаются сами (night.Eyes.wake)."""
    nd = br.nd
    for a in nd:  # мозг проснулся: вспышка по всей стае
        a[4] = 1.0
    mem = dict(br.mem)
    for f in range(25):  # цвет памяти уходит в общий
        k = (f + 1) / 25
        br.mem = {i: tuple(c[j] + ((0, 170, 255)[j] - c[j]) * k for j in range(3)) for i, c in mem.items()}
        br.move(centre=.15)
        br.think(.008)
        br.lv = 1.0
        br.draw(1.3)
        br.show()
        await scr.frame()
    br.mem = {}
    wr = Writing(br, eyes, ecol, delay=10)
    while not wr.step(50):
        br.show()
        await scr.frame()
    for g in range(40):  # стая притихает, веки остаются
        wr.hover(lv=.6 + (rest - .6) * (g + 1) / 40)
        br.show()
        await scr.frame()
    if mind is not None:  # дальше это она же — в настоящей стае
        mind.adopt(([(a[0], a[1], a[2], a[3]) for a in br.nd], rest))
    br.fb = [0] * (W * H * 3)  # на экране — только веки, стая теперь слоем под сценой
    if Image:
        br.lay.paste((0, 0, 0), (0, 0, W, H))
    wr.f += 10  # свежих точек не остаётся — все в слое
    wr.paint()
    br.show()


# ---------- засыпание: пробуждение наоборот (night.night, 23:00) ----------
async def merge(scr: Screen, br: Brain, frames: int, lv: float, rate: float) -> None:
    """Нейроны парами тянутся друг к другу и сливаются: второй из пары исчезает, первый вспыхивает."""
    nd = br.nd
    left, pairs = list(range(len(nd))), []
    while len(left) > 1:
        i = left.pop(0)
        j = min(left, key=lambda k: (nd[k][0] - nd[i][0]) ** 2 + (nd[k][1] - nd[i][1]) ** 2)
        left.remove(j)
        pairs.append((i, j))
    lv0 = br.lv
    br.sep = 1.0  # пары не расталкиваются — сходятся
    for f in range(frames):
        k = .015 + .09 * f / frames
        tg = {}
        for i, j in pairs:
            mx, my = (nd[i][0] + nd[j][0]) / 2, (nd[i][1] + nd[j][1]) / 2
            tg[i] = tg[j] = (mx, my, k)
        br.move(tg, centre=.5, damp=.85, jitter=.01)
        br.think(rate)
        br.lv = lv0 + (lv - lv0) * f / frames
        br.draw()
        br.show()
        await scr.frame()
    gone = {j for _, j in pairs}
    for i, _ in pairs:
        nd[i][4] = 1.0
    br.nd = [a for t, a in enumerate(nd) if t not in gone]
    br.pl, br.near, br.adj = [], [], []


async def asleep(scr: Screen, P: list, C: list) -> None:
    """Сомкнутые веки (точки P, цвета C) распадаются на нейроны; стая засыпает — нейроны сливаются попарно
    (30 → 15 → 8 → 4 → 2 → 1), всё медленнее, тусклее, ближе к центру; последняя искра бьётся всё реже и гаснет —
    там же, где утром родилась (birth)."""
    br = Brain(scr)
    for _ in range(N):  # нейроны появляются из век
        x, y = random.choice(P)
        br.spawn(x + random.uniform(-1, 1), y + random.uniform(-1, 1), random.uniform(-.3, .3), random.uniform(-.2, .2))[6] = .5
    br.lv = .7
    await absorb(scr, br, list(zip(P, C)), feel=25, grab=40, wave=False, flash=.25, lv_to=.6)  # тихо, без вспышек
    br.pulses = True
    for frames, lv, rate in ((60, .6, .009), (70, .5, .007), (80, .42, .005), (90, .35, .004), (100, .3, .003)):
        await merge(scr, br, frames, lv, rate)
    a = br.nd[0]
    x0, y0 = a[0], a[1]
    br.pulses = False
    t, beats = 0, ((36, 1.0), (46, .75), (58, .5), (72, .28))  # период удара растёт, сила тает
    for period, amp in beats:
        for f in range(period):
            x, y = x0 + (CX - x0) * min(1, t / 60), y0 + (CY - .5 - y0) * min(1, t / 60)  # дрейфует к центру
            b = (math.exp(-f / 3.5) + (.65 * math.exp(-(f - 8) / 3.5) if f >= 8 else 0)) * amp  # тук-тук, как при рождении
            for dy in range(-3, 4):
                for dx in range(-3, 4):
                    w = clamp(1 - math.hypot(dx, dy) / (1.4 + 1.6 * b)) * (.25 + .75 * b)
                    if w > 0:
                        br.add(rnd(x) + dx, rnd(y) + dy, 160 * w * w, 200 * w, 255 * w)
            br.show()
            await scr.frame()
            t += 1
    scr.clear()


# ---------- утро: стая тихонько просыпается (night.morning, зеркало засыпания) ----------
async def wake_up(scr: Screen, mind, rest: float = .2) -> None:
    """Искра бьётся в темноте и делится — стая рождается, как при загрузке (birth), только утренняя, тихая;
    притихает до rest, и её нейроны принимает настоящая стая (mind.adopt) — дальше она живёт фоном."""
    mind.calm(0)
    br = Brain(scr)
    br.lv = .55
    await birth(scr, br)
    for f in range(50):  # стая притихает
        br.lv = .55 + (rest - .55) * (f + 1) / 50
        br.move(centre=.25)
        br.think(.006)
        br.draw()
        br.show()
        await scr.frame()
    mind.adopt(([(a[0], a[1], a[2], a[3]) for a in br.nd], rest))
    scr.clear()


# ---------- 6:00: ранняя серая стая (night.morning, зеркало ночи) ----------
EARLY = (70, 70, 70)  # серая, как экран зеркала ночи (night.GRAY), чуть светлее — чтобы стаю было видно


async def early(scr: Screen, mind, T: list, cols: list) -> None:
    """Будни, 6:00: часы ещё спят — проснулась ранняя стая. Серая искра тихо бьётся в темноте, делится, серая
    стая без вспышек выписывает экран зеркала ночи (точки T цветами cols) и тихо гаснет — экран остаётся.
    Голубая стая до начала дня не просыпается (mind.calm(0))."""
    mind.calm(0)
    br = Brain(scr)
    br.tint, br.lv = EARLY, .9
    await birth(scr, br)
    br.pulses = False
    wr = Writing(br, T, cols, delay=14)
    while not wr.step(30):
        br.show()
        await scr.frame()
    for g in range(70):  # стая тихо гаснет, экран остаётся
        wr.hover(lv=.9 * (1 - (g + 1) / 70))
        br.show()
        await scr.frame()
    br.fb = [0] * (W * H * 3)
    if Image:
        br.lay.paste((0, 0, 0), (0, 0, W, H))
    wr.f += 10
    wr.paint()
    br.show()


async def swap(scr: Screen, old: list, new: list, color, tint=EARLY) -> None:
    """Смена на тихом экране (зеркало ночи): меняются только отличающиеся точки — рядом проявляются несколько
    серых нейронов, затягивают уходящие точки в себя, выпускают новые на их места и тихо гаснут. Остальной
    экран стоит (base)."""
    gone, add = sorted(set(old) - set(new)), sorted(set(new) - set(old))
    if not gone and not add:
        return
    base = bytearray(scr.px)
    for x, y in gone:
        i = (y * W + x) * 3
        base[i:i + 3] = b"\0\0\0"
    pts = gone + add
    x0, x1 = min(p[0] for p in pts) - 2, max(p[0] for p in pts) + 2
    y0, y1 = min(p[1] for p in pts) - 2, max(p[1] for p in pts) + 2
    k = max(3, min(8, len(pts) // 8))
    br = Brain(scr)
    br.tint, br.base, br.sep, br.lv = tint, bytes(base), 3.0, .8
    for _ in range(k):
        br.spawn(random.uniform(x0, x1), random.uniform(y0, y1), random.uniform(-.2, .2), random.uniform(-.2, .2))[6] = 0.0
    nd = br.nd

    def nearest(p):
        return min(range(k), key=lambda j: (nd[j][0] - p[0]) ** 2 + (nd[j][1] - p[1]) ** 2)

    cx, cy, hw = (x0 + x1) / 2, (y0 + y1) / 2, (x1 - x0) / 2
    out = [(p, random.randrange(16)) for p in gone]   # уходящие: точка, когда сорвётся
    inn = [(p, random.randrange(16)) for p in add]    # новые: точка, когда вылетит
    FLY, A, B, C = 12, 30, 34, 22
    for f in range(A + B + C):
        tg = {j: (cx + math.sin(f * .05 + j * 2) * hw * .8, cy + math.cos(f * .07 + j) * 2, .03) for j in range(k)}
        br.move(tg, centre=0, damp=.85, jitter=.01)
        for a in nd:  # проявляются — и под конец гаснут
            a[6] = clamp(f / 10) * clamp((A + B + C - f) / C)
        br.draw(.6)
        r, g, b = color
        for (px, py), d in out:  # затягиваются в ближайший нейрон, тускнея
            t = (f - d) / FLY
            if t >= 1:
                continue
            if t < 0:
                br.add(px, py, r, g, b)
                continue
            a = nd[nearest((px, py))]
            e = t * t
            m = 1 - t
            br.add(rnd(px + (a[0] - px) * e), rnd(py + (a[1] - py) * e), r * m, g * m, b * m)
        for (px, py), d in inn:  # вылетают из ближайшего нейрона на своё место
            t = (f - A - d) / FLY
            if t < 0:
                continue
            if t >= 1:
                br.add(px, py, r, g, b)
                continue
            a = nd[nearest((px, py))]
            e = 1 - (1 - t) * (1 - t)
            br.add(rnd(a[0] + (px - a[0]) * e), rnd(a[1] + (py - a[1]) * e), r * t, g * t, b * t)
        br.show()
        await scr.frame()
    for x, y in add:  # итог — точно новый экран
        i = (y * W + x) * 3
        base[i:i + 3] = bytes(map(int, color))
    scr.px = base


async def dawn(scr: Screen, mind, P: list, C: list, rest: float = .3) -> None:
    """Начало дня после зеркала ночи: серые нейроны забирают тихий экран (точки P, цвета C) и сами становятся
    голубыми, а матрица разгорается до дневной яркости — ранняя стая будит часы. Дальше её нейроны принимает
    главная стая (mind.adopt), и идёт пожелание (night.day_start)."""
    br = Brain(scr)
    br.tint, br.lv = EARLY, .8
    for _ in range(N):
        x, y = random.choice(P)
        br.spawn(x + random.uniform(-2, 2), y + random.uniform(-2, 2), random.uniform(-.2, .2), random.uniform(-.2, .2))[6] = 0.0
    await absorb(scr, br, list(zip(P, C)), feel=20, grab=40, wave=False, flash=0, lv_to=.8)
    d0 = scr.dim
    for f in range(100):  # серые становятся голубыми, часы разгораются
        m = (f + 1) / 100
        br.mix, scr.dim, br.lv = m, d0 + (1 - d0) * m, .8 + .2 * m
        br.pulses = m > .5
        br.move(centre=.15)
        br.think(.01)
        br.draw()
        br.show()
        await scr.frame()
    for f in range(40):  # и притихают — дальше они фон дня
        br.lv = 1 - (1 - rest) * (f + 1) / 40
        br.move(centre=.15)
        br.think(.01)
        br.draw()
        br.show()
        await scr.frame()
    mind.adopt(([(a[0], a[1], a[2], a[3]) for a in br.nd], rest))
    scr.clear()
