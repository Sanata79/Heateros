"""Загрузка NeuroClock — порт bootfx.ino, boot() (booting.ino) и eyesHello / bootToday (wakeeyes.ino) с ESP32.

«Большой взрыв»: из точки в центре вылетают искры и по спирали собираются в крупное NEURO / CLOCK в две строки
во весь экран, по ним проходит блик: NEURO краснеет, CLOCK — бирюза (версия — на этапе UPDATE). Потом этапы, как на ESP, но свои для Pi: connect. (значок Wi-Fi,
IP), NTP, SYSTEM (CPU и память — вместо RTC и датчиков ESP), WEATHER (город), MQTT, UPDATE; под заголовком
этапа — полоса: пройденные светятся и по ним бежит блик, текущий наполняется и пульсирует. В конце полоса
вспыхивает и рассыпается искрами, сеть неспешно собирает глаза, они просыпаются. Днём глаза становятся шаром →
пожелание между порталами → крупное TODAY (первый экран дня); вечером и ночью сеть собирает «Привет».
"""
from __future__ import annotations

import asyncio
import math
import random
import socket

import fx
from fx import Dots
from matrix import BLUE, GREEN, RED, W, Screen, center_x, draw_text, grad, morph, text_points
from night import Eyes, split_out, type_text, wish_text
from clockrow import now
from ticker import Row

CYAN = (0, 200, 255)
STAGES = 6
BB_X, BB_Y = (W - (STAGES * 8 - 1)) // 2, 9


def clamp(v, a=0.0, b=255.0):
    return max(a, min(b, v))


def ease(k: float) -> float:
    k = clamp(k, 0, 1)
    return 1 - (1 - k) ** 3


def my_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("192.168.0.1", 9))  # пакет не уходит — только выбор интерфейса
            return s.getsockname()[0]
    except OSError:
        return "no network"


# ---------- заставка ----------
async def splash(scr: Screen) -> list:
    top = text_points("NEURO", 3, 1, 2, 2)
    T = top + text_points("CLOCK", 3, 17, 2, 2)
    after = [RED] * len(top) + [CYAN] * (len(T) - len(top))  # за бликом
    xs, ys = [32.0] * len(T), [15.5] * len(T)
    vx, vy = [], []
    for _ in T:
        a, v = random.uniform(0, 6.283), random.uniform(.6, 2.2)
        vx.append(math.cos(a) * v * 1.6); vy.append(math.sin(a) * v)
    dots = Dots(scr)
    for f in range(12):  # взрыв из точки
        for i in range(len(T)):
            xs[i] += vx[i]; ys[i] += vy[i]; vx[i] *= .9; vy[i] *= .9
        w = 1 - f / 12
        await dots.frame(xs, ys, [(255 * w, 255, 255)] * len(T))
    sx, sy, dl, F = list(xs), list(ys), [random.randrange(10) for _ in T], 30
    for f in range(F + 11):  # собираются в буквы по спирали
        cs = []
        for i, (tx, ty) in enumerate(T):
            e = ease((f - dl[i]) / F)
            s = math.sin(e * math.pi)
            dx, dy = tx - sx[i], ty - sy[i]
            xs[i], ys[i] = sx[i] + dx * e - dy * s * .35, sy[i] + dy * e + dx * s * .12
            cs.append((255 * (1 - e) * .6, 200 + 55 * (1 - e), 255))
        await dots.frame(xs, ys, cs, .018)
    for s in range(-6, 71, 2):  # блик, за ним NEURO краснеет, CLOCK — бирюза
        cs = [(255, 255, 255) if abs(tx - s) < 2 else after[i] if tx < s else (60, 120, 255)
              for i, (tx, _) in enumerate(T)]
        await dots.frame([p[0] for p in T], [p[1] for p in T], cs, .014)
    return T


async def splash_out(scr: Screen, T: list) -> None:
    """Буквы осыпаются вниз и гаснут — нижние срываются первыми."""
    xs, ys = [float(x) for x, _ in T], [float(y) for _, y in T]
    vx = [random.randint(-30, 30) / 100 for _ in T]
    vy = [-random.randint(0, 79) / 100 for _ in T]
    dl = [(31 - y) // 2 + random.randrange(8) for _, y in T]
    dots = Dots(scr)
    dots.prev = list(T)
    for f in range(55):
        cs = []
        for i in range(len(T)):
            if f >= dl[i]:
                vy[i] += .2; xs[i] += vx[i]; ys[i] += vy[i]
            k = 1 if f < dl[i] else max(0.0, 1 - (f - dl[i]) / 22)
            cs.append((255 * k, 40 * (1 - k) * k * 4, 0))
        await dots.frame(xs, ys, cs)
    await dots.frame([], [], [])


# ---------- тексты этапов ----------
async def wave_in(scr: Screen, text: str, color) -> None:
    """Нижняя строка выныривает снизу по букве (nwave)."""
    x0 = center_x(text)
    for i, ch in enumerate(text):
        for y in range(32, 23, -1):
            scr.fill(x0 + i * 6, y + 1, 6, 8)
            draw_text(scr, ch, x0 + i * 6, y, color)
            await scr.frame(.01)


async def drop_in(scr: Screen, text: str, y0: int, color) -> None:
    """Буквы падают сверху на место (textDropFromTop)."""
    x0 = center_x(text)
    for i, ch in enumerate(text):
        for y in range(y0 - 12, y0 + 1, 2):
            scr.fill(x0 + i * 6, max(0, y - 2), 6, 10 if y > y0 - 10 else 8)
            draw_text(scr, ch, x0 + i * 6, y, color)
            await scr.frame(.018)


async def fall_out(scr: Screen, text: str, y0: int, color) -> None:
    """Буквы по одной падают вниз за край (textFallDownByLetter)."""
    x0 = center_x(text)
    for i, ch in enumerate(text):
        for y in range(y0, 33, 3):
            scr.fill(x0 + i * 6, y - 3, 6, 11)
            draw_text(scr, ch, x0 + i * 6, y, color)
            await scr.frame(.01)
        scr.fill(x0 + i * 6, 24, 6, 8)


async def fly_left(scr: Screen, text: str, y: int, color) -> None:
    for x in range(center_x(text), -len(text) * 6 - 1, -2):
        scr.fill(0, y, W, 8)
        draw_text(scr, text, x, y, color)
        await scr.frame(.008)
    scr.fill(0, y, W, 8)


# ---------- значок Wi-Fi и полоса этапов ----------
def wifi_icon(scr: Screen, lit: int, on, off) -> None:
    for y in range(9):
        for x in range(23, 42):
            dx, dy = x + .5 - 32, y + .5 - 8.5
            d = math.hypot(dx, dy)
            cone = dy < 0 and abs(dx) < -dy * 1.05
            arc = 0 if d < 1.3 else 1 if cone and abs(d - 3.5) < .6 else 2 if cone and abs(d - 6) < .6 else 3 if cone and abs(d - 8.5) < .6 else -1
            scr.set(x, y, (0, 0, 0) if arc < 0 else on if arc <= lit else off)


async def wifi_wait(scr: Screen, ok_fn, timeout: float = 30) -> bool:
    """Дуги бегут, пока ждём сеть; есть — значок вспыхивает зелёным, нет — красным, и гаснет."""
    loop = asyncio.get_running_loop()
    t0, ok = loop.time(), ok_fn()
    while not ok and loop.time() - t0 < timeout:
        wifi_icon(scr, int((loop.time() - t0) / .22) % 5 - 1, CYAN, (0, 30, 40))
        await scr.frame(.04)
        ok = ok_fn()
    c = (60, 255, 90) if ok else (255, 30, 30)
    for _ in range(3):
        wifi_icon(scr, 3, c, c); await scr.hold(.14)
        wifi_icon(scr, -1, (0, 0, 0), (0, 0, 0)); await scr.hold(.09)
    wifi_icon(scr, 3, c, c)
    await scr.hold(.4)
    for k in range(10, -1, -1):  # гаснет
        d = (6 * k, 25.5 * k, 9 * k) if ok else (25.5 * k, 3 * k, 3 * k)
        wifi_icon(scr, 3, d, d)
        await scr.frame(.025)
    scr.fill(0, 0, W, 9)
    return ok


class Bar:
    """Полоса этапов в строках 9..10: пройденные светятся, по ним бежит блик; текущий наполняется и пульсирует."""

    def __init__(self, scr: Screen):
        self.scr, self.stage, self.task, self.t0, self.ts = scr, 0, None, 0.0, 0.0

    def next(self) -> None:
        self.stage += 1
        self.ts = asyncio.get_running_loop().time()

    async def _run(self) -> None:
        loop = asyncio.get_running_loop()
        self.t0 = self.ts = loop.time()
        while True:
            t = loop.time() - self.t0
            grow = min(.9, (loop.time() - self.ts) / 4)
            band = math.fmod(t * 30, 90) - 15
            for s in range(STAGES):
                for i in range(7):
                    x = BB_X + s * 8 + i
                    if s < self.stage:
                        sh = max(0.0, 1 - abs(x - band) / 5)
                        c = (200 * sh, 170 + 85 * sh, 220 + 35 * sh)
                    elif s == self.stage:
                        p = .55 + .45 * math.sin(t * 6)
                        filled = i < 1 + grow * 6
                        c = (0, 200 * p, 255 * p) if filled else (0, 30, 45)
                        if filled and i == int(grow * 6) and int(t * 10) & 1:
                            c = (255, 255, 255)
                    else:
                        c = (0, 22, 32)
                    self.scr.set(x, BB_Y, c); self.scr.set(x, BB_Y + 1, c)
            await asyncio.sleep(.03)

    def start(self) -> None:
        self.task = asyncio.create_task(self._run())

    async def finish(self) -> None:
        """Полоса заполняется, белый блик, сегменты рассыпаются искрами вверх."""
        if self.task:
            self.task.cancel()
        xs = [x for x in range(BB_X, BB_X + STAGES * 8 - 1) if (x - BB_X) % 8 != 7]
        for s in range(-6, 67, 3):
            for x in xs:
                d = abs(x - s)
                c = (255, 255, 255) if d < 3 else (60, 255, 90) if x < s else (0, 170, 220)
                self.scr.set(x, BB_Y, c); self.scr.set(x, BB_Y + 1, c)
            await self.scr.frame(.016)
        P = [(x, BB_Y + y) for x in xs for y in (0, 1)]
        px, py = [float(x) for x, _ in P], [float(y) for _, y in P]
        vx = [random.randint(-40, 40) / 100 for _ in P]
        vy = [-random.randint(40, 159) / 100 for _ in P]
        dots = Dots(self.scr)
        dots.prev = list(P)
        for f in range(30):
            for i in range(len(P)):
                px[i] += vx[i]; py[i] += vy[i]; vy[i] += .07
            k = 1 - f / 30
            await dots.frame(px, py, [(255 * k,) * 3 if (i * 7 + f) % 9 == 0 else (60 * k, 255 * k, 90 * k) for i in range(len(P))], .022)
        await dots.frame([], [], [])


async def stage(scr: Screen, bar: Bar, title: str, tcolor, line: str, lcolor, row: int = 24) -> None:
    """Этап: заголовок печатается, строка бежит между вихревыми порталами, заголовок расходится."""
    await type_text(scr, title, 0, tcolor, .075)
    await Row(scr, row).run(line, lcolor, neuro=False)
    await split_out(scr, title, 0, tcolor)
    bar.next()


# ---------- после загрузки ----------
async def hello(scr: Screen) -> None:
    """Вечером и ночью: глаза распадаются, сеть собирает «Привет» (5x16) с лучом, слово 5 с переливается с
    искрами, потом стекает в сеть, и она гаснет (eyesHello)."""
    A, C = scr.lit()
    x0, y0 = (W - 35) // 2, 8
    B = text_points("Привет", x0, y0, 1, 2)
    await morph(scr, A, C, B, None, beam=True)
    loop = asyncio.get_running_loop()
    t0, sp = loop.time(), []
    while loop.time() - t0 < 5:
        t = (loop.time() - t0) * 1.17
        for x, y in B:
            scr.set(x, y, grad(x, t))
        if not random.randrange(5) and len(sp) < 6:
            sp.append([random.randrange(len(B)), 9])
        for s in sp:
            x, y = B[s[0]]
            w = s[1] / 9
            scr.set(x, y, (255 * w + (1 - w) * 128,) * 3)
            s[1] -= 1
        sp = [s for s in sp if s[1] > 0]
        await scr.frame(.03)
    A, C = scr.lit()
    await morph(scr, A, C, [], None)
    scr.clear()


async def boot(scr: Screen, clock, mind) -> str:
    """Вся загрузка. Возвращает, что уже показано: «today» — на экране крупное TODAY (первый экран дня его не
    собирает заново), «hello» — вечер или ночь, дальше свой режим."""
    st = lambda: getattr(clock, "state", {}) or {}
    mind.calm(.1)
    scr.dim = 1.0
    scr.clear()
    T = await splash(scr)
    await scr.hold(2)
    await splash_out(scr, T)
    await drop_in(scr, "connect.", 12, BLUE)
    bar = Bar(scr)
    bar.start()
    ok = await wifi_wait(scr, lambda: bool(getattr(clock, "ready", False)) and st().get("rssi", -100) > -100)
    await fall_out(scr, "connect.", 12, BLUE)
    if ok:
        await stage(scr, bar, "Connected", BLUE, my_ip(), BLUE)
    else:
        await stage(scr, bar, "NO WIFI", RED, "Offline mode", RED)
    s = st()
    synced = s.get("nsync") == "sync ok"
    await stage(scr, bar, "NTP DATA", BLUE, "Time synchronized" if synced else "Wait ntp server data", GREEN if synced else RED)
    await stage(scr, bar, "SYSTEM", BLUE, f"CPU {s.get('ctemp', 0):.1f}C  RAM {round(100 * (1 - s.get('frhp', 0) / max(1, s.get('totalHeap', 1))))}%", GREEN)
    w = s.get("weather") or {}
    await stage(scr, bar, "WEATHER", RED, f"Weather data updated  {w.get('town', '')}" if w else "No response from the server",
                GREEN if w else RED, 12)
    mq = s.get("mqst", "")
    await stage(scr, bar, "MQTT", BLUE, f"Broker {s.get('mqh', '')}  {mq}", GREEN if mq == "connected" else RED)
    u = s.get("update") or {}
    await stage(scr, bar, "UPDATE", BLUE, f"Version {s.get('ver', '')}  {u.get('result', '')}".strip(), GREEN)
    await bar.finish()
    scr.clear()
    eyes = Eyes(scr)
    await eyes.wake()  # нейросеть собирает глаза, они просыпаются
    h = now().hour
    if h >= 20 or h < 6:
        await hello(scr)
        return "hello"
    P, C = eyes.points()  # днём: глаза → шар → пожелание между порталами → «TODAY»
    TD = text_points("TODAY", 3, 9, 2, 2)
    await Row(scr, 12).run(wish_text(h), BLUE, B=TD, A=P, ca=C)
    return "today"
