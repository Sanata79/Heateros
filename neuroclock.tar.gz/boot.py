"""Загрузка NeuroClock: пробуждение стаи (awake.py) — рождение из искры, имя, разрыв на нейроны, мир
(Wi-Fi, время, система, погода, MQTT, обновление), веки; глаза просыпаются (night.Eyes), стая живёт вокруг.
Днём глаза становятся Сферой → пожелание между порталами → крупное TODAY (первый экран дня); вечером и ночью
сеть собирает «Привет». Прежняя загрузка — порт bootfx.ino с ESP32 — в backups/boot_esp_style_0.10.30.py.
"""
from __future__ import annotations

import asyncio
import random

import awake
from matrix import BLUE, W, Screen, grad, morph, text_points
from night import Eyes, wish_text
from clockrow import now
from ticker import Row


# ---------- после загрузки ----------
async def hello(scr: Screen) -> None:
    """Вечером и ночью: глаза распадаются, сеть собирает «Привет» (5x16) с лучом, слово 5 с переливается с
    искрами, потом стекает в сеть, и она гаснет (eyesHello)."""
    A, C = scr.lit()
    x0, y0 = (W - 35) // 2, 8
    B = text_points("Привет", x0, y0, 1, 2)
    await morph(scr, A, C, B, None, beam=True)
    loop = asyncio.get_running_loop()
    t0, sp = loop.time(), []
    while loop.time() - t0 < 5:
        t = (loop.time() - t0) * 1.17
        for x, y in B:
            scr.set(x, y, grad(x, t))
        if not random.randrange(5) and len(sp) < 6:
            sp.append([random.randrange(len(B)), 9])
        for s in sp:
            x, y = B[s[0]]
            w = s[1] / 9
            scr.set(x, y, (255 * w + (1 - w) * 128,) * 3)
            s[1] -= 1
        sp = [s for s in sp if s[1] > 0]
        await scr.frame(.03)
    A, C = scr.lit()
    await morph(scr, A, C, [], None)
    scr.clear()


async def boot(scr: Screen, clock, mind) -> str:
    """Вся загрузка. Возвращает, что уже показано: «today» — на экране крупное TODAY (первый экран дня его не
    собирает заново), «hello» — вечер или ночь, дальше свой режим."""
    mind.calm(0)  # стая загрузки рождается сама; в конце настоящая стая примет её нейроны
    scr.dim = 1.0
    scr.clear()
    plan = awake.name_plan()  # пока экран тёмный
    br = awake.Brain(scr)
    await awake.birth(scr, br)
    P = await awake.name(scr, br, plan)
    await awake.tear(scr, br, P)
    await awake.world(scr, br, clock)
    eyes = Eyes(scr)
    await awake.awaken(scr, br, *eyes.closed(), mind)
    await eyes.wake(built=True)  # часы проснулись и увидели человека
    h = now().hour
    if h >= 20 or h < 6:
        await hello(scr)
        return "hello"
    P, C = eyes.points()  # днём: глаза → Сфера → пожелание между порталами → «TODAY»
    TD = text_points("TODAY", 3, 9, 2, 2)
    await Row(scr, 12).run(wish_text(h), BLUE, B=TD, A=P, ca=C)
    return "today"
