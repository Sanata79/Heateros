"""Загрузка NeuroClock: пробуждение стаи (awake.py) — рождение из искры, имя, разрыв на нейроны, мир
(Wi-Fi, время, система, погода, MQTT, обновление), веки; глаза просыпаются (night.Eyes).
Днём глаза становятся Сферой → пожелание между порталами → крупное TODAY (первый экран дня).
"""
from __future__ import annotations

import awake
from matrix import BLUE, Screen, morph, text_points
from night import Eyes, wish_text
from clockrow import now
from ticker import Row


async def boot(scr: Screen, clock, mind) -> str:
    """Вся загрузка. Возвращает, что уже показано: «today» — на экране крупное TODAY (первый экран дня его не
    собирает заново), «done» — вечер или ночь, дальше свой режим."""
    mind.calm(0)  # стая загрузки рождается сама; в конце настоящая стая примет её нейроны
    scr.dim = 1.0
    scr.clear()
    plan = awake.name_plan()  # пока экран тёмный
    br = awake.Brain(scr)
    await awake.birth(scr, br)
    P = await awake.name(scr, br, plan)
    await awake.tear(scr, br, P)
    await awake.world(scr, br, clock)
    eyes = Eyes(scr)
    await awake.awaken(scr, br, *eyes.closed(), mind)
    await eyes.wake(built=True)  # часы проснулись и увидели человека
    h = now().hour
    if h >= 20 or h < 6:
        P, C = scr.lit()
        await morph(scr, P, C, [], None)
        scr.clear()
        return "done"
    P, C = eyes.points()  # днём: глаза → Сфера → пожелание между порталами → «TODAY»
    TD = text_points("TODAY", 3, 9, 2, 2)
    await Row(scr, 12).run(wish_text(h), BLUE, B=TD, A=P, ca=C)
    return "today"
