"""Строка с нейропорталами — порт движка бегущих строк ESP32-часов (lina.ino: atPut, atNeuroPortal, atBall…).

Строка в 8 точек высотой собирается в своём буфере (Row.lb) и выводится на экран целиком (show). По краям —
нейропорталы: узлы покачиваются, между ними связи, по связям бегает сигнал. Точка у правого портала летит
из его узла на своё место (из фиолета в свой цвет), у левого — с места в узел, отлетают искры. Порталы
рождаются Сферой: сеть собирает её посреди строки, она вспыхивает и разрывается надвое — между половинками
живёт та же сеть, из которой Сфера родилась: нейроны плавают в промежутке, связи держат их друг с другом и с
краями половинок, по связям бегут импульсы; половинки расходятся — связи растягиваются и рвутся там, где стало
далеко, нейроны гаснут, половинки тают в порталы (sphere_in). Обратно (sphere_close, sphere_out) нейроны
загораются в промежутке, связи сцепляются заново и стягивают половинки в целую Сферу. Кадр — 20 мс, как на ESP.
"""
from __future__ import annotations

import math
import random

from matrix import W, Screen, glyph, grad, morph, rnd

PW = 3            # ширина портала
PR = W - PW       # левый столбец правого портала
ZR, ZL = 12, 10   # зоны сборки справа и рассыпания слева
OPEN = 10         # кадров на раскрытие
NN = 4            # узлов в нейропортале
SPLIT = 40        # кадров на разъезд / съезд половинок Сферы — чтобы нейросвязи было видно
ANCH = (1.5, 3.5, 5.0, 6.5)  # строки, где связи держатся за края половинок Сферы
BR = 9.0                     # дальше — связь рвётся
BNODES = ((0, 2.5, .9), (0, 5.5, 4.2), (0, 8.5, 6.4), (1, 2.5, 2.4), (1, 5.5, 5.6), (1, 8.5, .6),
          (2, 1 / 3, 3.0), (2, 2 / 3, 5.0))  # нейроны: у левой половинки, у правой (отступ, строка), посередине (доля)
LIFE = 12
EDGES = ((0, 1), (1, 2), (2, 3), (0, 2), (1, 3))


def mix(c, w: float, a: float = 1, t=(255, 255, 255)) -> tuple:
    """Цвет c → к t на долю w, затем яркость a (atMix)."""
    return tuple(max(0, min(255, (c[k] + (t[k] - c[k]) * w) * a)) for k in range(3))


def dim(c, s: float) -> tuple:
    return (c[0] * s, c[1] * s, c[2] * s)


def ai_color(x: float, t: float, bright: float = 1) -> tuple:
    """Перелив сообщений ИИ: по ширине и во времени — от голубого к фиолетовому (aiColor)."""
    k = .5 + .5 * math.sin(x * .18 + t * .12)
    return (160 * k * bright, 230 * (1 - k) * bright, 255 * bright)


def ahash(i: int, c: int, r: int) -> int:
    return ((i * 7 + c * 13 + r * 29 + 5) * 2654435761 & 0xFFFFFFFF) >> 24


class Row:
    def __init__(self, scr: Screen, y: int):
        self.scr, self.y = scr, y
        self.lb = [[None] * W for _ in range(8)]
        self.sp: list = []  # искры: x, y, vx, vy, цвет, жизнь
        self.nx = [[0.0] * NN for _ in range(2)]
        self.ny = [[0.0] * NN for _ in range(2)]
        self.bp: list = []  # Сфера: точки и цвета
        self.bc: list = []
        self.neuro = True    # нейропорталы; False — вихревые порталы обычной строки (пожелания)

    def clear(self) -> None:
        self.lb = [[None] * W for _ in range(8)]
        self.sp = []

    def show(self) -> None:
        """Буфер строки — на экран (вся строка), буфер очищается."""
        px, y = self.scr.px, self.y
        for r in range(8):
            buf = bytearray(W * 3)
            for x, c in enumerate(self.lb[r]):
                if c:
                    j = x * 3
                    buf[j] = int(c[0]); buf[j + 1] = int(c[1]); buf[j + 2] = int(c[2])
            a = (y + r) * W * 3
            px[a:a + W * 3] = buf
        self.lb = [[None] * W for _ in range(8)]

    def _set(self, x: int, r: int, c) -> None:
        if 0 <= x < W and 0 <= r < 8:
            self.lb[r][x] = c

    def _add(self, x: float, r: float, c) -> None:
        x, r = rnd(x), rnd(r)
        if 0 <= x < W and 0 <= r < 8:
            o = self.lb[r][x] or (0, 0, 0)
            self.lb[r][x] = tuple(min(255, a + b) for a, b in zip(o, c))

    def bonds(self, e: float, f: int, join: bool) -> None:
        """Сеть между половинками Сферы на доле пути e — как сеть, из которой Сфера рождается: нейроны в
        промежутке, связи между всеми, кто ближе BR (с краями половинок тоже), импульсы по связям. Половинки
        расходятся — связи рвутся сами, нейроны гаснут; сходятся (join) — загораются, связи сцепляются вновь."""
        half = (W // 2 - PW) * e
        xl, xr = 31 - half, 32 + half  # внутренние края половинок
        gap = xr - xl
        a = min(1.0, max(0.0, (.85 - e) / .25))  # нейроны гаснут к концу пути и загораются при сближении
        pts = [(xl, r, 0) for r in ANCH] + [(xr, r, 0) for r in ANCH]  # края — без своих точек
        for j, (side, at, row) in enumerate(BNODES):  # у каждой половинки — своя часть сети, середина гаснет первой
            ph = j * 1.7 + (3 if join else 0)
            wob = min(1.5, gap * .08)
            if side == 2:
                x, aa = xl + gap * at, a * min(1.0, max(0.0, (.55 - e) / .2))
            else:
                at = min(at, gap * .45)  # пока половинки рядом — сеть сжата между ними
                x, aa = (xl + at if side == 0 else xr - at), a
            pts.append((x + math.sin(f * .06 + ph) * wob, row + math.cos(f * .05 + ph * 1.3) * .9, aa))
        live = []
        for i in range(len(pts)):
            for k in range(i + 1, len(pts)):
                (x1, y1, a1), (x2, y2, a2) = pts[i], pts[k]
                if i < 2 * len(ANCH) and k < 2 * len(ANCH):
                    continue  # края половинок между собой не связаны
                d = math.hypot(x2 - x1, y2 - y1)
                w = min(a1 if i >= 2 * len(ANCH) else a, a2 if k >= 2 * len(ANCH) else a) * (1 - d / BR)
                if d >= BR or w <= 0:
                    continue
                live.append((i, k))
                n = max(1, int(d))
                for s in range(1, n):
                    u = s / n
                    self._add(x1 + (x2 - x1) * u, y1 + (y2 - y1) * u, (80 * w, 40 * w, 190 * w))
        for x, y, aa in pts[2 * len(ANCH):]:  # нейроны: точка и крестик-ореол, как у сети
            if aa > 0:
                self._add(x, y, (0, 170 * aa, 255 * aa))
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    self._add(x + dx, y + dy, (0, 30 * aa, 70 * aa))
        bp = []  # импульсы — по живым связям; связь порвалась — импульс пропал
        for q in getattr(self, "bpl", []):
            if (q[0], q[1]) in live or (q[1], q[0]) in live:
                q[2] += q[3]
                if q[2] < 1:
                    bp.append(q)
        if live and len(bp) < 4 and random.randrange(3) == 0:
            i, k = random.choice(live)
            bp.append([i, k, 0.0, random.uniform(.05, .09)] if random.randrange(2) else [k, i, 0.0, random.uniform(.05, .09)])
        for i, k, t, _ in bp:
            for s, m in ((0, 1.0), (1, .45), (2, .18)):  # голова и хвост
                u = t - s * .1
                if u < 0:
                    break
                (x1, y1, _), (x2, y2, _) = pts[i], pts[k]
                self._add(x1 + (x2 - x1) * u, y1 + (y2 - y1) * u, (200 * m, 240 * m, 255 * m))
        self.bpl = bp

    def put(self, px: int, r: int, col, i: int, c: int) -> None:
        """Точка строки r знака i (столбец c) на месте px; у порталов — в полёте (atPut, нейро)."""
        if px < PW or px >= PR:
            return
        h = ahash(i, c, r)
        side, nn, neuro = (0 if px < W // 2 else 1), h & (NN - 1), self.neuro
        sy, x, y, w, a = self.ny[side][nn] if neuro else h & 7, float(px), float(r), 0.0, 1.0
        if px >= PR - ZR:
            k = min(1.0, max(0.0, (PR - px - (h >> 5)) / (ZR - 7)))
            e = (1 - k) * (1 - k)
            sx = self.nx[1][nn] if neuro else PR
            x, y, w, a = px + (sx - px) * e, r + (sy - r) * e, .7 * (1 - k), .35 + .65 * k
        elif px < PW + ZL:
            k = min(1.0, max(0.0, (px - PW - (h >> 6)) / (ZL - 3)))
            e = (1 - k) * (1 - k)
            sx = self.nx[0][nn] if neuro else PW - 1
            x, y, w, a = px + (sx - px) * e, r + (sy - r) * e, .6 * (1 - k), .3 + .7 * k
            if k < .6 and not random.randrange(14) and len(self.sp) < 32:
                self.sp.append([x, y, -random.randint(15, 44) / 100, random.randint(-30, 30) / 100, col, LIFE])
        self._set(rnd(x), rnd(y), mix(col, w, a, (170, 70, 255) if neuro else (255, 255, 255)))  # нейро — из фиолета

    def sparks(self) -> None:
        """Искры летят в левый портал и гаснут."""
        alive = []
        for s in self.sp:
            s[0] += s[2]; s[1] += s[3]; s[5] -= 1
            x, y = rnd(s[0]), rnd(s[1])
            if s[5] <= 0 or x < PW or x >= W or y < 0 or y > 7:
                continue
            k = s[5] / LIFE
            self.lb[y][x] = mix(s[4], .6 * k, k)
            alive.append(s)
        self.sp = alive

    def vortex(self, x0: int, f: int, po: float, d: int) -> None:
        """Портал обычной строки в столбцах x0..x0+2, раскрыт на po: по нему бежит вихрь, середина — светлое ядро."""
        h = 4.2 * po
        for j in range(PW):
            for r in range(8):
                dd = abs(r - 3.5)
                if dd > h:
                    continue
                s = .5 + .5 * math.sin(r * 1.3 - f * .5 * d + j * 2.1)
                e = 1 - .5 * dd / (h + .5)
                a = po * e * (.55 + .45 * s if j == 1 else .35 + .4 * s)
                self.lb[r][x0 + j] = ((120 + 135 * s) * a, (200 + 55 * s) * a, 255 * a) if j == 1 else \
                    (170 * s * a, (60 + 140 * (1 - s)) * a, 255 * a)

    def portal(self, side: int, f: int, po: float) -> None:
        """Нейропортал: узлы покачиваются; po ≤ 0 — только положения узлов (к ним летят точки)."""
        x0 = PR if side else 0
        nx, ny = self.nx[side], self.ny[side]
        for k in range(NN):
            nx[k] = x0 + 1 + math.sin(f * .09 + k * 1.9 + side) * .9
            ny[k] = .6 + k * 2.1 + math.cos(f * .07 + k * 2.3 + side * 2) * .7
        if po <= 0:
            return
        for a, b in EDGES:
            for s in range(1, 4):
                self._set(rnd(nx[a] + (nx[b] - nx[a]) * s / 4), rnd(ny[a] + (ny[b] - ny[a]) * s / 4), (55 * po, 25 * po, 130 * po))
        for k in range(NN):
            a = po * (.6 + .4 * math.sin(f * .3 + k * 1.7))
            self._set(rnd(nx[k]), rnd(ny[k]), (0, 170 * a, 255 * a))
        t = math.fmod(f * .12 + side * 1.5, 3)
        a = int(t)
        k = t - a
        self._set(rnd(nx[a] + (nx[a + 1] - nx[a]) * k), rnd(ny[a] + (ny[a + 1] - ny[a]) * k), (200 * po, 240 * po, 255 * po))

    async def sphere_frame(self, e: float, a: float, flash: float, po: float, f: int, join: bool = False) -> None:
        """Половинки Сферы на доле пути e к краям, яркость a, между ними — нейросвязи; порталы раскрыты на po."""
        for (x, y), c in zip(self.bp, self.bc):
            left = x < W // 2
            xx = rnd(x + (-1 if left else 1) * (W // 2 - PW) * e)
            if 0 <= xx < W and a > 0:
                self.lb[y - self.y][xx] = mix(c, flash, a)
        if 0 < e < 1 and a > 0:
            self.bonds(e, f, join)
        self.portal(0, f, po); self.portal(1, f, po)
        self.show()
        await self.scr.frame()

    async def sphere_in(self, f_end: int, A: list | None = None, ca=None) -> None:
        """Сеть собирает Сферу посреди строки (из пустоты или из точек A), она вспыхивает, разрывается — между
        половинками рвутся нейросвязи — и половинки уезжают в порталы; к кадру f_end порталы раскрыты."""
        y = self.y
        self.bp = [(x, y + r) for r in range(8) for x in range(W)
                   if ((x - 31.5) / 4.6) ** 2 + ((r - 3.5) / 3.9) ** 2 <= 1][:80]
        area = (0, 0, W, 32) if A else (0, y - 4, W, y + 12)
        await morph(self.scr, A or [], ca, self.bp, None, area=area)
        self.bc = [grad(x, 0) for x, _ in self.bp]
        for g in range(6):  # заряд
            await self.sphere_frame(0, 1, .5 + .5 * math.sin(math.pi * g / 5), 0, f_end - SPLIT - 6 + g)
        for g in range(SPLIT + 1):  # у краёв половинки тают в порталы
            k = g / SPLIT
            e, fade = k * k * (3 - 2 * k), min(1.0, max(0.0, (k - .7) / .3))
            await self.sphere_frame(e, 1 - fade, 0, fade, f_end - SPLIT + g)

    async def sphere_close(self, f0: int) -> None:
        """Порталы гаснут в половинки, те сходятся — синапсы сцепляются и стягивают их — в Сферу, она вспыхивает
        и остаётся на экране."""
        for g in range(SPLIT + 1):
            q = 1 - g / SPLIT
            e, fade = q * q * (3 - 2 * q), min(1.0, max(0.0, (q - .7) / .3))
            await self.sphere_frame(e, 1 - fade, 0, fade, f0 + g, join=True)
        for g in range(6):
            await self.sphere_frame(0, 1, .5 + .5 * math.sin(math.pi * g / 5), 0, f0 + SPLIT + g)
        for (x, y), c in zip(self.bp, self.bc):
            self.scr.set(x, y, c)

    async def sphere_out(self, f0: int, B: list | None = None, cb=None) -> None:
        """Порталы гаснут в половинки, те сходятся в Сферу (синапсы сцепляются и стягивают их), Сфера рассыпается
        в сеть и та гаснет — или сеть по всему экрану собирает из Сферы B цветом cb."""
        for g in range(SPLIT + 1):
            q = 1 - g / SPLIT
            e, fade = q * q * (3 - 2 * q), min(1.0, max(0.0, (q - .7) / .3))
            await self.sphere_frame(e, 1 - fade, 0, fade, f0 + g, join=True)
        for g in range(6):
            await self.sphere_frame(0, 1, .5 + .5 * math.sin(math.pi * g / 5), 0, f0 + SPLIT + g)
        for (x, y), c in zip(self.bp, self.bc):
            self.scr.set(x, y, c)
        area = (0, 0, W, 32) if B else (0, self.y - 4, W, self.y + 12)
        await morph(self.scr, self.bp, self.bc, B or [], cb, area=area)

    async def run(self, text: str, color=None, B: list | None = None, cb=None, step: float = .02,
                  neuro: bool = True, A: list | None = None, ca=None) -> None:
        """Бегущая строка (atRun): текст выходит из правого портала и уходит в левый. neuro — нейропорталы из
        Сферы, в конце Сфера рассыпается в сеть (или становится B); иначе — вихревые порталы раскрываются и
        схлопываются. color None — перелив ИИ. A, ca — Сфера собирается из этих точек (глаза при загрузке)."""
        n = len(text)
        if not n:
            return
        w = n * 6
        self.neuro = neuro
        self.clear()
        f = 0
        if neuro:
            await self.sphere_in(OPEN, A, ca)
            f = OPEN
        x, cl = PR, 0
        while True:
            done = x + w < PW - 2  # весь текст ушёл в левый портал
            if neuro and done:
                break
            po = f / OPEN if f < OPEN else 1 - cl / OPEN if done else 1
            if done:
                cl += 1
            if po < 0:
                break
            if neuro:
                self.portal(0, f, -1); self.portal(1, f, -1)  # только положения узлов
            if f >= OPEN and not done:
                first, last = max(0, int((PW - x) / 6) - 1), min(n, int((PR - x) / 6) + 1)
                for i in range(first, last):
                    cols = glyph(text[i])
                    for c in range(5):
                        px = x + i * 6 + c
                        cc = color or ai_color(px * 3, f)
                        for r in range(8):
                            if cols[c] >> r & 1:
                                self.put(px, r, cc, i, c)
                x -= 1
            self.sparks()
            if neuro:
                self.portal(0, f, po); self.portal(1, f, po)
            else:
                self.vortex(0, f, po, -1); self.vortex(PR, f, po, 1)
            self.show()
            await self.scr.frame(step)
            f += 1
        self.clear()
        if neuro:
            await self.sphere_out(f, B, cb)
            if B:
                return
        self.show()  # строка чистая
