"""Экран WEATHER в стиле нейросети — порт hWh (hfunct.ino), wxneuro.ino и блока nbMorph (todayfx.ino) с ESP32.

Капли дождя собираются в WEATHER и стекают. Сеть собирает заголовок NOW, внизу — температуру; описание погоды
бежит между нейропорталами из шара; NOW стекает в сеть, она собирает живую сцену погоды (icons.py), и та
движется. Температура стекает и выныривает влажностью. Сцена стекает в сеть — та собирает Pressure, часы внизу
собирает сеть; Pressure перестраивается в Wind. Потом — Tomorrow так же (диапазон, описание, сцена), и весь
экран стекает дождём. Описание — по-русски (OpenWeather lang=ru, кириллица из шрифта Лины).
"""
from __future__ import annotations

import asyncio

import fx
import icons
from clockrow import SMALL_Y, ClockKeeper, now, row_drip, row_neuro
from matrix import BLUE, GREEN, RED, W, Screen, center_x, draw_text, morph, text_points
from ticker import Row

HOLD = 5  # секунд на каждый шаг, как на ESP
DIRS = ("N", "NE", "E", "SE", "S", "SW", "W", "NW")


def lround(v: float) -> int:
    return int(v + .5) if v >= 0 else -int(.5 - v)


class Wx:
    def __init__(self, scr: Screen):
        self.scr, self.title, self.nb, self.nbc = scr, [], [], []
        self.task = None
        self.scene = icons.Scene()

    # ---------- заголовок и сцена ----------
    async def title_in(self, t: str) -> None:
        """Заголовок наверху красным — из сети (wxTitleIn)."""
        self.title = text_points(t, center_x(t), 0)
        await morph(self.scr, [], None, self.title, RED, area=(0, 0, W, 11))

    async def title_to_icon(self, code: str) -> bool:
        """Заголовок стекает в сеть, она собирает живую сцену погоды — каждая точка своим цветом; дальше сцена
        движется сама (iconTick). False — сцены для кода нет, заголовок остаётся."""
        k = icons.kind(code)
        if k is None:
            return False
        b = self.scene.render(k, self.t())
        B, cb = [], []
        for i, c in enumerate(b):
            if c:
                B.append((i % icons.WX_W, i // icons.WX_W)); cb.append(c)
        await morph(self.scr, self.title, [RED] * len(self.title), B, cb, area=(0, 0, W, icons.WX_H))
        self.title = []
        self.task = asyncio.create_task(self._tick(k))
        return True

    @staticmethod
    def t() -> float:
        return asyncio.get_running_loop().time() % 3600

    async def _tick(self, k: int) -> None:  # кадр живой сцены раз в 40 мс
        px = self.scr.px
        while True:
            b = self.scene.render(k, self.t())
            buf = bytearray(icons.WX_W * icons.WX_H * 3)
            for i, c in enumerate(b):
                if c:
                    j = i * 3
                    buf[j] = int(c[0]); buf[j + 1] = int(c[1]); buf[j + 2] = int(c[2])
            px[:len(buf)] = buf
            await asyncio.sleep(.04)

    def icon_stop(self) -> None:
        if self.task:
            self.task.cancel()
            self.task = None

    # ---------- блок «заголовок + значение» над часами ----------
    def _points(self, title: str | None, val: str | None) -> tuple[list, list]:
        if not title:
            return [], []
        a, b = text_points(title, center_x(title), 0), text_points(val, center_x(val), 12)
        return a + b, [RED] * len(a) + [BLUE] * len(b)

    async def block(self, title: str | None, val: str | None) -> None:
        """Что в блоке, стекает в сеть, она собирает title (красный) и val (синий); None — блок гаснет."""
        B, cb = self._points(title, val)
        await morph(self.scr, self.nb, self.nbc, B, cb, area=(0, 0, W, SMALL_Y))
        self.nb, self.nbc = B, cb

    async def block_from_screen(self, title: str, val: str) -> None:
        """Всё, что над часами (сцена или текст), стекает в сеть, она собирает title и val (nbMorphFrom)."""
        P, C = self.scr.lit()
        A = [(p, c) for p, c in zip(P, C) if p[1] < SMALL_Y]
        B, cb = self._points(title, val)
        await morph(self.scr, [a for a, _ in A], [c for _, c in A], B, cb, area=(0, 0, W, SMALL_Y))
        self.nb, self.nbc = B, cb


def strings(w: dict) -> dict:
    """Строки, как у ESP: «9.3C», «91%», «762mmHg», «3M/S SW»."""
    s = lround(w.get("wind", 0))
    wind = f"{s}M/S {DIRS[(int(w.get('wdeg', 0)) % 360 + 22) // 45 % 8]}" if s else "NO DATA"
    return {"temp": f"{w['temp1']:.1f}C", "hum": f"{w['hum']}%", "press": f"{w['press']}mmHg", "wind": wind}


async def weather(scr: Screen, clock, mind) -> None:
    w = clock.weather or {}
    if "temp1" not in w:
        return
    s = strings(w)
    mind.calm(.12)
    P = await fx.rain_title_in(scr, "WEATHER")
    await scr.hold(.3)
    await fx.rain_title_out(scr, P)
    wx, keeper = Wx(scr), ClockKeeper(scr)
    try:
        await wx.title_in("NOW")
        await row_neuro(scr, s["temp"], GREEN)
        await Row(scr, 12).run(w.get("desc", ""), BLUE)
        if not await wx.title_to_icon(w.get("icon", "")):
            draw_text(scr, w.get("main", ""), center_x(w.get("main", "")), 12, BLUE)  # нет сцены — словом
        await scr.hold(HOLD)
        await row_drip(scr, s["temp"], s["hum"], GREEN)  # температура стекает, влажность выныривает
        await scr.hold(HOLD)
        await fx.slide_out_bottom(scr, s["hum"], GREEN)
        wx.icon_stop()
        await wx.block_from_screen("Pressure", s["press"])  # сцена стекает в сеть, она собирает давление
        await row_neuro(scr, now().strftime("%H:%M"), GREEN)
        keeper.start()
        await scr.hold(HOLD)
        await wx.block("Wind", s["wind"])  # давление перестраивается в ветер
        await scr.hold(HOLD)
        await wx.block(None, None)  # ветер растворяется в сети
        if w.get("fok") and icons.kind(w.get("fIcon", "")) is not None:  # завтра — как NOW
            keeper.stop()
            await fx.slide_out_bottom(scr, now().strftime("%H:%M"), GREEN)
            await wx.title_in("Tomorrow")
            await row_neuro(scr, w["fRange"], GREEN)
            await Row(scr, 12).run(w.get("fDesc", ""), BLUE)
            await wx.title_to_icon(w["fIcon"])
            await scr.hold(HOLD)
            wx.icon_stop()
    finally:
        wx.icon_stop()
        keeper.stop()
    await fx.rain_out(scr)  # WEATHER стекает дождём вместе со сценой
    mind.calm(1)
