"""Нижняя строка — маленькие часы и то, что встаёт на их место (температура, влажность), как на ESP32:
сеть собирает строку (row_neuro), минуты и значения стекают пикселями и выныривают (drip_small, row_drip),
двоеточие мигает, пока экран занят своим (ClockKeeper).
"""
from __future__ import annotations

import asyncio
import datetime as dt
import math
import random

from matrix import GREEN, Screen, center_x, draw_text, morph, text_points

SMALL_Y = 24                 # строка маленьких часов
SMALL_X = (17, 23, 35, 41)   # клетки цифр «HH:MM» (центр строки, как у ESP)


def now() -> dt.datetime:
    return dt.datetime.now()


def colon_small(scr: Screen, on: bool, color=GREEN) -> None:  # двоеточие «HH:MM» внизу
    for y in (26, 28):
        scr.set(31, y, color if on else (0, 0, 0))


def mix(c, w: float) -> tuple:  # цвет → к белому на долю w
    return tuple(v + (255 - v) * min(1.0, w) for v in c)


async def drip_small(scr: Screen, old: str, new: str, color) -> None:
    """Смена минут, как clkDripSmall на ESP: изменившиеся цифры стекают пикселями вниз за край (нижние
    срываются первыми, с ускорением), новые выныривают снизу, проскакивают на точку выше и встают, блестя."""
    if len(old) != 5 or len(new) != 5:
        return
    a, b = old[:2] + old[3:], new[:2] + new[3:]
    chg = [a[i] != b[i] for i in range(4)]
    if not any(chg):
        return
    Y = SMALL_Y

    def clear():
        for i in range(4):
            if chg[i]:
                scr.fill(SMALL_X[i], Y - 1, 5, 9)

    drops, cells = [], 0  # x, y, скорость, задержка
    for i in range(4):
        if chg[i]:
            for x, y in text_points(a[i], SMALL_X[i], Y):
                drops.append([x, float(y), 0.0, (Y + 6 - y) * 2 + random.randrange(5) + cells * 3])
            cells += 1
    half = tuple(v // 2 for v in color)
    for f in range(60):  # стекает
        clear()
        any_on = False
        for d in drops:
            if f >= d[3]:
                d[2] += .22; d[1] += d[2]
            y = round(d[1])
            if y < 32:
                any_on = True
                scr.set(d[0], y, color)
                if d[2] > .8 and y - 1 >= Y - 1:
                    scr.set(d[0], y - 1, half)  # тянется капля
        await scr.frame(0.018)
        if not any_on:
            break
    new_pts = [(c, text_points(b[i], SMALL_X[i], Y)) for c, i in enumerate(i for i in range(4) if chg[i])]
    F = 18
    for f in range(F + 6 * (cells - 1) + 1):  # выныривает
        clear()
        for c, pts in new_pts:
            e = min(1.0, max(0.0, (f - c * 6) / F))
            ofs = 9 * (1 - e / .7) - 1.3 * math.sin(e / .7 * math.pi / 2) if e < .7 else -1.3 * math.cos((e - .7) / .3 * math.pi / 2)
            shine = .5 * math.sin(e * math.pi) if e < 1 else 0
            for x, y in pts:
                yy = round(y + ofs)
                if Y - 1 <= yy < 32:
                    scr.set(x, yy, mix(color, shine + (shine if y == Y else 0)))
        await scr.frame(0.02)
    clear()
    for _, pts in new_pts:
        for x, y in pts:
            scr.set(x, y, color)


async def row_neuro(scr: Screen, text: str, color) -> None:
    """Строку часов внизу собирает сеть — точки сразу своим цветом (rowNeuro на ESP)."""
    await morph(scr, [], None, text_points(text, center_x(text), SMALL_Y), color, area=(0, SMALL_Y, 64, 32))


class ClockKeeper:
    """Маленькие часы, пока экран занят своим: двоеточие мигает, новая минута просто встаёт (как colonTick)."""

    def __init__(self, scr: Screen, color=GREEN):
        self.scr, self.task, self.color = scr, None, color

    async def _run(self) -> None:
        shown = now().strftime("%H:%M")
        while True:
            t = now()
            hm = t.strftime("%H:%M")
            if hm != shown:
                shown = hm
                self.scr.fill(0, SMALL_Y, 64, 8)
                draw_text(self.scr, hm, center_x(hm), SMALL_Y, self.color)
            colon_small(self.scr, t.second % 2 == 0, self.color)
            await asyncio.sleep(.25)

    def start(self) -> None:
        self.task = asyncio.create_task(self._run())

    def stop(self) -> None:
        if self.task:
            self.task.cancel()


async def row_drip(scr: Screen, old: str, new: str, color) -> None:
    """Любой текст в строке часов (погода: температура → влажность), как rowDripSmall: изменившиеся знаки
    стекают, новые выныривают по очереди; разной длины — меняется вся строка."""
    Y, la, lb = SMALL_Y, len(old), len(new)
    xa, xb = (64 - la * 6) // 2, (64 - lb * 6) // 2
    chg = lambda i: la != lb or old[i] != new[i]
    drops, cells = [], 0
    for i in range(la):
        if chg(i):
            for x, y in text_points(old[i], xa + i * 6, Y):
                drops.append([x, float(y), 0.0, (Y + 6 - y) * 2 + random.randrange(5) + min(cells, 8) * 3])
            cells += 1
    half = tuple(v // 2 for v in color)
    for f in range(60 if drops else 0):  # стекает
        for i in range(la):
            if chg(i):
                scr.fill(xa + i * 6, Y - 1, 6, 9)
        any_on = False
        for d in drops:
            if f >= d[3]:
                d[2] += .22; d[1] += d[2]
            y = round(d[1])
            if y < 32:
                any_on = True
                scr.set(d[0], y, color)
                if d[2] > .8 and y - 1 >= Y - 1:
                    scr.set(d[0], y - 1, half)
        await scr.frame(.018)
        if not any_on:
            break
    for i in range(la):
        if chg(i):
            scr.fill(xa + i * 6, Y - 1, 6, 9)
    cellsB = [(c, text_points(new[i], xb + i * 6, Y), i) for c, i in enumerate(i for i in range(lb) if chg(i))]
    if not cellsB:
        return
    F = 18
    for f in range(F + 6 * (len(cellsB) - 1) + 1):  # выныривает
        for _, _, i in cellsB:
            scr.fill(xb + i * 6, Y - 1, 6, 9)
        for c, pts, _ in cellsB:
            e = min(1.0, max(0.0, (f - c * 6) / F))
            ofs = 9 * (1 - e / .7) - 1.3 * math.sin(e / .7 * math.pi / 2) if e < .7 else -1.3 * math.cos((e - .7) / .3 * math.pi / 2)
            shine = .5 * math.sin(e * math.pi) if e < 1 else 0
            for x, y in pts:
                yy = round(y + ofs)
                if Y - 1 <= yy < 32:
                    scr.set(x, yy, mix(color, shine + (shine if y == Y else 0)))
        await scr.frame(.02)
    for _, _, i in cellsB:
        scr.fill(xb + i * 6, Y - 1, 6, 9)
    for _, pts, _ in cellsB:
        for x, y in pts:
            scr.set(x, y, color)
