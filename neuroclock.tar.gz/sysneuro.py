"""Экран SYSTEM — живые часы рассказывают о себе и о комнате. Заголовок SYSTEM — анонс экрана: каждая буква
собирается своим эффектом (S — нейроны, Y — пузырьки, S — сигналы, T — ячейки, E — волна, M — нейроны), по
собранным пробегает свет — они краснеют; уходят в обратном порядке теми же эффектами. В конце весь экран падает
колонками; часы внизу собирает сеть. Значения — подпись сверху и
цифры обычного размера, у каждого своё появление, жизнь и уход:
  SENSOR °C — температура: маленькая нейросеть «думает» цифры: нейроны зажигаются, связи натягиваются, нейроны
             по очереди вспыхивают и выпускают точки цифр на места (цветом температуры); пока стоят — по связям
             бегут импульсы, дошёл до нейрона — его часть цифр вспыхивает; в тепле нейроны дрожат живее; уходя,
             нейроны втягивают свои точки и гаснут;
  SENSOR %  — влажность: цифры собираются из голубых пиксельных пузырьков, всплывающих снизу, и так же уходят
             пузырьками вверх; пока стоят — как под водой: бегут блики, строки колышутся, изредка всплывает
             пузырёк;
  CPU   °C — дорожки платы: цифры приносят сигналы — бегут по дорожкам, спрыгивают на своё место и встают точкой;
             пока стоят — по дорожкам бегут импульсы, тем быстрее, чем занятее процессор; уходя, точки
             спрыгивают на дорожки и уплывают сигналами вправо;
  CPU   %  — загрузка процессора, так же сигналами (цвет — по загрузке);
  RAM   %  — ячейки памяти: точки цифр записываются вразброс — мигают, как ячейка при записи, и остаются; ячейка
             под точкой вспыхивает; пока стоят — занятые ячейки светятся, в них вспыхивает запись; стираются так же;
  Wi-Fi %  — волны от антенны внизу: фронт волны, проходя, проявляет точки (ближние к антенне — первыми);
             пока стоят — волны расходятся тем дальше, чем сильнее сигнал; уходя, волна уносит точки наружу.
Wi-Fi — в процентах, как «сила сигнала» NetworkManager (полоски в панели Wi-Fi). Комнату показывает выносной
датчик BME280 (state["room"]: t, h); нет датчика — только система (state: cpuTemp, cpu, frhp/totalHeap, rssi).
"""
from __future__ import annotations

import asyncio
import math
import random
import time

import fx
from clockrow import SMALL_Y, ClockKeeper, now, row_neuro
from matrix import GREEN, RED, W, Screen, center_x, glyph, text_points

AH = SMALL_Y          # поле над часами: строки 0..23 (подпись — строка 0, цифры — строка 12)
VY = 12               # строка цифр, как у значений на других экранах
HOLD = 6              # секунд на значение
G = .32               # тяжесть: буквы падают, как заголовок
TEMP, HUM, CHIP, MEM, WAVES = range(5)


def num(v, default: float = 0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def mixc(a, b, k: float) -> tuple:
    k = min(1.0, max(0.0, k))
    return tuple(a[i] + (b[i] - a[i]) * k for i in range(3))


def t_color(t: float) -> tuple:
    """Комната: холодно — голубое, 21–23 — бирюзовое, жарко — оранжевое."""
    return mixc((90, 170, 255), (60, 235, 175), (t - 17) / 4) if t < 21 else mixc((60, 235, 175), (255, 140, 50), (t - 23) / 3)


def cpu_color(t: float) -> tuple:
    """Процессор: до 50 — бирюза, к 65 — жёлтый, к 75 — красный."""
    return mixc((0, 200, 230), (245, 205, 40), (t - 50) / 15) if t < 65 else mixc((245, 205, 40), (255, 60, 30), (t - 65) / 10)


def wifi_pct(rssi: float) -> int:
    """Сила сигнала в процентах — как у NetworkManager (nmcli SIGNAL, полоски в панели Wi-Fi): −40 дБм и
    лучше — 100 %, −100 — 0."""
    return 100 - int(100 * abs(min(-40.0, max(-100.0, rssi)) + 40) / 60)


def wifi_q(rssi: float) -> float:
    return wifi_pct(rssi) / 100


def wifi_color(rssi: float) -> tuple:
    q = wifi_q(rssi)
    return mixc((255, 70, 40), (245, 205, 40), q / .5) if q < .5 else mixc((245, 205, 40), (60, 230, 110), (q - .5) / .3)


def traces() -> list:
    """Дорожки платы: от края к краю, с изломами под 45°, каждая — список точек (одни и те же каждый раз)."""
    rnd, out = random.Random(7), []
    for k in range(6):
        y, x, pts = 1 + k * 4 + rnd.randrange(2), 0, []
        while x < W:
            pts.append((x, y))
            x += 1
            if rnd.random() < .12 and 1 <= y < AH - 2:
                d = rnd.choice((-1, 1))
                for _ in range(rnd.randrange(1, 3)):  # излом
                    if 0 <= y + d < AH:
                        y += d
                        pts.append((x, y))
                        x += 1
        out.append(pts)
    return out


TRACES = traces()
AT_X = [{} for _ in TRACES]  # дорожка: x → первый номер её точки с этим x
for _k, _tr in enumerate(TRACES):
    for _i, (_x, _y) in enumerate(_tr):
        AT_X[_k].setdefault(_x, _i)
CELLS = [(cx * 4, cy * 3) for cy in range(8) for cx in range(16)]  # 128 ячеек 3x2
ORDER = random.Random(3).sample(range(len(CELLS)), len(CELLS))  # как занята память — вразброс


class Board:
    """Поле 64x24: фон своего значения, подпись и крупные цифры, которые падают и срываются; рисует себя само."""

    def __init__(self, scr: Screen):
        self.scr, self.kind, self.v, self.a = scr, None, {}, 0.0
        self.pts, self.li, self.cols = [], [], []
        self.dy, self.vy, self.wait = [], [], []
        self.out = self.busy = False
        self.task = None
        self.nn: list = []     # температура: нейроны — дом x, y, фаза, когда вспыхнул, яркость вспышки
        self.np: list = []     # её точки: номер нейрона, откуда летит x, y, задержка, доля пути, вспышка
        self.lk: list = []     # связи между нейронами и импульсы по ним
        self.ip: list = []
        self.wv: list = []     # Wi-Fi: у каждой точки — расстояние до антенны, где она, скорость, жизнь, вспышка
        self.ring = -1.0       # фронт волны, что проявляет или уносит точки
        self.mw: list = []     # RAM: у каждой точки — когда записать или стереть
        self.sg: list = []     # CPU: у каждой точки свой сигнал — дорожка, цель на ней, где он, этап, прыжок, задержка
        self.bb: list = []     # влажность: у каждой точки свой пузырёк — x, y, скорость, задержка, фаза, состояние
        self.amb: list = []    # и редкие пузырьки, всплывающие рядом, пока цифры стоят
        self.pulse = [[random.randrange(len(TRACES)), random.uniform(0, 1)] for _ in range(7)]
        self.flash: dict = {}  # ячейка памяти → яркость записи
        self.n, self.bg, self.ov, self.lett = 0, None, None, []  # кадр, прежний фон, готовые подпись и цифры

    # ---------- текст ----------
    def set_text(self, label: str, lc, text: str, col) -> None:
        """Подпись сверху, значение — в строке VY, обычным шрифтом; падают сначала подпись, потом буквы значения."""
        L = text_points(label, center_x(label), 0)
        x0 = center_x(text)
        P = text_points(text, x0, VY)
        self.pts = L + P
        self.li = [0] * len(L) + [1 + (x - x0) // 6 for x, _ in P]
        self.cols = [lc] * len(L) + [col] * len(P)
        n = max(self.li, default=0) + 1
        self.dy = [-(VY + 10.0 if i else 10.0) - (i % 2) * 3 for i in range(n)]
        self.vy, self.wait = [0.0] * n, [i * 4 for i in range(n)]
        self.out, self.ov, self.bg = False, None, None
        self.lett = self.letters()

    def step(self) -> bool:
        """Шаг падения букв; True — что-то ещё движется."""
        moving = False
        for i in range(len(self.dy)):
            if self.wait[i] > 0:
                self.wait[i] -= 1; moving = True
                continue
            if self.out:
                if self.dy[i] < AH + 2:
                    self.vy[i] += G; self.dy[i] += self.vy[i]; moving = True
                continue
            if self.dy[i] < 0 or self.vy[i]:
                self.vy[i] += G; self.dy[i] += self.vy[i]
                if self.dy[i] >= 0:  # удар — отскок всё меньше
                    self.dy[i] = 0.0
                    self.vy[i] = -self.vy[i] * .3 if self.vy[i] > 1 else 0.0
                moving = True
        return moving

    async def drop_in(self, kind: int, label: str, lc, text: str, col, v: dict) -> None:
        self.kind, self.v = kind, v
        self.set_text(label, lc, text, col)
        self.busy = True
        for _ in range(120):
            self.a = min(1.0, self.a + .05)
            await self.scr.frame()
            if not self.step() and self.a >= 1:
                break
        self.busy = False

    async def drop_out(self) -> None:
        self.out, self.busy = True, True
        self.wait = [i * 3 for i in range(len(self.dy))]
        for _ in range(120):
            self.a = max(0.0, self.a - .04)
            await self.scr.frame()
            if not self.step() and self.a <= 0:
                break
        self.pts, self.busy, self.ov = [], False, None

    # ---------- температура: нейроны ----------
    def nodes_at(self, t: float) -> list:
        """Где нейроны сейчас: дрожат возле дома — в тепле живее (16 °C — спокойно, 28 — вовсю)."""
        w = min(1.0, max(0.0, (num(self.v.get("t"), 22) - 16) / 12))
        amp, sp = .5 + 1.5 * w, .8 + 2.2 * w
        return [(n[0] + math.sin(t * sp + n[2]) * amp, n[1] + math.cos(t * sp * .8 + n[2] * 1.7) * amp * .7) for n in self.nn]

    async def neuro_in(self, label: str, lc, text: str, col, v: dict) -> None:
        """Нейроны зажигаются, связи натягиваются; нейроны слева направо вспыхивают и выпускают точки на места."""
        self.kind, self.v, self.a = TEMP, v, 0.0
        self.set_text(label, lc, text, col)
        x0, x1 = min(x for x, _ in self.pts), max(x for x, _ in self.pts)
        k = 7
        self.nn = [[x0 - 4 + (x1 - x0 + 8) * (i + .5) / k + random.uniform(-2, 2), (5 if i % 2 else 21) + random.uniform(-1.5, 1.5),
                    random.uniform(0, 6.3), -99, 0.0] for i in range(k)]
        self.nn.append([4.0, 13 + random.uniform(-3, 3), random.uniform(0, 6.3), -99, 0.0])       # и по краям
        self.nn.append([W - 5.0, 13 + random.uniform(-3, 3), random.uniform(0, 6.3), -99, 0.0])
        self.lk = [(i, j) for i in range(len(self.nn)) for j in range(i + 1, len(self.nn))
                   if math.hypot(self.nn[i][0] - self.nn[j][0], self.nn[i][1] - self.nn[j][1]) < 19]
        self.ip = []
        order = sorted(range(k), key=lambda i: self.nn[i][0])  # вспыхивают слева направо
        fire = {i: 22 + n * 7 for n, i in enumerate(order)}
        self.np = []
        for x, y in self.pts:
            i = min(range(k), key=lambda i: (self.nn[i][0] - x) ** 2 + (self.nn[i][1] - y) ** 2)
            self.np.append([i, 0.0, 0.0, fire[i] + random.randrange(8), 0.0, 0.0])
        self.busy = True
        for f in range(200):
            self.f = f
            self.a = min(1.0, f / 18)
            for i, n in enumerate(self.nn):
                if fire.get(i) == f:
                    n[3], n[4] = f, 1.0
            moving = f < 24
            for q in self.np:
                if q[4] < 1:
                    moving = True
                    if f >= q[3]:
                        q[4] = min(1.0, q[4] + 1 / 14)
            self.decay()
            await self.scr.frame()
            if not moving:
                break
        self.busy = False

    async def neuro_out(self) -> None:
        """Нейроны по очереди вспыхивают и втягивают свои точки; потом гаснут."""
        order = sorted(range(len(self.nn)), key=lambda i: self.nn[i][0])
        start = {i: n * 6 for n, i in enumerate(order)}
        for q in self.np:
            q[3] = start[q[0]] + random.randrange(6)
        self.busy = True
        for f in range(200):
            for i, n in enumerate(self.nn):
                if start.get(i) == f:
                    n[4] = 1.0
            left = False
            for q in self.np:
                if q[4] > 0:
                    left = True
                    if f >= q[3]:
                        q[4] = max(0.0, q[4] - 1 / 12)
            if not left:
                self.a = max(0.0, self.a - .06)
            self.decay()
            await self.scr.frame()
            if not left and self.a <= 0:
                break
        self.pts, self.np, self.nn, self.lk, self.ip, self.busy = [], [], [], [], [], False

    def decay(self) -> None:
        for n in self.nn:
            n[4] *= .88
        for q in self.np:
            q[5] *= .9

    def draw_neuro(self, t: float) -> None:
        b = bytearray(W * AH * 3)
        put, a = self.put, self.a
        P = self.nodes_at(t)
        for i, j in self.lk:  # связи — тусклые, дышат
            (x1, y1), (x2, y2) = P[i], P[j]
            m = (.28 + .12 * math.sin(t * 2 + i + j)) * a
            n = int(max(abs(x2 - x1), abs(y2 - y1))) + 1
            for s in range(1, n):
                u = s / n
                put(b, int(x1 + (x2 - x1) * u + .5), int(y1 + (y2 - y1) * u + .5), 55 * m, 25 * m, 130 * m)
        if not self.busy and self.lk and len(self.ip) < 3 and random.random() < .06:  # импульс по связи
            i, j = random.choice(self.lk)
            self.ip.append([i, j, 0.0] if random.random() < .5 else [j, i, 0.0])
        for p in self.ip:  # импульс бежит; дошёл — нейрон вспыхивает, и его точки тоже
            p[2] += .05
            (x1, y1), (x2, y2) = P[p[0]], P[p[1]]
            for k, m in ((0, 1), (1, .45), (2, .18)):
                u = p[2] - k * .08
                if 0 <= u <= 1:
                    put(b, int(x1 + (x2 - x1) * u + .5), int(y1 + (y2 - y1) * u + .5), 200 * m * a, 240 * m * a, 255 * m * a)
            if p[2] >= 1:
                self.nn[p[1]][4] = 1.0
                for q in self.np:
                    if q[0] == p[1]:
                        q[5] = 1.0
        self.ip = [p for p in self.ip if p[2] < 1]
        for (x, y), n in zip(P, self.nn):  # нейроны: ядро и крестик-ореол, вспышка — белым
            f = n[4]
            put(b, int(x + .5), int(y + .5), (0 + 255 * f) * a, (170 + 85 * f) * a, 255 * a)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                put(b, int(x + .5) + dx, int(y + .5) + dy, 60 * f * a, (30 + 80 * f) * a, (70 + 120 * f) * a)
        if not self.busy:
            self.decay()
        for q, (tx, ty), c in zip(self.np, self.pts, self.cols):  # точки цифр: летят из нейрона, вспыхивают с ним
            u = q[4]
            if u <= 0:
                continue
            nx, ny = P[q[0]]
            e = u * u * (3 - 2 * u)
            x, y = nx + (tx - nx) * e, ny + (ty - ny) * e
            w = max(1 - u, q[5] * .7)  # в полёте и во вспышке — к белому
            put(b, int(x + .5), int(y + .5), c[0] + (255 - c[0]) * w, c[1] + (255 - c[1]) * w, c[2] + (255 - c[2]) * w)
        self.scr.px[:len(b)] = b

    # ---------- CPU: сигналы по дорожкам ----------
    async def chip_in(self, label: str, lc, text: str, col, v: dict, keep: bool = False) -> None:
        """Сигналы бегут по дорожкам слева, у своего x спрыгивают на место точки и встают — со вспышкой.
        keep — подпись уже стоит (CPU °C → CPU %): прибегает только значение."""
        old = [q for q, i in zip(self.sg, self.li) if i == 0] if keep else []
        self.kind, self.v = CHIP, v
        if not keep:
            self.a = 0.0
        self.set_text(label, lc, text, col)
        x0 = min(x for x, _ in self.pts)
        self.sg = []
        for n, (x, y) in enumerate(self.pts):
            if keep and self.li[n] == 0 and n < len(old):
                self.sg.append(old[n]); continue
            k = min((k for k in range(len(TRACES)) if x in AT_X[k]), key=lambda k: abs(TRACES[k][AT_X[k][x]][1] - y))
            self.sg.append([k, AT_X[k][x], 0.0, 0, 0.0, int((x - x0) * 1.1) + random.randrange(20), 0.0])
        self.busy = True
        for f in range(220):
            self.a = min(1.0, self.a + .06)
            moving = False
            for q, (tx, ty) in zip(self.sg, self.pts):
                if q[3] == 0:                     # ждёт
                    moving = True
                    q[5] -= 1
                    if q[5] <= 0:
                        q[3] = 1
                elif q[3] == 1:                   # бежит по дорожке
                    moving = True
                    q[2] = min(float(q[1]), q[2] + 1.5)
                    if q[2] >= q[1]:
                        q[3] = 2
                elif q[3] == 2:                   # спрыгивает на место
                    moving = True
                    q[4] = min(1.0, q[4] + 1 / (abs(ty - TRACES[q[0]][q[1]][1]) / 1.6 + 1))
                    if q[4] >= 1:
                        q[3], q[6] = 3, 1.0
            for q in self.sg:
                q[6] *= .85
            await self.scr.frame()
            if not moving:
                break
        self.busy = False

    async def chip_out(self, value_only: bool = False) -> None:
        """Точки спрыгивают на дорожки и уплывают сигналами вправо, разгоняясь. value_only — подпись остаётся."""
        x0 = min((x for x, _ in self.pts), default=0)
        for q, (tx, _), i in zip(self.sg, self.pts, self.li):
            if value_only and i == 0:
                continue
            q[3], q[5], q[4] = 4, int((tx - x0) * .3) + random.randrange(16), 1.0
        self.busy = True
        for f in range(220):
            moving = False
            for q, (tx, ty) in zip(self.sg, self.pts):
                if q[3] == 4:
                    moving = True
                    if q[5] > 0:
                        q[5] -= 1
                        continue
                    q[4] = max(0.0, q[4] - 1 / (abs(ty - TRACES[q[0]][q[1]][1]) / 1.6 + 1))
                    if q[4] <= 0:
                        q[3], q[6] = 5, 1.2    # на дорожке — побежал; q[6] — скорость
                elif q[3] == 5:
                    moving = True
                    q[6] = min(4.0, q[6] + .12)
                    q[2] += q[6]
                    if q[2] >= len(TRACES[q[0]]) + 4:
                        q[3] = 6
            if not moving and not value_only:
                self.a = max(0.0, self.a - .08)
            await self.scr.frame()
            if not moving and (value_only or self.a <= 0):
                break
        if value_only:  # подпись стоит — ждёт новое значение
            keep = [n for n, i in enumerate(self.li) if i == 0]
            self.pts, self.sg = [self.pts[n] for n in keep], [self.sg[n] for n in keep]
            self.cols, self.li = [self.cols[n] for n in keep], [0] * len(keep)
            self.busy = False
            return
        self.pts, self.sg, self.busy = [], [], False

    def draw_chip(self, t: float) -> None:
        b = bytearray(W * AH * 3)
        put, a = self.put, self.a
        self.bg_chip(b, t, a)
        for q, (tx, ty), c in zip(self.sg, self.pts, self.cols):
            st = q[3]
            if st in (1, 5):                      # сигнал на дорожке: голова и хвост
                tr = TRACES[q[0]]
                for k, m in ((0, 1), (1, .5), (2, .25), (3, .1)):
                    i = int(q[2]) - k * (2 if st == 5 and q[6] > 2 else 1)
                    if 0 <= i < len(tr):
                        x, y = tr[i]
                        put(b, x, y, (c[0] + (255 - c[0]) * .6) * m, (c[1] + (255 - c[1]) * .6) * m, (c[2] + (255 - c[2]) * .6) * m)
            elif st in (2, 4):                    # прыжок между дорожкой и местом точки
                sx, sy = TRACES[q[0]][q[1]]
                u = q[4]
                put(b, int(sx + (tx - sx) * u + .5), int(sy + (ty - sy) * u + .5), 230, 245, 255)
            elif st == 3:                         # точка на месте; только что встала — вспышка
                w = q[6]
                put(b, tx, ty, c[0] + (255 - c[0]) * w, c[1] + (255 - c[1]) * w, c[2] + (255 - c[2]) * w)
        self.scr.px[:len(b)] = b

    # ---------- Wi-Fi: волны рисуют и уносят ----------
    OX, OY = 31.5, AH - .5  # антенна — внизу поля, по центру

    def arc(self, b: bytearray, r: float, c, m: float) -> None:
        """Дуга волны радиуса r (растянута вширь, как у фона)."""
        if r <= 0:
            return
        n = int(math.pi * r * 2.4) + 3
        for s in range(n):
            ang = math.pi * s / (n - 1)
            self.put(b, int(self.OX + math.cos(ang) * r * 1.6 + .5), int(self.OY - math.sin(ang) * r + .5), c[0] * m, c[1] * m, c[2] * m)

    async def wave_in(self, label: str, lc, text: str, col, v: dict) -> None:
        """Яркий фронт волны расходится от антенны и, проходя, проявляет точки со вспышкой."""
        self.kind, self.v, self.a = WAVES, v, 0.0
        self.set_text(label, lc, text, col)
        self.wv = [[math.hypot((x - self.OX) / 1.6, y - self.OY), float(x), float(y), 0.0, 0.0, 0.0, 0.0] for x, y in self.pts]
        dmax = max(q[0] for q in self.wv) + 3
        self.ring, self.busy = 0.0, True
        while self.ring < dmax:
            self.ring += .45
            self.a = min(1.0, self.a + .03)
            for q in self.wv:
                if q[5] == 0 and self.ring >= q[0]:
                    q[5], q[6] = 1.0, 1.0      # проявилась
                q[6] *= .88
            await self.scr.frame()
        self.ring, self.busy = -1.0, False

    async def wave_out(self) -> None:
        """Волна проходит ещё раз и уносит точки за собой наружу; они гаснут на лету."""
        dmax = max((q[0] for q in self.wv), default=0) + 3
        self.ring, self.busy = 0.0, True
        for f in range(240):
            if self.ring >= 0:
                self.ring += .5
                if self.ring > dmax + 30:
                    self.ring = -1.0
            alive = False
            for q in self.wv:
                if q[5] <= 0:
                    continue
                alive = True
                if q[3] == 0 and self.ring >= q[0]:  # подхватила волна
                    dx, dy = (q[1] - self.OX) / 1.6, q[2] - self.OY
                    l = max(.5, math.hypot(dx, dy))
                    q[3], q[4] = dx / l * 1.6, dy / l  # направление (в шагах по экрану)
                    q[6] = .6
                if q[3] or q[4]:
                    sp = .5 + (1 - q[5]) * 1.2
                    q[1] += q[3] * sp; q[2] += q[4] * sp
                    q[5] -= .035
                q[6] *= .88
            if not alive:
                self.a = max(0.0, self.a - .06)
            await self.scr.frame()
            if not alive and self.a <= 0:
                break
        self.pts, self.wv, self.ring, self.busy = [], [], -1.0, False

    def draw_wave(self, t: float) -> None:
        b = bytearray(W * AH * 3)
        self.bg_waves(b, t, self.a)
        c0 = wifi_color(num(self.v.get("rssi"), -60))
        if self.ring >= 0:  # фронт — ярче фоновых волн, к белому
            self.arc(b, self.ring, (c0[0] + (255 - c0[0]) * .5, c0[1] + (255 - c0[1]) * .5, c0[2] + (255 - c0[2]) * .5), .9)
        for q, c in zip(self.wv, self.cols):
            if q[5] <= 0:
                continue
            w, m = q[6], min(1.0, q[5])
            self.put(b, int(q[1] + .5), int(q[2] + .5), (c[0] + (255 - c[0]) * w) * m, (c[1] + (255 - c[1]) * w) * m,
                     (c[2] + (255 - c[2]) * w) * m)
        self.scr.px[:len(b)] = b

    # ---------- RAM: запись в ячейки ----------
    BLINK = (1, 0, 1, 1, 0, 1, 1, 1)  # запись: точка мигает, как ячейка памяти, и остаётся
    WIPE = (0, 1, 0, 1, 0, 0, 1, 0)   # стирание: мигает и гаснет

    @staticmethod
    def cell(x: int, y: int) -> int:
        return (y // 3) * 16 + x // 4

    async def mem_in(self, label: str, lc, text: str, col, v: dict) -> None:
        """Точки записываются вразброс: каждая в своё время мигает и остаётся, ячейка под ней вспыхивает."""
        self.kind, self.v, self.a = MEM, v, 0.0
        self.set_text(label, lc, text, col)
        self.mw = [12 + random.randrange(70) for _ in self.pts]  # когда запись начнётся
        self.f0, self.busy = 0, True
        for f in range(12 + 70 + len(self.BLINK) + 2):
            self.f0 = f
            self.a = min(1.0, self.a + .06)
            for w, (x, y) in zip(self.mw, self.pts):
                if f == w:
                    self.flash[self.cell(x, y)] = 1.0
            await self.scr.frame()
        self.busy = False

    async def mem_out(self) -> None:
        """Стирание вразброс: точка мигает и гаснет, ячейка под ней вспыхивает."""
        self.mw = [-1 - random.randrange(70) for _ in self.pts]  # минус — стирание, когда начнётся
        self.busy = True
        for f in range(70 + len(self.WIPE) + 2):
            self.f0 = f
            for w, (x, y) in zip(self.mw, self.pts):
                if f == -1 - w:
                    self.flash[self.cell(x, y)] = 1.0
            await self.scr.frame()
        for _ in range(20):
            self.a = max(0.0, self.a - .06)
            await self.scr.frame()
        self.pts, self.mw, self.busy = [], [], False

    def draw_mem(self, t: float) -> None:
        b = bytearray(W * AH * 3)
        self.bg_mem(b, t, self.a)
        f, on = getattr(self, "f0", 0), []
        for w, (x, y), c in zip(self.mw, self.pts, self.cols):
            if w >= 0:                      # запись
                k = f - w if self.busy else 99
                if k < 0:
                    continue
                if k < len(self.BLINK):
                    if self.BLINK[k]:
                        on.append((x, y, (235, 225, 255)))
                    continue
            else:                           # стирание
                k = f - (-1 - w)
                if k >= len(self.WIPE):
                    continue
                if k >= 0:
                    if self.WIPE[k]:
                        on.append((x, y, (235, 225, 255)))
                    continue
            on.append((x, y, c))
        lit = {(x, y) for x, y, _ in on}
        for x, y in lit:  # тёмная обводка: цифры не тонут в ячейках
            for xx, yy in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                if 0 <= xx < W and 0 <= yy < AH and (xx, yy) not in lit:
                    j = (yy * W + xx) * 3
                    b[j] = b[j + 1] = b[j + 2] = 0
        for x, y, c in on:
            self.put(b, x, y, *c)
        self.scr.px[:len(b)] = b

    # ---------- влажность: пузырьки ----------
    async def bubble_in(self, label: str, lc, text: str, col, v: dict) -> None:
        """Каждая точка подписи и цифр — голубой пузырёк: всплывает снизу, покачиваясь, и встаёт на своё место."""
        self.kind, self.v, self.a = HUM, v, 1.0
        self.set_text(label, lc, text, col)
        self.dy = [0.0] * len(self.dy)
        self.bb = [[x + random.uniform(-3, 3), AH + 1 + random.uniform(0, 7), -random.uniform(.35, .6),
                    random.randrange(28) + (x % 64) // 8, random.uniform(0, 6.3), 0] for x, _ in self.pts]
        self.amb, self.busy = [], True
        for f in range(160):
            moving = False
            for q, (tx, ty) in zip(self.bb, self.pts):
                if q[5] == 0:
                    q[3] -= 1
                    if q[3] <= 0:
                        q[5] = 1
                    moving = True
                elif q[5] == 1:
                    q[1] += q[2]
                    k = min(1.0, max(0.0, (q[1] - ty) / 10))  # ближе к месту — меньше качается, точнее по x
                    q[0] += (tx - q[0]) * (.18 - .12 * k) + math.sin(f * .35 + q[4]) * .3 * k
                    if q[1] <= ty:
                        q[0], q[1], q[5] = tx, ty, 2
                    moving = True
            await self.scr.frame()
            if not moving:
                break
        self.busy = False

    async def bubble_out(self) -> None:
        """Точки отрываются пузырьками и всплывают вверх, разгоняясь и тая у верхнего края."""
        self.busy = True
        for q in self.bb:
            q[3], q[2], q[5] = random.randrange(26), -random.uniform(.15, .3), 3
        for f in range(120):
            moving = False
            for q in self.bb:
                if q[5] != 3:
                    continue
                if q[3] > 0:
                    q[3] -= 1; moving = True
                    continue
                q[2] -= .03                                   # всплывает всё быстрее
                q[1] += q[2]
                q[0] += math.sin(f * .35 + q[4]) * .35
                if q[1] < -1:
                    q[5] = 4
                else:
                    moving = True
            await self.scr.frame()
            if not moving:
                break
        self.pts, self.bb, self.busy, self.ov, self.a = [], [], False, None, 0.0

    def draw_hum(self, t: float) -> None:
        b = bytearray(W * AH * 3)
        put = self.put
        for q, (tx, ty), c in zip(self.bb, self.pts, self.cols):
            if q[5] == 2:
                if ty < VY:  # подпись — ровно
                    put(b, tx, ty, *c)
                    continue
                # под водой: раз в несколько секунд по цифрам сверху вниз пробегает рябь — сдвигает одну строку
                # на точку; по цифрам бегут блики
                rip = (t * 6) % 40 - 4
                x = tx + (1 if abs(ty - VY - rip) < .5 and (tx + ty) % 2 else 0)
                k = max(0.0, math.sin(tx * .45 + t * 2.1) * math.sin(ty * .7 - t * 1.3 + tx * .2))
                k = k * k * .8
                put(b, x, ty, c[0] + (255 - c[0]) * k, c[1] + (255 - c[1]) * k, c[2] + (255 - c[2]) * k)
            elif q[5] in (1, 3) and q[3] <= 0:  # пузырёк: светлый, иногда с бликом
                m = 1.0 if q[5] == 1 else min(1.0, max(0.0, q[1] / 6 + .2))
                h = .7 + .3 * math.sin(t * 9 + q[4])
                put(b, int(q[0] + .5), int(q[1] + .5), 120 * h * m, 200 * h * m, 255 * m)
        if not self.busy and self.bb:  # редкие пузырьки рядом с цифрами
            if random.random() < .04 and len(self.amb) < 4:
                self.amb.append([random.uniform(4, W - 4), AH - .5, random.uniform(0, 6.3)])
            for a in self.amb:
                a[1] -= .25
                put(b, int(a[0] + math.sin(t * 3 + a[2]) * .8), int(a[1]), 60, 120, 190)
            self.amb = [a for a in self.amb if a[1] > -1]
        self.scr.px[:len(b)] = b

    # ---------- фоны ----------
    @staticmethod
    def put(b: bytearray, x: int, y: int, r: float, g: float, bb: float) -> None:
        if 0 <= x < W and 0 <= y < AH:
            j = (y * W + x) * 3
            b[j] = int(r); b[j + 1] = int(g); b[j + 2] = int(bb)

    def bg_chip(self, b: bytearray, t: float, a: float) -> None:
        c = cpu_color(num(self.v.get("cpuTemp"), 55))
        load = min(1.0, max(0.0, num(self.v.get("cpu"), 30) / 100))
        for tr in TRACES:  # дорожки и переходные отверстия на концах
            for x, y in tr:
                self.put(b, x, y, c[0] * .24 * a, c[1] * .24 * a, c[2] * .24 * a)
        for p in self.pulse:  # импульсы: быстрее, когда процессор занят
            tr = TRACES[p[0]]
            p[1] += (.004 + .02 * load) * (1 + p[0] % 3 * .3)
            if p[1] >= 1:
                p[0], p[1] = random.randrange(len(TRACES)), 0.0
                tr = TRACES[p[0]]
            i = int(p[1] * (len(tr) - 1))
            for k, m in ((0, 1), (1, .6), (2, .38), (3, .22), (4, .1)):
                if i - k >= 0:
                    x, y = tr[i - k]
                    w = .35 + .65 * m
                    self.put(b, x, y, (c[0] + (255 - c[0]) * .5 * m) * w * a, (c[1] + (255 - c[1]) * .5 * m) * w * a,
                             (c[2] + (255 - c[2]) * .5 * m) * w * a)

    def bg_mem(self, b: bytearray, t: float, a: float) -> None:
        used = int(len(CELLS) * min(1.0, max(0.0, num(self.v.get("ram"), 50) / 100)) + .5)
        busy = set(ORDER[:used])
        if busy and random.random() < .5:  # запись в случайную занятую ячейку
            self.flash[random.choice(ORDER[:used])] = 1.0
        for n, (cx, cy) in enumerate(CELLS):
            f = self.flash.get(n, 0)
            if n in busy:
                r, g, bb = 70 + 185 * f, 35 + 200 * f, 140 + 115 * f
                r, g, bb = r * (.45 + .55 * f), g * (.45 + .55 * f), bb * (.45 + .55 * f)
            else:  # свободная — тусклая; вспыхивает, когда в неё пишут точку цифр
                r, g, bb = 10 + 120 * f, 8 + 90 * f, 22 + 200 * f
            for dx in range(3):
                for dy in range(2):
                    self.put(b, cx + dx, cy + dy, r * a, g * a, bb * a)
        self.flash = {k: v - .12 for k, v in self.flash.items() if v > .12}

    def bg_waves(self, b: bytearray, t: float, a: float) -> None:
        rs = num(self.v.get("rssi"), -60)
        q, c = wifi_q(rs), wifi_color(rs)
        R = 10 + 32 * q                   # докуда дотягивается сигнал
        ox, oy = 31.5, AH - .5            # антенна — внизу поля, по центру
        for k in range(4):                # дуги расходятся от антенны и гаснут к краю сигнала
            r = (t * 8 + k * R / 4) % R + 1.5
            m = (1 - (r / (R + 1.5)) ** 1.5) * (.55 + .45 * q) * .45  # фон — приглушённо, цифры поверх
            n = int(math.pi * r * 2.4) + 3  # точек на дугу — почти сплошная (дуга растянута вширь)
            for s in range(n):
                ang = math.pi * s / (n - 1)
                x, y = ox + math.cos(ang) * r * 1.6, oy - math.sin(ang) * r
                self.put(b, int(x + .5), int(y + .5), c[0] * m * a, c[1] * m * a, c[2] * m * a)
        g = .6 + .4 * math.sin(t * 7)     # антенна мигает — идёт передача
        for dx, m in ((0, 1), (-1, .4), (1, .4)):
            self.put(b, 31 + dx, AH - 1, c[0] * m * g * a, c[1] * m * g * a, c[2] * m * g * a)

    # ---------- кадр ----------
    def letters(self) -> list:
        """По буквам — заранее: (строки от и до, индексы своих точек и обводки в буфере при dy = 0). Обводка буквы
        чужую букву не портит: точки рисуются после всех обводок — как если бы обводили всё сразу."""
        out = []
        for i in range(len(self.dy)):
            lit = {p: c for p, k, c in zip(self.pts, self.li, self.cols) if k == i}
            dark = {(xx, yy) for x, y in lit for xx, yy in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1))
                    if 0 <= xx < W and (xx, yy) not in lit}
            ys = [y for _, y in lit] + [y for _, y in dark]
            out.append((min(ys, default=0), max(ys, default=0), [(y * W + x) * 3 for x, y in dark],
                        [((y * W + x) * 3, c) for (x, y), c in lit.items()]))
        return out

    def overlay(self) -> tuple[list, list]:
        """Подпись и цифры с обводкой на своих местах сейчас — индексы в буфере: (гасить, [(индекс, цвет)])."""
        dark, lit, row, end = [], [], W * 3, W * AH * 3
        for i, (y0, y1, dk, lt) in enumerate(self.lett):
            d = math.floor(self.dy[i])  # как floor(y + dy): y целое
            if y0 + d >= 0 and y1 + d < AH:  # буква целиком в поле — просто сдвиг
                sh = d * row
                dark += [j + sh for j in dk]
                lit += [(j + sh, c) for j, c in lt]
            elif y1 + d >= 0 and y0 + d < AH:  # на краю — по точке
                sh = d * row
                dark += [j + sh for j in dk if 0 <= j + sh < end]
                lit += [(j + sh, c) for j, c in lt if 0 <= j + sh < end]
        return dark, lit

    def draw(self, t: float) -> None:
        """Фон — не чаще 25 раз в секунду (пока буквы падают, кадр через раз берёт прежний фон), подпись и цифры
        с обводкой, пока стоят, — один раз; на Pi так фон Wi-Fi укладывается в кадр с запасом."""
        if self.kind == HUM:
            self.draw_hum(t)
            return
        if self.kind == TEMP:
            self.draw_neuro(t)
            return
        if self.kind == CHIP:
            self.draw_chip(t)
            return
        if self.kind == MEM:
            self.draw_mem(t)
            return
        if self.kind == WAVES:
            self.draw_wave(t)
            return
        self.n += 1
        if self.bg is not None and self.busy and self.n % 2:
            b = bytearray(self.bg)
        else:
            b = bytearray(W * AH * 3)
            if self.a > 0 and self.kind is not None:
                (None, None, self.bg_chip, self.bg_mem, self.bg_waves)[self.kind](b, t, self.a)
            self.bg = bytes(b)
        if self.busy or self.ov is None:
            ov = self.overlay()
            self.ov = None if self.busy else ov
        else:
            ov = self.ov
        for j in ov[0]:  # тёмная обводка: цифры не тонут в фоне
            b[j] = b[j + 1] = b[j + 2] = 0
        for j, c in ov[1]:
            b[j] = int(c[0]); b[j + 1] = int(c[1]); b[j + 2] = int(c[2])
        self.scr.px[:len(b)] = b

    async def _run(self) -> None:
        loop = asyncio.get_running_loop()
        while True:
            self.draw(loop.time())
            await asyncio.sleep(.02 if self.busy else .04)  # буквы стоят — фону хватает 25 кадров

    def start(self) -> None:
        self.task = asyncio.create_task(self._run())

    def stop(self) -> None:
        if self.task:
            self.task.cancel()
            self.task = None


# ---------- заголовок: анонс экрана — каждая буква своим эффектом ----------
FULL_H = 32
FX_COL = ((0, 200, 255), (110, 190, 255), (200, 230, 90), (215, 185, 255), (150, 240, 170))  # нейроны, пузырьки, сигналы, ячейки, волна
FX_OF = (0, 1, 2, 3, 4, 0)  # S — нейроны, Y — пузырьки, S — сигналы, T — ячейки, E — волна, M — нейроны
TITLE_RED = (255, 45, 30)
BLINK_IN, BLINK_OUT = (1, 0, 1, 1, 0, 1, 1, 1), (0, 1, 0, 1, 0, 0, 1, 0)


def smooth(u: float) -> float:
    u = min(1.0, max(0.0, u))
    return u * u * (3 - 2 * u)


class Title:
    """Крупное SYSTEM во весь экран: буквы собираются (и уходят) каждая своим эффектом экрана — анонс того,
    что будет дальше. Всё считается от номера кадра: где точка в кадре f — по её эффекту и её задержке."""
    LET = 14  # кадров между буквами

    def __init__(self, scr: Screen, text: str = "SYSTEM"):
        self.scr = scr
        P, x0, y0, w, h = fx.title_points(text)
        self.x0, self.y0, self.h = x0, y0, h
        self.n = len(text)
        self.p = []  # x, y, буква, эффект, задержка, откуда (x, y), скорость
        for x, y in P:
            L = (x - x0) // 6
            e = FX_OF[L % len(FX_OF)]
            self.p.append([x, y, L, e, random.randrange(14), x + random.uniform(-3, 3), FULL_H + random.uniform(0, 6),
                           random.uniform(.55, .85)])
        self.nodes = {}  # буква с нейронами → два нейрона: над и под буквой
        for L in range(self.n):
            if FX_OF[L % len(FX_OF)] == 0:
                cx = x0 + L * 6 + 2
                self.nodes[L] = [(cx + random.uniform(-3, 3), y0 - 5 + random.uniform(-1, 1)),
                                 (cx + random.uniform(-3, 3), y0 + h + 4 + random.uniform(-1, 1))]
        self.red = 0.0  # пробег света: буквы краснеют слева направо (0…1)

    def node_of(self, q) -> tuple:
        a, b = self.nodes[q[2]]
        return a if q[1] < self.y0 + self.h / 2 else b

    @staticmethod
    def ring_d(x: float, y: float) -> float:
        return math.hypot((x - 31.5) / 1.6, y - (FULL_H - .5))

    def col(self, q, settled: bool) -> tuple:
        c = FX_COL[q[3]]
        if settled and self.red >= 1:  # свет пробежал — все красные (без пересчёта каждый кадр)
            return TITLE_RED
        if settled and self.red > 0:
            k = smooth((self.red * (self.x0 + 45) - q[0]) / 4)  # свет бежит слева направо
            return mixc(c, TITLE_RED, k)
        return c

    def frame_in(self, f: int) -> tuple[list, list]:
        """Точки и «служебное» (нейроны, связи, кольцо волны) в кадре f появления."""
        pts, extra = [], []
        for q in self.p:
            x, y, L, e, d = q[0], q[1], q[2], q[3], q[4]
            st = L * self.LET + d
            k = f - st
            if e == 0:                                   # нейроны: точка вылетает из нейрона
                if k < 0:
                    continue
                u = k / 14
                nx, ny = self.node_of(q)
                if u < 1:
                    s = smooth(u)
                    pts.append((nx + (x - nx) * s, ny + (y - ny) * s, mixc((255, 255, 255), FX_COL[0], u)))
                else:
                    pts.append((x, y, self.flash(self.col(q, True), k - 14)))
            elif e == 1:                                 # пузырьки всплывают снизу
                if k < 0:
                    continue
                yy = q[6] - q[7] * k
                if yy > y:
                    kk = min(1.0, (yy - y) / 10)
                    pts.append((x + (q[5] - x) * kk + math.sin(k * .35 + d) * .4 * kk, yy, (120, 200, 255)))
                else:
                    pts.append((x, y, self.flash(self.col(q, True), int((y - yy) / q[7]))))
            elif e == 2:                                 # сигнал бежит по строке слева
                if k < 0:
                    continue
                xx = -2 + 2.4 * k
                if xx < x:
                    for t, m in ((0, 1), (1, .45), (2, .2)):
                        pts.append((xx - t * 1.5, y, mixc((0, 0, 0), mixc(FX_COL[2], (255, 255, 255), .5), m)))
                else:
                    pts.append((x, y, self.flash(self.col(q, True), int((xx - x) / 2.4))))
            elif e == 3:                                 # ячейка мигает — запись
                k = f - (L * self.LET + d * 2)
                if k < 0:
                    continue
                if k < len(BLINK_IN):
                    if BLINK_IN[k]:
                        pts.append((x, y, (235, 225, 255)))
                else:
                    pts.append((x, y, self.col(q, True)))
            else:                                        # волна от антенны проявляет
                r = .6 * (f - L * self.LET)
                if r < 0:
                    continue
                dd = self.ring_d(x, y)
                if r >= dd:
                    pts.append((x, y, self.flash(self.col(q, True), int((r - dd) / .6))))
        for L in range(self.n):                          # кольцо волны, нейроны и связь между ними
            r = .6 * (f - L * self.LET)
            if FX_OF[L % len(FX_OF)] == 4 and 0 < r < 34:
                extra.append(("ring", r, FX_COL[4]))
            if L in self.nodes:
                k = f - L * self.LET
                a = min(1.0, max(0.0, (k + 8) / 8)) * min(1.0, max(0.0, (40 - k) / 14))
                if a > 0:
                    extra.append(("nodes", self.nodes[L], a, k))
        return pts, extra

    def frame_out(self, f: int) -> tuple[list, list]:
        """Уход: буквы в обратном порядке, каждая своим эффектом."""
        pts, extra = [], []
        for q in self.p:
            x, y, L, e, d = q[0], q[1], q[2], q[3], q[4]
            st = (self.n - 1 - L) * 10 + d // 2
            k = f - st
            red = self.col(q, True)
            if k < 0 or (e == 4 and .7 * (f - (self.n - 1 - L) * 10) < self.ring_d(x, y)):
                pts.append((x, y, red)); continue
            if e == 0:                                   # нейрон втягивает
                u = k / 12
                if u >= 1:
                    continue
                nx, ny = self.node_of(q)
                s = smooth(u)
                pts.append((x + (nx - x) * s, y + (ny - y) * s, mixc(red, (255, 255, 255), u)))
            elif e == 1:                                 # пузырёк всплывает и тает у верха
                yy = y - .3 * k - .03 * k * k
                if yy < -1:
                    continue
                pts.append((x + math.sin(k * .35 + d) * .5, yy, mixc((120, 200, 255), (0, 0, 0), max(0.0, 1 - yy / 6) * .7)))
            elif e == 2:                                 # сигнал убегает вправо, разгоняясь
                xx = x + 1.2 * k + .06 * k * k
                if xx > W + 3:
                    continue
                for t, m in ((0, 1), (1, .45), (2, .2)):
                    pts.append((xx - t * 1.5, y, mixc((0, 0, 0), mixc(FX_COL[2], (255, 255, 255), .5), m)))
            elif e == 3:                                 # стирание: мигает и гаснет
                k = f - ((self.n - 1 - L) * 10 + d * 2)
                if k < 0:
                    pts.append((x, y, red))
                elif k < len(BLINK_OUT) and BLINK_OUT[k]:
                    pts.append((x, y, (235, 225, 255)))
            else:                                        # волна уносит наружу
                r0 = .7 * (f - (self.n - 1 - L) * 10)
                dd = self.ring_d(x, y)
                kk = (r0 - dd) / .7
                dx, dy = (x - 31.5) / 1.6, y - (FULL_H - .5)
                l = max(.5, math.hypot(dx, dy))
                life = 1 - kk / 26
                if life <= 0:
                    continue
                sp = kk * (.5 + kk * .03)
                pts.append((x + dx / l * 1.6 * sp, y + dy / l * sp, mixc((0, 0, 0), FX_COL[4], life)))
        for L in range(self.n):
            r = .7 * (f - (self.n - 1 - L) * 10)
            if FX_OF[L % len(FX_OF)] == 4 and 0 < r < 40:
                extra.append(("ring", r, FX_COL[4]))
            if L in self.nodes:
                k = f - (self.n - 1 - L) * 10
                a = min(1.0, max(0.0, (k + 8) / 8)) * min(1.0, max(0.0, (30 - k) / 10))
                if a > 0:
                    extra.append(("nodes", self.nodes[L], a, k))
        return pts, extra

    @staticmethod
    def flash(c, k: int) -> tuple:
        return mixc(c, (255, 255, 255), max(0.0, 1 - k / 5)) if k < 5 else c

    def show(self, pts: list, extra: list, t: float) -> None:
        b = bytearray(W * FULL_H * 3)

        def put(x, y, c):
            x, y = int(x + .5), int(y + .5)
            if 0 <= x < W and 0 <= y < FULL_H:
                j = (y * W + x) * 3
                b[j] = int(c[0]); b[j + 1] = int(c[1]); b[j + 2] = int(c[2])
        for e in extra:
            if e[0] == "ring":                           # фронт волны
                r, c = e[1], mixc((0, 0, 0), e[2], .55)
                n = int(math.pi * r * 2.4) + 3
                for s in range(n):
                    ang = math.pi * s / (n - 1)
                    put(31.5 + math.cos(ang) * r * 1.6, FULL_H - .5 - math.sin(ang) * r, c)
            else:                                        # два нейрона и связь, по ней бежит импульс
                (ax, ay), (bx, by) = e[1]
                a, k = e[2], e[3]
                n = int(max(abs(bx - ax), abs(by - ay))) + 1
                for s in range(1, n):
                    u = s / n
                    put(ax + (bx - ax) * u, ay + (by - ay) * u, (40 * a, 18 * a, 95 * a))
                u = (k * .06) % 1
                put(ax + (bx - ax) * u, ay + (by - ay) * u, (200 * a, 240 * a, 255 * a))
                for x, y in ((ax, ay), (bx, by)):
                    put(x, y, (120 * a, 220 * a, 255 * a))
                    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        put(x + dx, y + dy, (0, 50 * a, 110 * a))
        for x, y, c in pts:
            put(x, y, c)
        self.scr.px[:] = b

    async def come(self) -> None:
        last = (self.n - 1) * self.LET + 14 + 30
        for f in range(last):
            self.show(*self.frame_in(f), f * .02)
            await self.scr.frame()
        for g in range(26):                              # пробег света: буквы краснеют
            self.red = g / 25
            self.show(*self.frame_in(last + g), 0)
            await self.scr.frame()
        await self.scr.hold(1.0)

    async def leave(self) -> None:
        for f in range((self.n - 1) * 10 + 60):
            self.show(*self.frame_out(f), f * .02)
            await self.scr.frame()
        self.scr.clear()


# ---------- OPUS: отчёт диагностики — потоком, как пишет языковая модель ----------
OPUS_C = (255, 140, 90)                                                   # подпись OPUS
OPUS_LVL = {"ok": (120, 230, 190), "warn": (255, 190, 60), "bad": (255, 70, 50)}
CW = 6                                                                    # ширина знака


def opus_frame(scr: Screen, label: str, nl: int, text: str, nt: int, off: float, caret, fl: dict, col, f: int) -> None:
    """Подпись (nl знаков) и отчёт (nt знаков, сдвиг off) — поле над часами; caret — где курсор (None — нет);
    fl — знак → сколько ещё вспыхивать (только что «сгенерирован»)."""
    b = bytearray(W * AH * 3)

    def ch(c: str, x0: int, y0: int, color) -> None:
        cols = glyph(c)
        for cx in range(5):
            x = x0 + cx
            if 0 <= x < W:
                for r in range(8):
                    if cols[cx] >> r & 1 and 0 <= y0 + r < AH:
                        j = ((y0 + r) * W + x) * 3
                        b[j] = int(color[0]); b[j + 1] = int(color[1]); b[j + 2] = int(color[2])
    lx = center_x(label)
    for i in range(nl):
        ch(label[i], lx + i * CW, 0, mixc(OPUS_C, (255, 255, 255), fl.get(("l", i), 0) / 4))
    x0 = 2 - int(off)
    for i in range(nt):
        x = x0 + i * CW
        if -CW < x < W:
            ch(text[i], x, VY, mixc(col, (255, 255, 255), fl.get(("t", i), 0) / 4))
    if caret is not None and (f // 12) % 2 == 0:                          # курсор мигает
        cx, cy, cc = caret
        for r in range(7):
            for dx in range(5):
                if 0 <= cx + dx < W:
                    j = ((cy + r) * W + cx + dx) * 3
                    b[j] = int(cc[0] * .7); b[j + 1] = int(cc[1] * .7); b[j + 2] = int(cc[2] * .7)
    scr.px[:len(b)] = b


async def opus_show(scr: Screen, text: str, level: str, mind) -> None:
    """Курсор печатает OPUS; отчёт «генерируется» по словам — новые буквы вспыхивают, строка уезжает влево, чтобы
    курсор был виден; дописал — строка уходит за край; курсор стирает OPUS справа налево и гаснет."""
    label, col = "OPUS", OPUS_LVL.get(level, OPUS_LVL["ok"])
    if level == "bad" and hasattr(mind, "stir"):
        mind.stir(.8)  # проблема — стая вздрагивает
    fl: dict = {}
    lx, f = center_x(label), 0

    async def tick(nl, nt, off, caret):
        nonlocal f
        opus_frame(scr, label, nl, text, nt, off, caret, fl, col, f)
        for k in list(fl):
            fl[k] -= 1
            if fl[k] <= 0:
                del fl[k]
        f += 1
        await scr.frame()

    for _ in range(24):                                                   # курсор моргает
        await tick(0, 0, 0, (lx, 0, OPUS_C))
    for i in range(len(label)):                                           # печатает OPUS
        fl[("l", i)] = 4
        for _ in range(6):
            await tick(i + 1, 0, 0, (lx + (i + 1) * CW, 0, OPUS_C))
    for _ in range(14):
        await tick(len(label), 0, 0, None)
    # отчёт — ровным потоком, как бегущая строка: курсор печатает (на пробелах — паузы, как между словами); дошёл
    # до правого края — строка едет влево всё время с одной скоростью, курсор допечатывает, когда есть место;
    # дописал — строка уезжает с той же скоростью, курсор — вместе с её концом
    nt, off, wait, rolling = 0, 0.0, 0, False
    while True:
        cx = 2 - int(off) + nt * CW
        if nt < len(text):
            wait -= 1
            if wait <= 0 and cx <= W - 8:
                fl[("t", nt)] = 4
                nt += 1
                wait = 5 + (4 + random.randrange(4) if text[nt - 1] == " " else 0)
                cx += CW
        rolling = rolling or cx > W - 8 or nt == len(text)
        if rolling:
            off += 1
        if cx < -CW:
            break
        await tick(len(label), nt, off, (cx, VY, col) if cx < W else None)
    for i in range(len(label), 0, -1):                                    # курсор стирает OPUS
        for _ in range(5):
            await tick(i, 0, off, (lx + i * CW, 0, OPUS_C))
    for _ in range(18):
        await tick(0, 0, off, (lx, 0, OPUS_C))
    scr.px[:W * AH * 3] = bytes(W * AH * 3)


def values(clock) -> list:
    """Что показать: (фон, подпись, текст, цвет, данные для фона) — комната, если есть датчик, и система."""
    s, r, out = getattr(clock, "state", None) or {}, getattr(clock, "room", None) or {}, []
    if r.get("t") is not None:
        t = num(r.get("t"))
        out.append((TEMP, "SENSOR", f"{round(t * 10) / 10:.1f}C", t_color(t), {"t": t}))
    if r.get("h") is not None:
        out.append((HUM, "SENSOR", f"{int(num(r.get('h')) + .5)}%", (110, 190, 255), {"h": num(r.get("h"))}))
    if s.get("cpuTemp"):
        ct = num(s.get("cpuTemp"))
        out.append((CHIP, "CPU", f"{int(ct + .5)}C", cpu_color(ct), {"cpuTemp": ct, "cpu": s.get("cpu")}))
        ld = num(s.get("cpu"))
        lc = mixc((60, 230, 110), (245, 205, 40), ld / 60) if ld < 60 else mixc((245, 205, 40), (255, 60, 30), (ld - 60) / 25)
        out.append((CHIP, "CPU", f"{int(ld + .5)}%", lc, {"cpuTemp": ct, "cpu": ld}))  # загрузка — тоже сигналами
    if s.get("totalHeap"):
        ram = 100 * (1 - num(s.get("frhp")) / max(1.0, num(s.get("totalHeap"), 1)))
        out.append((MEM, "RAM", f"{int(ram + .5)}%", (215, 185, 255), {"ram": ram}))
    if s.get("rssi") is not None and num(s.get("rssi"), -100) > -100:
        rs = num(s.get("rssi"))
        out.append((WAVES, "Wi-Fi", f"{wifi_pct(rs)}%", mixc(wifi_color(rs), (255, 255, 255), .45), {"rssi": rs}))
    return out


async def system(scr: Screen, clock, mind) -> None:
    vals = values(clock)
    if not vals:
        return
    mind.calm(.12)
    title = Title(scr)                    # анонс: каждая буква — своим эффектом экрана
    await title.come()
    await title.leave()
    await row_neuro(scr, now().strftime("%H:%M"), GREEN)
    keeper, bd = ClockKeeper(scr), Board(scr)
    keeper.start()
    bd.start()
    try:
        prev = None
        for n, (kind, label, text, col, v) in enumerate(vals):
            if kind == HUM:  # пузырьки
                await bd.bubble_in(label, RED, text, col, v)
                await scr.hold(HOLD)
                await bd.bubble_out()
                continue
            if kind != CHIP:
                prev = kind
            if kind == WAVES:  # волны рисуют и уносят
                await bd.wave_in(label, RED, text, col, v)
                await scr.hold(HOLD)
                await bd.wave_out()
                continue
            if kind == MEM:  # запись в ячейки
                await bd.mem_in(label, RED, text, col, v)
                await scr.hold(HOLD)
                await bd.mem_out()
                continue
            if kind == CHIP:  # сигналы по дорожкам; CPU °C → CPU % — подпись стоит, меняется только значение
                await bd.chip_in(label, RED, text, col, v, keep=prev == CHIP)
                await scr.hold(HOLD)
                nxt = vals[n + 1][0] if n + 1 < len(vals) else None
                await bd.chip_out(value_only=nxt == CHIP)
                prev = CHIP
                continue
            if kind == TEMP:  # нейроны
                await bd.neuro_in(label, RED, text, col, v)
                await scr.hold(HOLD)
                await bd.neuro_out()
                continue
            await bd.drop_in(kind, label, RED, text, col, v)
            await scr.hold(HOLD)
            await bd.drop_out()
        op = getattr(clock, "opus", None) or {}
        if op.get("text") and time.time() - float(op.get("epoch") or 0) < 2 * 86400:  # отчёт не старше двух суток
            bd.stop()  # поле над часами — теперь у отчёта
            await opus_show(scr, op["text"], op.get("level", "ok"), mind)
    finally:
        bd.stop()
        keeper.stop()
    await fx.fall_out(scr)  # падает колонками, как буквы заголовка
    mind.calm(1)
