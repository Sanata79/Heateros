"""Заставки и уходы экранов ESP32-часов (titlefx.ino, scrfx.ino): монеты — CURRENCY, дождь — WEATHER,
огонь — HEATER, падение — SYSTEM (как IN ROOM у ESP), искры — сообщения Лины.

Частицы рисуются поверх экрана: на каждом кадре гасятся прежние места и зажигаются новые (aiFrame / soFrame).
"""
from __future__ import annotations

import math
import random

from matrix import H, W, Screen, center_x, draw_text, rnd, text_points

CX, CY = 31.5, 15.5
WHITE = (255, 255, 255)


class Dots:
    """Частицы на экране: место, цвет; frame() — стереть прежние, нарисовать новые."""

    def __init__(self, scr: Screen, y_max: int = H - 1):
        self.scr, self.y_max, self.prev = scr, y_max, []

    async def frame(self, xs, ys, cs, sec: float = .02) -> None:
        for x, y in self.prev:
            self.scr.set(x, y, (0, 0, 0))
        self.prev = []
        for x, y, c in zip(xs, ys, cs):
            x, y = rnd(x), rnd(y)
            if c and 0 <= x < W and 0 <= y <= self.y_max:
                self.scr.set(x, y, c)
                self.prev.append((x, y))
        await self.scr.frame(sec)


def title_points(t: str) -> tuple[list, int, int, int, int]:
    """Крупный заголовок по центру, как fxTitleIn: короткие слова вдвое крупнее, длинные — 5x14."""
    sx = 2 if len(t) * 12 - 2 <= W else 1
    w, h = len(t) * 6 * sx - sx, 14
    x0, y0 = (W - w) // 2, (H - h) // 2
    return text_points(t, x0, y0, sx, 2), x0, y0, w, h


def ease(k: float) -> float:
    k = min(1.0, max(0.0, k))
    return 1 - (1 - k) ** 3


async def coins_title_in(scr: Screen, t: str) -> list:
    """Монеты вихрем из-за краёв собираются в надпись, из зелёного в золото, по ней — золотой блик."""
    scr.clear()
    P, x0, _, w, _ = title_points(t)
    rt = [math.hypot(x - CX, y - CY) for x, y in P]
    at = [math.atan2(y - CY, x - CX) for x, y in P]
    d = [random.randrange(12) for _ in P]
    r0 = [random.uniform(38, 50) for _ in P]
    dots = Dots(scr)
    F = 32
    for f in range(F + 13):
        xs, ys, cs = [], [], []
        for i in range(len(P)):
            e = ease((f - d[i]) / F)
            r, a = r0[i] + (rt[i] - r0[i]) * e, at[i] + (1 - e) * 7.85  # 2.5 оборота
            xs.append(CX + r * math.cos(a)); ys.append(CY + r * math.sin(a))
            cs.append(None if f < d[i] else (255 * e, 200, 0))
        await dots.frame(xs, ys, cs, .018)
    for s in range(x0 - 4, x0 + w + 5, 2):  # золотой блик
        cs = [WHITE if abs(x - s) < 2 else (255, 240, 150) if abs(x - s) < 4 else (255, 190, 0) for x, _ in P]
        await dots.frame([p[0] for p in P], [p[1] for p in P], cs, .016)
    return P


async def coins_title_out(scr: Screen, P: list) -> None:
    """Монеты надписи осыпаются, звенят об пол, раскатываются и по одной гаснут."""
    bottom = max(y for _, y in P) + 1  # низ надписи
    xs, ys = [float(x) for x, _ in P], [float(y) for _, y in P]
    vx = [random.uniform(-.9, .9) + (x - CX) * .02 for x, _ in P]
    vy = [-random.uniform(0, 1.2) for _ in P]
    d = [random.randrange(10) + (bottom - y) // 3 for _, y in P]  # нижние срываются первыми
    gone = [34 + random.randrange(40) for _ in P]
    dots, Y = Dots(scr), H - 1
    dots.prev = list(P)
    for f in range(80):
        cs = []
        for i in range(len(P)):
            if f > gone[i]:
                cs.append(None); continue
            if f == gone[i]:
                cs.append(WHITE); continue
            if f >= d[i]:
                vy[i] += .16; xs[i] += vx[i]; ys[i] += vy[i]
                if ys[i] >= Y:  # пол
                    ys[i] = Y
                    vy[i] = -vy[i] * .45 if vy[i] > .5 else 0
                    vx[i] *= .85
            sh = .45 + .55 * abs(math.cos(f * .45 + i * 1.7))  # монета крутится
            cs.append(WHITE if not random.randrange(70) else (255 * sh, 185 * sh, 0))
        await dots.frame(xs, ys, cs)
    await dots.frame([], [], [])


async def coins_out(scr: Screen) -> None:
    """Весь экран становится золотом, осыпается на пол, раскатывается и гаснет по монетке (SO_COINS)."""
    P, C = scr.lit()
    xs, ys = [float(x) for x, _ in P], [float(y) for _, y in P]
    vx = [random.uniform(-.9, .9) + (x - CX) * .02 for x, _ in P]
    vy = [-random.uniform(0, 1.2) for _ in P]
    d = [(H - 1 - y) // 4 + random.randrange(10) for _, y in P]
    g = [34 + random.randrange(45) for _ in P]
    dots, FLOOR = Dots(scr), H - 1
    dots.prev = list(P)
    for f in range(85):
        cs = []
        for i in range(len(P)):
            if f > g[i]:
                cs.append(None); continue
            if f == g[i]:
                cs.append(WHITE); continue
            if f >= d[i]:
                vy[i] += .16; xs[i] += vx[i]; ys[i] += vy[i]
                if ys[i] >= FLOOR:
                    ys[i] = FLOOR
                    vy[i] = -vy[i] * .45 if vy[i] > .5 else 0
                    vx[i] *= .85
            sh = .45 + .55 * abs(math.cos(f * .45 + i * 1.7))
            if f < d[i]:
                cs.append(C[i])
            else:
                k = min(1.0, (f - d[i]) / 5)
                cs.append(tuple(C[i][j] + (t - C[i][j]) * k for j, t in enumerate((255 * sh, 185 * sh, 0))))
        await dots.frame(xs, ys, cs)
    scr.clear()


async def rain_title_in(scr: Screen, t: str) -> list:
    """Капли падают сверху, разгоняются и оседают в буквы, всплеск — белым; по мокрым буквам бегут блики."""
    scr.clear()
    P = title_points(t)[0]
    a = [-random.randint(2, 33) for _ in P]
    landed = [None] * len(P)
    d = [random.randrange(12) for _ in P]
    dots = Dots(scr)
    blue = [(0, 110 + (x * 7) % 60, 255) for x, _ in P]
    for f in range(70):
        allin, ys, cs = True, [], []
        for i, (x, y0) in enumerate(P):
            if f < d[i]:
                ys.append(-5); cs.append(None); allin = False
                continue
            tt = f - d[i]
            y = a[i] + .9 * tt + .06 * tt * tt  # капля разгоняется
            if y >= y0:
                y = y0
                if landed[i] is None:
                    landed[i] = f
            else:
                allin = False
            ys.append(y)
            cs.append((80, 170, 255) if landed[i] is None else WHITE if f - landed[i] < 2 else blue[i])
        await dots.frame([p[0] for p in P], ys, cs, .018)
        if allin and f > 20:
            break
    for _ in range(35):  # блики на мокрых буквах
        await dots.frame([p[0] for p in P], [p[1] for p in P],
                         [WHITE if not random.randrange(40) else blue[i] for i in range(len(P))], .03)
    return P


async def rain_title_out(scr: Screen, P: list) -> None:
    """Буквы стекают вниз и уходят за край."""
    d = [random.randrange(16) for _ in P]
    dots = Dots(scr)
    dots.prev = list(P)
    for f in range(50):
        ys = [y + (.5 * (f - d[i]) + .07 * (f - d[i]) ** 2 if f >= d[i] else 0) for i, (_, y) in enumerate(P)]
        await dots.frame([p[0] for p in P], ys, [(40, 120, 255)] * len(P))
        if all(y > H - 1 for y in ys):
            break
    await dots.frame([], [], [])


async def rain_out(scr: Screen) -> None:
    """Весь экран синеет и стекает каплями вниз (SO_RAIN)."""
    P, C = scr.lit()
    ys, vy = [float(y) for _, y in P], [0.0] * len(P)
    d = [random.randrange(18) for _ in P]
    dots = Dots(scr)
    dots.prev = list(P)
    for f in range(70):
        cs = []
        for i in range(len(P)):
            if f >= d[i]:
                vy[i] += .12; ys[i] += vy[i] + .3
                k = min(1.0, (f - d[i]) / 6)
                cs.append(tuple(C[i][j] + (t - C[i][j]) * k for j, t in enumerate((40, 120, 255))))
            else:
                cs.append(C[i])
        await dots.frame([p[0] for p in P], ys, cs)
        if all(y >= H for y in ys):
            break
    scr.clear()


async def slide_out_bottom(scr: Screen, text: str, color) -> None:
    """Нижняя строка уезжает за нижний край (slideOutToBottom)."""
    for y in range(H - 8, H + 9):
        scr.fill(0, y - 1, W, 10)
        draw_text(scr, text, center_x(text), y, color)
        await scr.frame(.01)


FALL = (255, 45, 30)  # SYSTEM — красным, как IN ROOM у ESP


async def fall_title_in(scr: Screen, t: str) -> list:
    """Буквы по одной слева направо падают сверху, ударяются белой вспышкой и чуть подпрыгивают (textDropFromTop)."""
    scr.clear()
    P, x0, _, _, _ = title_points(t)
    sx = 2 if len(t) * 12 - 2 <= W else 1
    li = [(x - x0) // (6 * sx) for x, _ in P]                      # номер буквы
    ys = [float(y - 18 - li[i] % 2 * 3) for i, (_, y) in enumerate(P)]
    vy, hit = [0.0] * len(P), [None] * len(P)
    dots = Dots(scr)
    for f in range(len(t) * 5 + 40):
        cs = []
        for i, (_, y) in enumerate(P):
            if f < li[i] * 5:
                cs.append(None); continue
            vy[i] += .32; ys[i] += vy[i]
            if ys[i] >= y:  # удар: вспышка и отскок, всё меньше
                ys[i] = y
                if hit[i] is None:
                    hit[i] = f
                vy[i] = -vy[i] * .3 if vy[i] > 1 else 0
            cs.append(WHITE if hit[i] is not None and f - hit[i] < 2 else FALL)
        await dots.frame([p[0] for p in P], ys, cs, .018)
    return P


async def fall_title_out(scr: Screen, P: list) -> None:
    """Буквы по очереди слева направо срываются вниз (textFallDownByLetter)."""
    x0 = min((x for x, _ in P), default=0)
    d = [(x - x0) // 6 * 3 for x, _ in P]
    ys, vy = [float(y) for _, y in P], [0.0] * len(P)
    dots = Dots(scr)
    dots.prev = list(P)
    for f in range(80):
        for i in range(len(P)):
            if f >= d[i]:
                vy[i] += .3; ys[i] += vy[i]
        await dots.frame([p[0] for p in P], ys, [FALL] * len(P))
        if all(y > H - 1 for y in ys):
            break
    await dots.frame([], [], [])


async def fall_out(scr: Screen) -> None:
    """Весь экран падает колонками слева направо, как буквы заголовка (SO_FALL, IN ROOM у ESP)."""
    P, C = scr.lit()
    d = [(x // 6) * 2 + random.randrange(3) for x, _ in P]
    ys, vy = [float(y) for _, y in P], [0.0] * len(P)
    dots = Dots(scr)
    dots.prev = list(P)
    for f in range(70):
        for i in range(len(P)):
            if f >= d[i]:
                vy[i] += .15; ys[i] += vy[i]
        await dots.frame([p[0] for p in P], ys, C)
        if all(y >= H for y in ys):
            break
    scr.clear()


def flame(h: float, flick: float) -> tuple:  # пламя: h — разгар 0…1
    return (min(255, 255 * (.45 + .55 * h) * flick), min(255, (40 + 180 * h * h) * flick), 60 * flick if h > .92 else 0)


async def fire_title_in(scr: Screen, t: str) -> list:
    """Искры поднимаются снизу волной слева направо и разгораются в буквы; буквы горят."""
    scr.clear()
    P, x0, _, _, _ = title_points(t)
    ax = [x + random.randint(-4, 4) for x, _ in P]
    ay = [H + random.randrange(12) for _ in P]
    d = [(x - x0) // 3 + random.randrange(6) for x, _ in P]
    dots, F = Dots(scr), 26
    for f in range(F + 31):
        xs, ys, cs = [], [], []
        for i, (x, y) in enumerate(P):
            e = ease((f - d[i]) / F)
            xs.append(ax[i] + (x - ax[i]) * e + math.sin(f * .6 + i) * (1 - e) * 1.5)
            ys.append(ay[i] + (y - ay[i]) * e)
            cs.append(None if f < d[i] else flame(e, random.uniform(.75, 1)))
        await dots.frame(xs, ys, cs, .018)
    for _ in range(45):  # буквы горят
        await dots.frame([p[0] for p in P], [p[1] for p in P],
                         [flame(random.uniform(.6, 1), random.uniform(.7, 1)) for _ in P], .03)
    return P


async def fire_title_out(scr: Screen, P: list) -> None:
    """Буквы рассыпаются угольками вверх, угольки остывают."""
    xs, ys = [float(x) for x, _ in P], [float(y) for _, y in P]
    vx = [random.uniform(-.25, .25) for _ in P]
    vy = [-random.uniform(.4, 1.2) for _ in P]
    dots = Dots(scr)
    dots.prev = list(P)
    for f in range(30):
        b = 1 - f / 30
        for i in range(len(P)):
            xs[i] += vx[i] + math.sin(f * .5 + i) * .2
            ys[i] += vy[i]
        await dots.frame(xs, ys, [(255 * b * random.uniform(.7, 1), 90 * b * b, 0) for _ in P], .028)
    await dots.frame([], [], [])


async def fire_out(scr: Screen) -> None:
    """Экран разгорается снизу вверх, угольки поднимаются и остывают (SO_FIRE)."""
    P, C = scr.lit()
    xs, ys = [float(x) for x, _ in P], [float(y) for _, y in P]
    d = [(H - 1 - y) // 2 + random.randrange(7) for _, y in P]
    vx = [random.uniform(-.3, .3) for _ in P]
    vy = [-random.uniform(.25, 1.1) for _ in P]
    dots = Dots(scr)
    dots.prev = list(P)
    for f in range(50):
        cs = []
        for i in range(len(P)):
            if f < d[i]:
                cs.append(C[i]); continue
            k = (f - d[i]) / 26
            xs[i] += vx[i] + math.sin(f * .5 + i) * .15
            ys[i] += vy[i]
            if k < .25:
                w = k / .25
                cs.append(tuple(C[i][j] + (t - C[i][j]) * w for j, t in enumerate((255, 200, 60))))
            elif k < 1:
                cs.append((255 * (1.25 - k) * random.uniform(.7, 1), 200 * (1 - k) ** 2, 0))
            else:
                cs.append(None)
        await dots.frame(xs, ys, cs)
    scr.clear()


async def scatter_out(scr: Screen) -> None:
    """Вспышка и разлёт искрами, как «AI» (SO_SCATTER)."""
    P, C = scr.lit()
    xs, ys = [float(x) for x, _ in P], [float(y) for _, y in P]
    vx = [random.uniform(-1.5, 1.5) for _ in P]
    vy = [random.uniform(-1.2, .6) for _ in P]
    dots, F = Dots(scr), 24
    dots.prev = list(P)
    for f in range(F):
        b = 1 - f / F
        for i in range(len(P)):
            xs[i] += vx[i]; ys[i] += vy[i]; vy[i] += .12
        await dots.frame(xs, ys, [WHITE if f < 3 else (c[0] * b * b, c[1] * b * b, c[2] * b * b) for c in C], .028)
    scr.clear()
